# SPDX-License-Identifier: LGPL-3.0-only

"""Graphical interface for Doorstop."""
