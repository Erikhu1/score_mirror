# SPDX-License-Identifier: LGPL-3.0-only

"""Web interface for Doorstop."""

from .client import check, get_next_number
