# SPDX-License-Identifier: LGPL-3.0-only

"""Package for the doorstop.server tests."""

ENV = "TEST_INTEGRATION"  # environment variable to enable integration tests
REASON = "'{0}' variable not set".format(ENV)
