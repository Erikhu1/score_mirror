# License information

Trustable Software Framework © 2016-25 by Codethink is licensed under Creative
Commons Attribution-ShareAlike 4.0 International. To view a copy of this
license, visit https://creativecommons.org/licenses/by-sa/4.0/ or see the
license text in the project [here](./LICENSE)

The accompanying [tools]({{ trustable.source }}/tools) are licensed under
Eclipse Public License 2.0. See the Eclipse Foundation site
[here](https://www.eclipse.org/legal/epl-2.0/) for more information, or see the
license text in the project [here](./trudag/LICENSE).
