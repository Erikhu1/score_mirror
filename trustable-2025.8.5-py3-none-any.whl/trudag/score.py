# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

"""
Library for Trustable score calculations.

In practice, this means functions for interfacing between [dotstop][trudag.dotstop] and [graphalyzer][trudag.graphalyzer].
"""

import trudag.graphalyzer.graph as gzrgraph
import trudag.graphalyzer.analysis as gzranalysis
from trudag.dotstop.core.graph import TrustableGraph
import trudag.utils as utils
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


def score(
    graph: TrustableGraph, validate: bool, dump: Path | None = None
) -> dict[str, float]:
    """
    Compute the trustable score of `graph` and all its reviewed `BaseItem`s.

    The score is calculated recursively from leaf `BaseItem`s, with each
    `BaseItem` being assigned a score equal to the weighted sum of its child
    `BaseItem`s. The score for each leaf `BaseItem` should be recorded in an
    attribute named [`ITEM_SCORE_KEY`][trudag.ITEM_SCORE_KEY],
    else its score will be assumed to be zero.

    Unreviewed `BaseItem`s will not be scored. Contributions from child
    `BaseItem`s associated by a suspect link are ignored.

    Warning:
        Scoring is still under heavy development. Currently:

        - Scores for non-leaf nodes are ignored.
        - All weights are assumed to be one and are normalized accordingly.

        This behaviour is likely to change.

    Args:
        graph (TrustableGraph): Graph to score.
        validate (bool): Run automated validators.
        dump (Path): Output file path for the Trustable Scores file

    Returns:
        (dict[str, float]): Dictionary of (UID, confidence score) pairs for all reviewed `BaseItem`s.
    """

    valid_subgraph = graph.valid_subgraph()
    evidence_score_dict = scores_from_graph(valid_subgraph, run_validators=validate)
    digraph = gzrgraph.DirectedAcyclicGraph(
        valid_subgraph.adjacency, [item.name for item in valid_subgraph.items]
    ).normalized()

    scores = gzranalysis.score(digraph, evidence_score_dict)

    # dump scores to an output file if any output path is provided
    utils.dump_scores(scores, dump)
    return scores


def scores_from_graph(
    graph: TrustableGraph, run_validators: bool = False
) -> dict[str, float]:
    """
    Given a [`TrustableGraph`], extract the Evidence scores.

    Where items have neither an SME or validation score, assign them a score of
    zero, logging a warning.
    Where items have an SME score but are missing a validation score AND references, assign them a score
    of zero, logging a warning.
    Where items have both an SME and validation score,
    take their product.

    Args:
        graph (dotstop.Graph): Graph to extract Evidence scores from.
        run_validators (bool, optional): Run automated validators. Defaults to False.

    Returns:
        (dict[str, float]): Dictionary of (item_str, confidence score) pairs for Evidence items
    """
    evidence_score_dict = {}
    for evidence in graph.get_premises():
        sme_score = evidence.score
        validator_score = evidence.validate() if run_validators else None
        if sme_score is None and validator_score is None:
            logger.warning(
                "Score not provided for Item %s. Score set to zero.", str(evidence)
            )
            evidence_score_dict[str(evidence)] = 0.0
        else:
            if (sme_score is not None) and (
                (validator_score is None) and not evidence.references()
            ):
                logger.warning(
                    "Score provided for Item %s is invalid, no validator or artifact provided for the score. Score set to zero.",
                    str(evidence),
                )
                evidence_score_dict[str(evidence)] = 0.0
                continue
            sme_score = 1.0 if sme_score is None else sme_score
            validator_score = 1.0 if validator_score is None else validator_score
            evidence_score_dict[str(evidence)] = sme_score * validator_score
    return evidence_score_dict
