# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

"""
Functions acting on the structure of a [`DirectedAcyclicGraph`][trudag.graphalyzer.graph.DirectedAcyclicGraph].
"""

import numpy as np
from trudag.graphalyzer.graph import DirectedAcyclicGraph


def _vector_score(
    graph: DirectedAcyclicGraph,
    completeness_matrix: np.ndarray,
    leaf_correctness_vector: np.ndarray,
) -> np.ndarray:
    r"""
    Return the graph's vector of scores $\boldsymbol{t}$, given the `completeness_matrix`, $\mathbf{C}_p$ and the `leaf_correctness_vector`, ${\boldsymbol{c}_r}_E$.

    $$
    \boldsymbol{t} = \mathbf{C}_p\sum_{i=0,...,n} \left(\boldsymbol{W}\mathbf{C}_p\right)^i ${\boldsymbol{c}_r}_E$.
    $$

    Args:
        graph (DirectedAcyclicDigraph): Graph defining the scoring function $T$.
        completeness_matrix (np.ndarray): Diagonal matrix of completeness scores.
        leaf_correctness_vector(np.ndarray): Vector of leaf correctness scores.

    Returns:
        t (np.ndarray): Complete vector of node scores.
    """
    t = completeness_matrix @ leaf_correctness_vector
    base = graph.adjacency @ completeness_matrix
    power_acc = base @ leaf_correctness_vector
    while power_acc.any():
        t += completeness_matrix @ power_acc
        power_acc = base @ power_acc
    return t


def score(
    graph: DirectedAcyclicGraph,
    leaf_correctness_scores_dict: dict[str, float],
    completeness_scores_dict: dict[str, float] | None = None,
) -> dict[str, float]:
    r"""
    Given a dictionary of correctness scores for leaf (or equivalently Premise) items, compute the Trustable Scores of every node in the graph.

    This function implements the algorithm described in the [scoring roadmap](../../../trudag/scoring-roadmap.md).

    !!! note
        - Non-leaf item scores included in `leaf_correctness_scores_dict` are disregarded.
        - Unscored leaves are assumed to have score zero.
        - If no completeness scores are provided, the argument is assumed to be complete.
        - If partial completeness scores are provided, omitted scores are set to zero.

    Args:
        graph (DirectedAcyclicGraph): Graph of the project being scored.
        leaf_correctness_scores_dict (dict[str, float]): Dictionary of (leaf item name, leaf item correctness) pairs.
        completeness_scores_dict (dict[str, float] | None, optional): Dictionary of (item name, item completeness). Defaults to None.

    Returns:
        (dict[str, float]): Dictionary of (item name, item trustable score) pairs.
    """

    leaf_correctness_vector = _leaf_dict_to_vector(graph, leaf_correctness_scores_dict)
    completeness_matrix = _completeness_dict_to_matrix(graph, completeness_scores_dict)

    t = _vector_score(graph, completeness_matrix, leaf_correctness_vector)

    scores_dict = {str(node): t[index][0] for node, index in graph.nodes()}

    return scores_dict


def _dscore_dscores(
    graph: DirectedAcyclicGraph, completeness_matrix: np.ndarray, r: int
) -> np.ndarray:
    r"""
    Return the vector derivative $\partial t_r/\partial \mathbf{t}$.

    Args:
        graph (DirectedAcyclicGraph): Graph defining the scoring function $T$
        completeness_matrix (np.ndarray): Diagonal matrix of completeness scores.
        r (int): Component of the score to differentiate.

    Returns:
        dtr_dt (np.ndarray): Vector derivative of score component.
    """
    d_r = np.zeros([graph.size(), 1])
    d_r[r][0] = 1.0

    sum = np.zeros([graph.size(), graph.size()])
    for i in range(0, graph.size()):
        sum += np.linalg.matrix_power(
            np.transpose(completeness_matrix @ graph.adjacency), i
        )

    return sum @ d_r


def score_node_sensitivity(
    graph: DirectedAcyclicGraph,
    node_label: str,
    completeness_scores_dict: dict[str, float] | None = None,
) -> dict[str, float]:
    r"""
    The partial derivatives of `node_label`'s score with respect to other node scores.

    That is, if `node_label` corresponds to the $r^\text{th}$ node, return

    $$
    \frac{\partial t_r}{\partial t_s} = \left(\mathbf{d}_r^\intercal\sum_{i=0,...,n}\left(\mathbf{C}_p\mathbf{W}\right)^k\right)_s
    $$

    where $(d_r)_s = \delta_{rs}$.

    Args:
        graph (DirectedAcyclicGraph): Graph of project under analysis.
        node_label (str): Label of the node to return partial derivatives of.
        completeness_scores_dict (dict[str, float] | None, optional): Dictionary of (item name, item completeness). Defaults to None.

    Returns:
        (dict[str, float]): (node, node-derivative) key-value pairs for all nodes.
    """
    completeness_matrix = _completeness_dict_to_matrix(graph, completeness_scores_dict)

    dnode_dt = _dscore_dscores(
        graph, completeness_matrix, graph.label_to_index(node_label)
    )

    derivative_dict = {str(node): dnode_dt[index][0] for node, index in graph.nodes()}

    return derivative_dict


def _d_score_d_weight(
    graph: DirectedAcyclicGraph,
    edge: tuple[int, int],
    completeness_matrix: np.ndarray,
    leaf_correctness_vector: np.ndarray,
) -> np.ndarray:
    r"""
    The derivative of node scores $\partial \mathbf{t}/\partial w_{rs}$.

    That is,

    $$
    \frac{\partial\mathbf{t}}{\partial w_{rs}} = \mathbf{C}_p\sum_{i=0}^n\sum_{k=0}^{i-1}\left(\mathbf{W}\mathbf{C}_p\right)^k \mathbf{E}_{rs}\mathbf{C}_p\left(\mathbf{W}\mathbf{C}_p\right)^{i-1-k}{\mathbf{c}_r}_E.
    $$

    where

    $$
    (e_{rs})_{ij} =
    \begin{cases}
    1,\; i=r, j=s\\
    0,\; \text{otherwise}
    \end{cases}.
    $$

    Args:
        graph (DirectedAcyclicGraph): Graph of the project being analyzed.
        edge (tuple[int,int]): Index into weighted adjacency matrix.
        completeness_matrix (np.ndarray): Diagonal matrix of completeness scores.
        leaf_correctness_vector(np.ndarray): Vector of leaf correctness scores.

    Returns:
        dt_dwrs (np.ndarray): Vector of derivatives.
    """

    sum = np.zeros([graph.size(), graph.size()])
    e_rs = np.zeros([graph.size(), graph.size()])
    e_rs[edge[0]][edge[1]] = 1.0
    for k in range(1, graph.size()):
        for m in range(0, k):
            sum += (
                np.linalg.matrix_power(completeness_matrix @ graph.adjacency, m)
                @ completeness_matrix
                @ e_rs
                @ np.linalg.matrix_power(
                    completeness_matrix @ graph.adjacency, k - 1 - m
                )
            )
    return completeness_matrix @ sum @ leaf_correctness_vector


def score_edge_sensitivity(
    graph: DirectedAcyclicGraph,
    edge: tuple[str, str],
    leaf_correctness_scores_dict: dict[str, float],
    completeness_scores_dict: dict[str, float] | None = None,
) -> dict[str, float]:
    r"""
    Dictionary of node scores differentiated with respect to the chosen edge weight.

    Args:
        graph (DirectedAcyclicGraph): Graph of the project being analyzed.
        edge (tuple[str, str]): `(parent, child)` definition of an edge.
        leaf_correctness_scores_dict (dict[str, float]): Dictionary of (leaf item name, leaf item correctness) pairs.
        completeness_scores_dict (dict[str, float] | None, optional): Dictionary of (item name, item completeness). Defaults to None.

    Returns:
        (dict[str, float]): (node, node-derivative) key-value pairs for all nodes.
    """

    leaf_correctness_vector = _leaf_dict_to_vector(graph, leaf_correctness_scores_dict)
    completeness_matrix = _completeness_dict_to_matrix(graph, completeness_scores_dict)

    d_score_d_weight = _d_score_d_weight(
        graph,
        tuple(graph.label_to_index(label) for label in edge),
        completeness_matrix,
        leaf_correctness_vector,
    )

    derivative_dict = {
        str(node): d_score_d_weight[index][0] for node, index in graph.nodes()
    }

    return derivative_dict


def _completeness_dict_to_matrix(
    graph: DirectedAcyclicGraph, completeness_scores_dict: dict[str, float] | None
) -> np.ndarray:
    """
    Convert a dictionary of (node label, score) pairs to an appropriately ordered diagonal matrix of scores.
    """
    if completeness_scores_dict:
        completeness_matrix = np.zeros([graph.size(), graph.size()])
        for node, index in graph.nodes():
            if str(node) in completeness_scores_dict:
                completeness_matrix[index][index] = completeness_scores_dict[str(node)]
        return completeness_matrix
    return np.identity(graph.size())


def _leaf_dict_to_vector(
    graph: DirectedAcyclicGraph,
    leaf_correctness_scores_dict: dict[str, float],
):
    """
    Convert a dictionary of (node label, score) pairs to an appropriately ordered vector of scores.
    """

    leaf_correctness_vector = np.zeros([graph.size(), 1])

    for node, index in graph.leaves():
        if str(node) in leaf_correctness_scores_dict:
            leaf_correctness_vector[index][0] = leaf_correctness_scores_dict[str(node)]

    return leaf_correctness_vector
