# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

"""
Collection of tests for the [`graphalyzer.graph`][trudag.graphalyzer.graph] module.
"""

import pytest
import trudag.graphalyzer.graph as gzrgraph
import numpy as np


# For floating point comparisons, we need to test equality within a tolerance.
# We should use the claimed tolerance of the library for testing.
ABS_TOL = gzrgraph.ABS_TOL
REL_TOL = gzrgraph.REL_TOL

# Tests for class constructor


def test_constructor_rectangular():
    RECTANGULAR_ARRAY = np.array([[0, 0, 0, 0], [1, 0, 0, 0]])
    with pytest.raises(
        ValueError,
        match="Directed Acyclic Graphs must have square adjacency matrice",
    ):
        gzrgraph.DirectedAcyclicGraph(RECTANGULAR_ARRAY)


def test_constructor_negative():
    NEGATIVE_EDGE_ARRAY = np.array(
        [[0, 0, 0, 0], [1, 0, 0, 0], [0, -1, 0, 0], [0, 0, 15, 0]]
    )
    with pytest.raises(
        ValueError, match="Graphalyzer does not support Digraphs with negative weights"
    ):
        gzrgraph.DirectedAcyclicGraph(NEGATIVE_EDGE_ARRAY)


def test_constructor_nilpotency():
    NON_NILPOTENT_ARRAY = np.array(
        [[0, 0, 0, 0], [1, 0, 0, 0], [0, 1, 1, 0], [0, 0, 15, 0]]
    )
    with pytest.raises(
        ValueError,
        match="The given Graph is cyclic, Graphalyzer only supports graphs without cycles.",
    ):
        gzrgraph.DirectedAcyclicGraph(NON_NILPOTENT_ARRAY)


def test_constructor_nonunique():
    VALID_ARRAY = np.array([[0, 1, 0], [0, 0, 1], [0, 0, 0]])
    NONUNIQUE_NODES = ["A", "B", "A"]
    with pytest.raises(ValueError, match="Nodes must have unique labels"):
        gzrgraph.DirectedAcyclicGraph(VALID_ARRAY, NONUNIQUE_NODES)


# Tests for class methods parametrized over graph fixtures


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_size(graph, request):
    graph = request.getfixturevalue(graph)
    assert graph["dag"].size() == graph["size"]


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_adjacency(graph, request):
    graph = request.getfixturevalue(graph)
    assert np.allclose(
        graph["dag"].adjacency,
        graph["adjacency"],
        atol=ABS_TOL,
        rtol=REL_TOL,
    )


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_symmetric_adjacency(graph, request):
    graph = request.getfixturevalue(graph)
    assert np.allclose(
        graph["dag"].symmetric_adjacency(),
        graph["symmetric_adjacency"],
    )


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_outdegree(graph, request):
    graph = request.getfixturevalue(graph)
    assert np.allclose(
        graph["dag"].outdegree(),
        graph["outdegree"],
        atol=ABS_TOL,
        rtol=REL_TOL,
    )


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_indegree(graph, request):
    graph = request.getfixturevalue(graph)
    assert np.allclose(
        graph["dag"].indegree(),
        graph["indegree"],
        atol=ABS_TOL,
        rtol=REL_TOL,
    )


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_degree(graph, request):
    graph = request.getfixturevalue(graph)
    assert np.allclose(
        graph["dag"].degree(),
        graph["degree"],
        atol=ABS_TOL,
        rtol=REL_TOL,
    )


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_laplacian(graph, request):
    graph = request.getfixturevalue(graph)
    assert np.allclose(
        graph["dag"].laplacian(),
        graph["laplacian"],
        atol=ABS_TOL,
        rtol=REL_TOL,
    )


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_is_connected(graph, request):
    graph = request.getfixturevalue(graph)
    assert graph["dag"].is_connected() == graph["connected"]


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_leaves(graph, request):
    graph = request.getfixturevalue(graph)
    labels = [str(node) for node, _ in graph["dag"].leaves()]
    indices = [index for _, index in graph["dag"].leaves()]
    assert (labels, indices) == graph["leaves"]


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_roots(graph, request):
    graph = request.getfixturevalue(graph)
    labels = [str(node) for node, _ in graph["dag"].roots()]
    indices = [index for _, index in graph["dag"].roots()]
    assert (labels, indices) == graph["roots"]


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_nodes(graph, request):
    graph = request.getfixturevalue(graph)
    labels = [str(node) for node, _ in graph["dag"].nodes()]
    indices = [index for _, index in graph["dag"].nodes()]
    assert (labels, indices) == graph["nodes"]


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_normalized(graph, request):
    graph = request.getfixturevalue(graph)
    print(graph["dag"].normalized().adjacency)
    assert np.allclose(
        graph["dag"].normalized().adjacency,
        graph["normalized_adjacency"],
        atol=ABS_TOL,
        rtol=REL_TOL,
    )
    assert graph["dag"].normalized().is_normalized()


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_is_normalized(graph, request):
    graph = request.getfixturevalue(graph)
    assert graph["dag"].is_normalized() == graph["is_normalized"]


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_unweighted(graph, request):
    graph = request.getfixturevalue(graph)
    assert np.allclose(
        graph["dag"].unweighted().adjacency,
        graph["unweighted_adjacency"],
        atol=ABS_TOL,
        rtol=REL_TOL,
    )
    assert graph["dag"].unweighted().is_unweighted()


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_is_unweighted(graph, request):
    graph = request.getfixturevalue(graph)
    assert graph["dag"].is_unweighted() == graph["is_unweighted"]


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_reversed(graph, request):
    graph = request.getfixturevalue(graph)
    assert np.allclose(
        graph["dag"].reversed().adjacency,
        graph["reversed_adjacency"],
        atol=ABS_TOL,
        rtol=REL_TOL,
    )
