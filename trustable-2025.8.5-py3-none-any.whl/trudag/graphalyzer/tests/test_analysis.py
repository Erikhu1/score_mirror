# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

"""
Collection of tests for the [`graphalyzer.graph`][trudag.graphalyzer.graph] module.
"""

import pytest
import trudag.graphalyzer.graph as gzrgraph
import trudag.graphalyzer.analysis as gzranalysis
import numpy as np


# For floating point comparisons, we need to test equality within a tolerance.
# We should use the claimed tolerance of the library for testing.
ABS_TOL = gzrgraph.ABS_TOL
REL_TOL = gzrgraph.REL_TOL


# Tests for class methods parametrized over graph fixtures
@pytest.mark.parametrize(
    "graph",
    [
        "weighted",
        "unweighted",
        "unconnected",
        "weighted_incomplete",
        "unweighted_incomplete",
        "unconnected_incomplete",
    ],
)
def test_score(graph, request):
    graph = request.getfixturevalue(graph)
    calculated = gzranalysis.score(
        graph["dag"],
        graph["leaf_scores_dict"],
        graph["completeness_scores_dict"],
    )
    actual = graph["all_scores_dict"]
    assert np.allclose(
        np.array(list(calculated.values())),
        np.array(list(actual.values())),
        atol=ABS_TOL,
        rtol=REL_TOL,
    )
    assert calculated.keys() == actual.keys()


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_score_node_sensitivity(graph, request):
    graph = request.getfixturevalue(graph)
    calculated = gzranalysis.score_node_sensitivity(
        graph["dag"], graph["node_label_for_sensitivities"]
    )
    actual = graph["node_sensitivities_dict"]
    assert np.allclose(
        np.array(list(calculated.values())),
        np.array(list(actual.values())),
        atol=ABS_TOL,
        rtol=REL_TOL,
    )
    assert calculated.keys() == actual.keys()


@pytest.mark.parametrize("graph", ["weighted", "unweighted", "unconnected"])
def test_score_edge_sensitivity(graph, request):
    graph = request.getfixturevalue(graph)
    calculated = gzranalysis.score_edge_sensitivity(
        graph["dag"], graph["edge_labels_for_sensitivities"], graph["leaf_scores_dict"]
    )
    actual = graph["edge_sensitivities_dict"]
    assert np.allclose(
        np.array(list(calculated.values())),
        np.array(list(actual.values())),
        atol=ABS_TOL,
        rtol=REL_TOL,
    )
    assert calculated.keys() == actual.keys()
