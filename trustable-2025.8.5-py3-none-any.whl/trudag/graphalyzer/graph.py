# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

"""
Adjacency-matrix-backed representations of graphs, with methods for performing
simple spectral and linear graph analysis.
"""

import numpy as np
import copy
from typing import Any, Iterator
from trudag.graphalyzer import REL_TOL, ABS_TOL

_RENDER_FORMAT = "svg"


class DirectedAcyclicGraph:
    def __init__(
        self, adjacency_matrix: np.ndarray, nodes: list[str] | None = None
    ) -> "DirectedAcyclicGraph":
        """
        An adjacency-matrix-driven representation of a [directed acyclic graph (DAG)](https://en.wikipedia.org/wiki/Directed_acyclic_graph).

        The adjacency matrix must be square with non-negative entries.
        The adjacency matrix must be also be consistent with the acyclic property of the graph.
        That is it must be nilpotent or equivalently be expressible in an upper triangular form through a sequence of row permutations.

        The nodes of a `DirectedAcyclicGraph` can be automatically labelled,
        or if `nodes` is specified,
        any list of objects with unique representations as a `str` can be used.

        Args:
            adjacency_matrix (np.ndarray): Square matrix describing the relationships between nodes.
            nodes (list[Any] | None, optional): Set of nodes in the graph. If provided, it should have length equal to the size of `adjacency_matrix`. Defaults to None.
        """
        DirectedAcyclicGraph._is_dag(adjacency_matrix)
        if not nodes:
            # No user defined nodes, use default labelling
            self._nodes = []
            for i in range(0, adjacency_matrix.shape[0]):
                self._nodes.append(DirectedAcyclicGraph._default_label(i))
        elif adjacency_matrix.shape[0] == len(nodes):
            # User defined nodes given, use their labels, if they are unique
            if len(nodes) > len(set(nodes)):
                raise ValueError("Nodes must have unique labels")
            self._nodes = nodes
        else:
            # Array node label length mismatch
            raise ValueError(
                "The length of node must correspond to the size of the adjacency matrix"
            )
        self._adjacency = adjacency_matrix.astype(float)

    @staticmethod
    def _is_dag(adjacency_matrix: np.ndarray) -> bool:
        """
        Raise ValueErrors if the input matrix is not a DAG.

        Detection of non-DAG adjacency matrices is determined by property
        testing:
        - DAGs are square matrices
        - DAGs have positive weights
        - DAGs are nilpotent

        Args:
            adjacency_matrix (np.ndarray): Matrix to be checked
        """
        if adjacency_matrix.ndim != 2:
            raise ValueError("Graphalyzer does not support multigraphs")
        if adjacency_matrix.shape[0] != adjacency_matrix.shape[1]:
            raise ValueError(
                "Directed Acyclic Graphs must have square adjacency matrices"
            )
        if (adjacency_matrix < 0.0).any():
            raise ValueError(
                "Graphalyzer does not support Digraphs with negative weights"
            )
        if np.linalg.matrix_power(adjacency_matrix, adjacency_matrix.shape[0]).any():
            raise ValueError(
                "The given Graph is cyclic, Graphalyzer only supports graphs without cycles."
            )
        return True

    @staticmethod
    def random(
        nodes: int, edge_probability: float, range: tuple[float, float] = (0.1, 1.0)
    ) -> "DirectedAcyclicGraph":
        """
        Generate a [`DirectedAcyclicGraph`][trudag.graphalyzer.graph.DirectedAcyclicGraph] of known size, with randomized adjacencies and edge weights.

        Created from a lower-triangular matrix of random non-negative real numbers.

        Args:
            nodes (int): Total number of nodes in the graph.
            edge_probability (float): Probability of an edge between any two nodes (lower values create sparser graphs, on average).
            range tuple[float, float]: Interval to uniformly sample edge weights from.
        """
        rng = np.random.default_rng()
        adjacency = rng.choice(
            a=[0.0, 1.0],
            size=(nodes, nodes),
            p=[edge_probability, 1.0 - edge_probability],
        )
        adjacency *= np.tri(*adjacency.shape, k=-1)
        weights = range[0] + rng.choice(nodes, nodes) * (range[1] - range[0])
        return DirectedAcyclicGraph(adjacency * weights)

    @staticmethod
    def _default_label(index: int) -> str:
        """
        Express an integer as a base 26 number using alphabetic digits.

        Uses the convention that A = 0, Z = 25, such that BA = 26.

        Args:
            index (int): Integer to be expressed as a base 26 string
        """
        ALPHABET_SIZE = 26
        remainder = index
        label = ""
        while remainder >= ALPHABET_SIZE:
            divisor, remainder = divmod(index, ALPHABET_SIZE)
            label = chr(ord("A") + remainder) + label
            remainder = divisor
        label = chr(ord("A") + remainder) + label
        return label

    def size(self) -> int:
        """
        Number of nodes in the graph.
        """
        return self._adjacency.shape[0]

    @property
    def adjacency(self) -> np.ndarray:
        r"""
        The graph's adjacency matrix.

        The adjacency matrix of a graph of $n$ ordered nodes is an $n\times n$ square matrix,
        where a non-zero value $w$ in the $(i,j)^\text{th}$ entry indicates there is a directed edge of weight $w$ from node $i$ to node $j$.
        """
        return self._adjacency

    def symmetric_adjacency(self) -> np.ndarray:
        """
        A symmetrised copy of the graph's [adjacency][trudag.graphalyzer.graph.DirectedAcyclicGraph.adjacency] matrix.

        This is the adjacency matrix of the equivalent undirected graph.
        """
        return self._adjacency + self._adjacency.transpose()

    def indegree(self) -> np.ndarray:
        r"""
        The graph's matrix of indegrees.

        This is a diagonal matrix where the $(i,i)^\text{th}$ entry is the number of edges entering the $i^\text{th}$ node.
        """
        indegree = np.zeros(self._adjacency.shape)
        for i in range(0, self._adjacency.shape[0]):
            transpose = self._adjacency.transpose()
            indegree[i][i] = transpose[i].sum()
        return indegree

    def outdegree(self) -> np.ndarray:
        r"""
        The graph's matrix of outdegrees.

        This is a diagonal matrix where the $(i,i)^\text{th}$ entry is the number of edges exiting the $i^\text{th}$ node.
        """
        outdegree = np.zeros(self._adjacency.shape)
        for i in range(0, self._adjacency.shape[0]):
            outdegree[i][i] = self._adjacency[i].sum()
        return outdegree

    def degree(self) -> np.ndarray:
        r"""
        The graph's matrix of degrees.

        This is a diagonal matrix where the $(i,i)^\text{th}$ entry is the number of edges entering or exiting the $i^\text{th}$ node.
        """
        return self.indegree() + self.outdegree()

    def laplacian(self) -> np.ndarray:
        """
        The [Laplacian matrix](https://en.wikipedia.org/wiki/Laplacian_matrix) of the equivalent undirected graph.

        That is, the Laplacian of the graph with adjacency matrix [`self.symmetric_adjacency()`][trudag.graphalyzer.graph.DirectedAcyclicGraph.symmetric_adjacency].
        """

        return self.degree() - self.symmetric_adjacency()

    def fiedler_number(self) -> float:
        """
        The [Fiedler number](https://en.wikipedia.org/wiki/Algebraic_connectivity) of the equivalent undirected graph.

        That is, the second largest eigenvalue of the [Laplacian][trudag.graphalyzer.graph.DirectedAcyclicGraph.laplacian]
        of the graph with adjacency matrix [`self.symmetric_adjacency()`][trudag.graphalyzer.graph.DirectedAcyclicGraph.symmetric_adjacency].
        """

        (values, _) = np.linalg.eigh(self.laplacian())
        values.sort()
        return values[1]

    def is_connected(self) -> bool:
        """
        `true` if the graph is connected.

        Computed algebraically by inspection of the Fiedler number.
        """
        fiedler_number = self.fiedler_number()
        return not (
            np.allclose(fiedler_number, 0.0, atol=ABS_TOL, rtol=REL_TOL)
            or fiedler_number < 0.0
        )

    def _filter_nodes(self, mask: np.ndarray) -> Iterator[tuple[Any, int]]:
        """
        Return an iterator over selected nodes and their matching indices.

        Nodes are included or excluded based on values in the boolean array mask.

        Args:
            mask (np.ndarray): 1-dimensional boolean array, must have length self.size()
        """
        nodes = []
        indices = []

        if mask.ndim != 1 or mask.size != self.size():
            raise ValueError(
                "Mask array must be 1-dimensional with length equal to graph size."
            )

        for selected, node, index in zip(mask, self._nodes, range(0, self.size())):
            if selected:
                nodes.append(node)
                indices.append(index)

        return zip(nodes, indices)

    def leaves(self) -> Iterator[tuple[Any, int]]:
        """
        An iterator over the leaf nodes and their matching indices into the adjacency matrix

        This is equivalent to the set of vertices with zero rows in the adjacency matrix.
        """

        zero_rows = ~self._adjacency.any(axis=1)

        return self._filter_nodes(zero_rows)

    def roots(self) -> Iterator[tuple[Any, int]]:
        """
        An iterator over the root nodes and their matching indices into the adjacency matrix.

        This is eqivalent to the set of vertices with zero columns in the adjacency matrix.
        """
        zero_cols = ~self._adjacency.any(axis=0)

        return self._filter_nodes(zero_cols)

    def nodes(self) -> Iterator[tuple[str, int]]:
        """
        An iterator over the graph's nodes and their matching indices into the adjacency matrix.
        """
        return zip(self._nodes, range(0, self.size()))

    def normalized(self) -> "DirectedAcyclicGraph":
        """
        A copy of the graph with normalized outdegrees.

        This is the graph with the same set of of edges, but with edge weights
        scaled such that the outdegree of all nodes is either `0.0` or `1.0`.
        """
        normalized_adjacency = copy.deepcopy(self._adjacency)
        outdegrees = np.diag(self.outdegree())
        for i, _ in enumerate(normalized_adjacency):
            if outdegrees[i] != 0.0:
                normalized_adjacency[i] /= outdegrees[i]
        return DirectedAcyclicGraph(normalized_adjacency, self._nodes)

    def is_normalized(self) -> bool:
        """
        `true` if the graph has normalized outdegrees, false otherwise.

        A graph has normalized outdegrees if all nodes have an outdegree of either `0.0` or `1.0`.
        """
        outdegrees = np.diag(self.outdegree())

        for entry in outdegrees:
            if not (
                np.allclose(entry, 1.0, atol=ABS_TOL, rtol=REL_TOL)
                or np.allclose(entry, 0.0, atol=ABS_TOL, rtol=REL_TOL)
            ):
                return False
        return True

    def unweighted(self) -> "DirectedAcyclicGraph":
        """
        A copy of the equivalent unweighted graph.

        This is the graph with the same set of of edges, but with all edge weights
        equal to either `0.0` or `1.0`.
        """
        unweighted_adjacency = np.where(self._adjacency, 1.0, 0.0)

        return DirectedAcyclicGraph(unweighted_adjacency, self._nodes)

    def is_unweighted(self) -> bool:
        """
        `true` if the graph is unweighted, false otherwise.

        A graph is unweighted if all the entries of its adjacency matrix are
        either `0.0` or `1.0`.
        """
        for row in self._adjacency:
            for entry in row:
                if entry not in [1.0, 0.0]:
                    return False
        return True

    def reversed(self) -> "DirectedAcyclicGraph":
        """
        A copy of the graph with reversed edge directions.
        """
        return DirectedAcyclicGraph(self._adjacency.transpose(), self._nodes)

    def label_to_index(self, label: str) -> int:
        """
        The integer index into the graph corresponding to the node with label `label`.

        Raises a `ValueError` if no such node exists.

        Args:
            label (str): Label of node to get index for.
        """

        for node, index in self.nodes():
            if str(node) == label:
                return index

        raise ValueError("Cannot provide index for a node that is not in the graph.")
