"""
Support for simple applications of graph theory in python using
adjacency-matrix-backed representations of graphs.
"""

# For floating point comparisons, equality is best defined with reference to a tolerance.
# For Python's double precision floating points, we should expect around 15 digits of precision for "exact" linear algebraic operations
ABS_TOL = 1.0e-15
"""
Absolute error tolerance for all inexact floating point operations.

For the double precision floating point values used by this module, setting this
value smaller than its default `1.0e-15` will result in well-defined but
unhelpful behaviour.
"""
REL_TOL = 1.0e-15
"""
Relative error tolerance for all inexact floating point operations.

For the double precision floating point values used by this module, setting this
value smaller than its default `1.0e-15` will result in well-defined but
unhelpful behaviour.
"""
