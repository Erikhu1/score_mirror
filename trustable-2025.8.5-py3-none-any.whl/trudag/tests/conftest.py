from git import Repo
import pytest
import traceback
import trudag.cli as cli
from trudag.utils import DOTSTOP_DEFAULT_FILENAME
from pathlib import Path
import click.testing
from click.testing import Result


@pytest.fixture
def project_workdir(files, tmp_path) -> Path:
    dot_path = tmp_path / DOTSTOP_DEFAULT_FILENAME
    dot_path.write_text(files["dot_source"])
    for item_name, item_source in files["items_source"].items():
        item_path = tmp_path / Path(item_name + ".md")
        item_path.write_text(item_source)
    return tmp_path


@pytest.fixture
def project_workdir_git(project_workdir, monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("GIT_AUTHOR_EMAIL", "test")
    monkeypatch.setenv("GIT_AUTHOR_NAME", "test")
    monkeypatch.setenv("GIT_COMMITTER_EMAIL", "test")
    monkeypatch.setenv("GIT_COMMITTER_NAME", "test")
    repo = Repo.init()
    repo.git.add(".")
    repo.git.commit(m="test commit")
    with Path(".netrc").open("w") as f:
        f.write("machine example.com login user password pass")

    return tmp_path


@pytest.fixture
def exec_command_in_project(
    project_files, command, tmp_path, monkeypatch, caplog
) -> dict[Path, (Result, list[(str, int, str)])]:
    # we create a sub-directory for the test for each of the project files
    # this can be used in the test cases to execute actions on specific project files.
    tmp_path = tmp_path.joinpath(str(id(project_files)))
    tmp_path.mkdir()
    # create the files in the project
    dot_path = tmp_path / DOTSTOP_DEFAULT_FILENAME
    dot_path.write_text(project_files["dot_source"])
    for item_name, item_source in project_files["items_source"].items():
        item_path = tmp_path / Path(item_name + ".md")
        item_path.write_text(item_source)

    # run the given commands
    # for the git repository info required by some tests, we need a revision
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("GIT_AUTHOR_EMAIL", "test")
    monkeypatch.setenv("GIT_AUTHOR_NAME", "test")
    monkeypatch.setenv("GIT_COMMITTER_EMAIL", "test")
    monkeypatch.setenv("GIT_COMMITTER_NAME", "test")
    repo = Repo.init()
    repo.git.add(".")
    repo.git.commit(m="test commit")
    runner = click.testing.CliRunner()
    result = runner.invoke(cli.main, [*command])
    if result.exception:
        traceback.print_exception(*result.exc_info)
    return (tmp_path, result, caplog.record_tuples)
