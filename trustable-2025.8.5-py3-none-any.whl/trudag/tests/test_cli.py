from typing import Callable
import pytest
import click.testing
import json
import logging
import yaml
import copy
from pathlib import Path
from trudag.dotstop.core.data_store.version import SCHEMA_VERSION
from trudag.error import ExitCodes
from trudag.dotstop.core.graph import LinkStatus, FILE_MARKER
import git

import trudag.cli as cli
import trudag.utils as utils

SUPPORTED_COMMANDS = [
    ["publish"],
    ["plot"],
    ["score"],
    ["manage"],
    ["manage", "lint"],
    ["manage", "migrate"],
    ["manage", "create-item"],
    ["manage", "remove-item"],
    ["manage", "set-item"],
    ["manage", "show-item"],
    ["manage", "create-link"],
    ["manage", "remove-link"],
    ["manage", "set-link"],
    ["manage", "show-link"],
]


empty_project_files = {
    "dot_source": """digraph G {}
    """,
    "items_source": {},
    "expected_scores_csv": lambda: f"""Repository root,{utils.get_root_dir()}
Commit SHA,{utils.get_commit_sha()}
Commit date/time,{utils.get_commit_date()}
Commit tag,{utils.get_last_tag()}
""",
    "expected_scores_json": lambda: {
        "scores": {},
        "info": {
            "Repository root": utils.get_root_dir(),
            "Commit SHA": utils.get_commit_sha(),
            "Commit date/time": utils.get_commit_date(),
            "Commit tag": utils.get_last_tag(),
            "Branch name": utils.get_branch_name(),
            "CI job id": utils.get_ci_job_id(),
            "Schema version": SCHEMA_VERSION,
        },
    },
    "expected_report": lambda: """# Trustable Compliance Report



## Item status guide ## { .subsection }

Each item in a Trustable Graph is scored with a number between 0 and 1.
The score represents aggregated organizational confidence in a given Statement, with larger numbers corresponding to higher confidence.
Scores in the report are indicated by both a numerical score and the colormap below:
<div class="br" style="height: 26px; width: 80%;background: linear-gradient(to right in hsl, hsl(0.0, 100%, 65%) 0%, hsl(120.0, 100%, 30%) 100%);">
<span style="float:right;">1.00&nbsp</span>
<span style="float:left;">&nbsp0.00</span>
</div>


The status of an item and its links also affect the score.

Unreviewed items are indicated by a strikethrough.
The score of unreviewed items is always set to zero.


Suspect links are indicated by italics.
The contribution to the score of a parent item by a suspiciously linked child is always zero, regardless of the child's own score.

"""
    + f"""---

_Generated for: TEST_

* _Repository root: {utils.get_root_dir()}_
* _Commit SHA: {utils.get_commit_sha()}_
* _Commit date/time: {utils.get_commit_date()}_
* _Commit tag: {utils.get_last_tag()}_
""",
    "expected_navigation": """- [Compliance report](trustable_report_for_TEST.md)
- [Dashboard](dashboard.md)
""",
}


"""
Example dot source code and item files for an empty project.
"""

simple_project_files = {
    "dot_source": (
        """digraph G {
        "ROOT-001" [sha="1cfd3f78157e6d24efb274d094dfe7ff829d4184c86e5f8cb8c8243d21f8fdf4"];
        "EVIDENCE-001" [sha="51bff004630ff62f5b5a358a91dcd3886a16281bbeae3351e3615e1bb4b58657"];
        "INTERMEDIATE-001" [sha="890da812aaa60be08197c0dfda860fc5a54838245d0ffd0e5dfc493b9ca85237"];
        "INTERMEDIATE-002"  [sha=f5d5ba0f75e9323c18adb9114485194bb8752f705d37ff82c501b72f0a03304f];
        "INTERMEDIATE-003" [sha=fd740090c729dbead29c6e59b63434451fd2403950616066705dee742c8f3b46];
        "ROOT-001" -> "INTERMEDIATE-001" [sha="27298d4dac7edabeac67c9bbc49f142301c377606ba8dcf46e27f29e6f02918a"];
        "INTERMEDIATE-001" -> "EVIDENCE-001" [sha="55ee1fa200db304fc2144085389f5dd0ed595a4c456c1ad6444bd2ee9135f745"];
    }
        """
    ),
    "items_source": {
        "ROOT-001": (
            """---
            normative: true
            ---

            A Statement about something
            """
        ),
        "INTERMEDIATE-001": (
            """---
            normative: true
            ---

            Some valid reasoning
            """
        ),
        "INTERMEDIATE-002": (
            """---
            normative: true
            ---

            Some more valid reasoning
            """
        ),
        "INTERMEDIATE-003": (
            """---
            normative: true
            ---

            Even more valid reasoning
            """
        ),
        "EVIDENCE-001": (
            """---
            normative: true
            ---

            Some actual basis for my claims
            """
        ),
    },
    "expected_scores_csv": lambda: f"""EVIDENCE-001,0.0
INTERMEDIATE-001,0.0
INTERMEDIATE-002,0.0
INTERMEDIATE-003,0.0
ROOT-001,0.0
Repository root,{utils.get_root_dir()}
Commit SHA,{utils.get_commit_sha()}
Commit date/time,{utils.get_commit_date()}
Commit tag,{utils.get_last_tag()}
""",
    "expected_scores_json": lambda: {
        "scores": [
            {"id": "INTERMEDIATE-002", "score": 0.0},
            {"id": "ROOT-001", "score": 0.0},
            {"id": "INTERMEDIATE-001", "score": 0.0},
            {"id": "EVIDENCE-001", "score": 0.0},
            {"id": "INTERMEDIATE-003", "score": 0.0},
        ],
        "info": {
            "Repository root": utils.get_root_dir(),
            "Commit SHA": utils.get_commit_sha(),
            "Commit date/time": utils.get_commit_date(),
            "Commit tag": utils.get_last_tag(),
            "Branch name": utils.get_branch_name(),
            "CI job id": utils.get_ci_job_id(),
            "Schema version": SCHEMA_VERSION,
        },
    },
    "expected_report": lambda: """# Trustable Compliance Report



## Item status guide ## { .subsection }

Each item in a Trustable Graph is scored with a number between 0 and 1.
The score represents aggregated organizational confidence in a given Statement, with larger numbers corresponding to higher confidence.
Scores in the report are indicated by both a numerical score and the colormap below:
<div class="br" style="height: 26px; width: 80%;background: linear-gradient(to right in hsl, hsl(0.0, 100%, 65%) 0%, hsl(120.0, 100%, 30%) 100%);">
<span style="float:right;">1.00&nbsp</span>
<span style="float:left;">&nbsp0.00</span>
</div>


The status of an item and its links also affect the score.

Unreviewed items are indicated by a strikethrough.
The score of unreviewed items is always set to zero.


Suspect links are indicated by italics.
The contribution to the score of a parent item by a suspiciously linked child is always zero, regardless of the child's own score.
## Compliance for EVIDENCE

| Item   | Summary | Score |
|--------|---------|-------|
| [EVIDENCE-001](EVIDENCE.md#evidence-001) {class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)"}|  Some actual basis for my claims | 0.00 |

## Compliance for INTERMEDIATE

| Item   | Summary | Score |
|--------|---------|-------|
| [INTERMEDIATE-001](INTERMEDIATE.md#intermediate-001) {class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)"}|  Some valid reasoning | 0.00 |
| [INTERMEDIATE-002](INTERMEDIATE.md#intermediate-002) {class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)"}|  Some more valid reasoning | 0.00 |
| [INTERMEDIATE-003](INTERMEDIATE.md#intermediate-003) {class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)"}|  Even more valid reasoning | 0.00 |

## Compliance for ROOT

| Item   | Summary | Score |
|--------|---------|-------|
| [ROOT-001](ROOT.md#root-001) {class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)"}|  A Statement about something | 0.00 |


"""
    + f"""---

_Generated for: TEST_

* _Repository root: {utils.get_root_dir()}_
* _Commit SHA: {utils.get_commit_sha()}_
* _Commit date/time: {utils.get_commit_date()}_
* _Commit tag: {utils.get_last_tag()}_
""",
    "expected_navigation": """- [Compliance report](trustable_report_for_TEST.md)
- [Dashboard](dashboard.md)
* [EVIDENCE-001](EVIDENCE-001.md)
* [EVIDENCE](EVIDENCE.md)
* [INTERMEDIATE-001](INTERMEDIATE-001.md)
* [INTERMEDIATE-002](INTERMEDIATE-002.md)
* [INTERMEDIATE-003](INTERMEDIATE-003.md)
* [INTERMEDIATE](INTERMEDIATE.md)
* [ROOT-001](ROOT-001.md)
* [ROOT](ROOT.md)
""",
}
"""
Example dot source code and item files for a simple project
"""


def util_order_json(obj):
    """
    Helper function to sort nested json objects
    so they can be compared without worrying about the order.
    """
    if isinstance(obj, dict):
        return sorted((k, util_order_json(v)) for k, v in obj.items())
    if isinstance(obj, list):
        return sorted(util_order_json(x) for x in obj)
    return obj


ValidatePickLevelsInner = list[tuple[int | None, int | None]]
ValidatePickLevels = Callable[[list[str]], ValidatePickLevelsInner]


@pytest.fixture
def validate_pick_levels() -> ValidatePickLevels:
    def inner(levels: list[str]) -> ValidatePickLevelsInner:
        results = cli.validate_pick_levels(
            None, None, [("", level) for level in levels]
        )
        return [(result[1], result[2]) for result in results]

    return inner


@pytest.mark.parametrize(
    "command",
    SUPPORTED_COMMANDS,
    ids=[" ".join(command) for command in SUPPORTED_COMMANDS],
)
@pytest.mark.parametrize(
    "files",
    [empty_project_files, simple_project_files],
    ids=["empty project", "simple project"],
)
def test_command_load(command, project_workdir, monkeypatch):
    monkeypatch.chdir(project_workdir)
    runner = click.testing.CliRunner()
    result = runner.invoke(cli.main, [*command, "--help"])
    assert result.exit_code == 0


SCORES_DUMPING_COMMANDS = [
    ["score", "-d"],
    ["publish", "-a", "-n", "TEST", "-o", ".", "-d"],
]


def _get_path_content(path: Path) -> str:
    assert path.exists()
    with path.open() as file:
        path_content = file.read()
    return path_content


def _update_source(project_files, replaceIn, replaceWith, source_type="dot_source"):
    """
    For a given set of test project files, we update the given type of source with the new information.
    This can be useful when we want to modify any part of the test project files for test cases.
    Args:
        project_files: set of test project files
        replaceIn: the part of the source to replace/update
        replaceWith: the new part of the source to be replaced/updated
        source_type: the kind of source, as of yet we have two kinds: dot_source, items_source
    Returns:
        project_files: the newly updated test project files to be used.
    """
    if isinstance(project_files[source_type], dict):
        project_files[source_type][replaceIn] = replaceWith

    if isinstance(project_files[source_type], str):
        project_files[source_type] = project_files[source_type].replace(
            replaceIn, replaceWith
        )
    return project_files


@pytest.mark.parametrize(
    "command",
    [command + ["scores.csv"] for command in SCORES_DUMPING_COMMANDS],
    ids=[" ".join(command) + " scores.csv" for command in SCORES_DUMPING_COMMANDS],
)
@pytest.mark.parametrize(
    "project_files",
    [empty_project_files, simple_project_files],
    ids=["empty project", "simple project"],
)
def test_scores_dumping_csv(exec_command_in_project, project_files):
    project_path, command_result, _ = exec_command_in_project
    assert command_result.exit_code == 0
    dumped_scores_csv = _get_path_content(project_path.joinpath("scores.csv"))
    expected_scores_csv = project_files["expected_scores_csv"]()

    assert dumped_scores_csv != ""
    assert dumped_scores_csv == expected_scores_csv


@pytest.mark.parametrize(
    "command",
    [command + ["scores.json"] for command in SCORES_DUMPING_COMMANDS],
    ids=[" ".join(command) + " scores.json" for command in SCORES_DUMPING_COMMANDS],
)
@pytest.mark.parametrize(
    "project_files",
    [empty_project_files, simple_project_files],
    ids=["empty project", "simple project"],
)
def test_scores_dumping_json(project_files, exec_command_in_project):
    project_path, command_result, _ = exec_command_in_project
    assert command_result.exit_code == 0
    dumped_scores_json = json.loads(
        _get_path_content(project_path.joinpath("scores.json"))
    )
    expected_scores_json = project_files["expected_scores_json"]()
    assert dumped_scores_json != ""
    assert util_order_json(dumped_scores_json) == util_order_json(expected_scores_json)


@pytest.mark.parametrize(
    "command",
    [command + ["invalid_file_name"] for command in SCORES_DUMPING_COMMANDS],
    ids=[
        " ".join(command) + " invalid_file_name" for command in SCORES_DUMPING_COMMANDS
    ],
)
@pytest.mark.parametrize(
    "project_files",
    [empty_project_files, simple_project_files],
    ids=["empty project", "simple project"],
)
def test_scores_dumping_failure(exec_command_in_project):
    project_path, command_result, command_log = exec_command_in_project
    assert command_result.exit_code == 0
    # We test if we fail correctly (If we pass a dump file without any extension)
    expected_error_log = (
        "trudag.utils",
        logging.ERROR,
        "Cannot dump scores, file extension '' is not supported.",
    )
    assert expected_error_log in command_log


@pytest.mark.parametrize("command", [["manage", "remove-item", "INTERMEDIATE-001"]])
@pytest.mark.parametrize("project_files", [simple_project_files])
def test_remove_item(exec_command_in_project):
    project_path, command_result, _ = exec_command_in_project
    assert command_result.exit_code == 0

    dotfile = _get_path_content(project_path / utils.DOTSTOP_DEFAULT_FILENAME)
    assert (
        dotfile.removeprefix(FILE_MARKER)
        == """digraph G {
"ROOT-001" [sha="1cfd3f78157e6d24efb274d094dfe7ff829d4184c86e5f8cb8c8243d21f8fdf4"];
"EVIDENCE-001" [sha="51bff004630ff62f5b5a358a91dcd3886a16281bbeae3351e3615e1bb4b58657"];
"INTERMEDIATE-002" [sha=f5d5ba0f75e9323c18adb9114485194bb8752f705d37ff82c501b72f0a03304f];
"INTERMEDIATE-003" [sha=fd740090c729dbead29c6e59b63434451fd2403950616066705dee742c8f3b46];
}
"""
    )


@pytest.mark.parametrize(
    "command", [["manage", "remove-link", "ROOT-001", "INTERMEDIATE-001"]]
)
@pytest.mark.parametrize("project_files", [simple_project_files])
def test_remove_link(exec_command_in_project):
    project_path, command_result, _ = exec_command_in_project
    assert command_result.exit_code == 0

    dotfile = _get_path_content(project_path / utils.DOTSTOP_DEFAULT_FILENAME)
    # strip comments and compare
    assert dotfile.removeprefix(FILE_MARKER) == (
        """digraph G {
"ROOT-001" [sha="1cfd3f78157e6d24efb274d094dfe7ff829d4184c86e5f8cb8c8243d21f8fdf4"];
"EVIDENCE-001" [sha="51bff004630ff62f5b5a358a91dcd3886a16281bbeae3351e3615e1bb4b58657"];
"INTERMEDIATE-001" [sha="890da812aaa60be08197c0dfda860fc5a54838245d0ffd0e5dfc493b9ca85237"];
"INTERMEDIATE-002" [sha=f5d5ba0f75e9323c18adb9114485194bb8752f705d37ff82c501b72f0a03304f];
"INTERMEDIATE-003" [sha=fd740090c729dbead29c6e59b63434451fd2403950616066705dee742c8f3b46];
"INTERMEDIATE-001" -> "EVIDENCE-001" [sha="55ee1fa200db304fc2144085389f5dd0ed595a4c456c1ad6444bd2ee9135f745"];
}
"""
    )


@pytest.mark.parametrize(
    "command", [["manage", "create-link", "ROOT-001", "INTERMEDIATE-002"]]
)
@pytest.mark.parametrize("project_files", [simple_project_files])
def test_create_link(exec_command_in_project):
    project_path, command_result, _ = exec_command_in_project
    assert command_result.exit_code == 0

    dotfile = _get_path_content(project_path / utils.DOTSTOP_DEFAULT_FILENAME)
    # strip comments and compare
    assert dotfile.removeprefix(FILE_MARKER) == (
        """digraph G {
"ROOT-001" [sha="1cfd3f78157e6d24efb274d094dfe7ff829d4184c86e5f8cb8c8243d21f8fdf4"];
"EVIDENCE-001" [sha="51bff004630ff62f5b5a358a91dcd3886a16281bbeae3351e3615e1bb4b58657"];
"INTERMEDIATE-001" [sha="890da812aaa60be08197c0dfda860fc5a54838245d0ffd0e5dfc493b9ca85237"];
"INTERMEDIATE-002" [sha=f5d5ba0f75e9323c18adb9114485194bb8752f705d37ff82c501b72f0a03304f];
"INTERMEDIATE-003" [sha=fd740090c729dbead29c6e59b63434451fd2403950616066705dee742c8f3b46];
"ROOT-001" -> "INTERMEDIATE-001" [sha="27298d4dac7edabeac67c9bbc49f142301c377606ba8dcf46e27f29e6f02918a"];
"ROOT-001" -> "INTERMEDIATE-002" [sha="906f15bffbe3e9f38f0059e15e06f99fb2d70f65a09ebad23b2b3a9cc86fe63a"];
"INTERMEDIATE-001" -> "EVIDENCE-001" [sha="55ee1fa200db304fc2144085389f5dd0ed595a4c456c1ad6444bd2ee9135f745"];
}
"""
    )


REPORT_COMMAND = [
    ["publish", "-a", "-n", "TEST", "-o", "."],
]


@pytest.mark.parametrize(
    "command",
    REPORT_COMMAND,
    ids=[" ".join(command) for command in REPORT_COMMAND],
)
@pytest.mark.parametrize(
    "project_files",
    [empty_project_files, simple_project_files],
    ids=["empty project", "simple project"],
)
def test_generated_report(project_files, exec_command_in_project):
    project_path, command_result, command_output = exec_command_in_project
    assert command_result.exit_code == 0
    actual_report = project_path.joinpath("trustable_report_for_TEST.md").read_text()
    assert project_files["expected_report"]() == actual_report


@pytest.mark.parametrize(
    "project_files",
    [empty_project_files, simple_project_files],
    ids=["empty project", "simple project"],
)
@pytest.mark.parametrize(
    "command",
    REPORT_COMMAND,
    ids=[" ".join(command) for command in REPORT_COMMAND],
)
def test_generated_nav(project_files, exec_command_in_project):
    project_path, command_result, _ = exec_command_in_project
    assert command_result.exit_code == 0
    actual_navigation = project_path.joinpath("nav.md").read_text()
    assert project_files["expected_navigation"] == actual_navigation


@pytest.mark.parametrize(
    "project_files",
    [empty_project_files, simple_project_files],
    ids=["empty project", "simple project"],
)
@pytest.mark.parametrize(
    "command",
    [["manage", "lint", "--fail-on-error"]],
    ids=["manage lint --fail-on-error"],
)
def test_valid_lint(exec_command_in_project, project_files):
    project_path, command_result, _ = exec_command_in_project
    assert command_result.exit_code == 0


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
    ids=["simple project"],
)
def test_lint_unreviewed_item_failure(project_workdir, monkeypatch, caplog):
    monkeypatch.chdir(project_workdir)
    runner = click.testing.CliRunner()
    dotfile_path = Path(project_workdir / utils.DOTSTOP_DEFAULT_FILENAME)
    dotfile_content = dotfile_path.read_text()
    # we make the item ROOT-001 unreviewed for the lint to fail
    dotfile_path.write_text(
        dotfile_content.replace(
            '"ROOT-001" [sha="1cfd3f78157e6d24efb274d094dfe7ff829d4184c86e5f8cb8c8243d21f8fdf4"];',
            '"ROOT-001";',
        )
    )

    result = runner.invoke(cli.main, ["manage", "lint", "--fail-on-error"])
    assert result.exit_code == ExitCodes.LINT_FAILURE
    expected_error_log = (
        "trudag.manage",
        logging.WARNING,
        "Unreviewed Item: ROOT-001",
    )

    assert expected_error_log in caplog.record_tuples


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
    ids=["simple project"],
)
def test_lint_link_status_failure(project_workdir, monkeypatch, caplog):
    monkeypatch.chdir(project_workdir)
    runner = click.testing.CliRunner()
    dotfile_path = Path(project_workdir / utils.DOTSTOP_DEFAULT_FILENAME)
    dotfile_content = dotfile_path.read_text()
    # we make the link suspect for the lint to fail
    dotfile_path.write_text(
        dotfile_content.replace(
            '"ROOT-001" -> "INTERMEDIATE-001" [sha="27298d4dac7edabeac67c9bbc49f142301c377606ba8dcf46e27f29e6f02918a"];',
            '"ROOT-001" -> "INTERMEDIATE-001";',
        )
    )

    result = runner.invoke(cli.main, ["manage", "lint", "--fail-on-error"])
    assert result.exit_code == ExitCodes.LINT_FAILURE
    expected_error_log = (
        "trudag.manage",
        logging.WARNING,
        "Suspect Link: ROOT-001 -> INTERMEDIATE-001",
    )

    assert expected_error_log in caplog.record_tuples


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
    ids=["simple project"],
)
def test_lint_json_dump(project_workdir, monkeypatch, caplog):
    monkeypatch.chdir(project_workdir)
    runner = click.testing.CliRunner()
    root_001_path = Path(project_workdir / "ROOT-001.md")
    root_001_content = root_001_path.read_text()
    # item ROOT-001 unreviewed and suspect link
    root_001_path.write_text(
        root_001_content.replace(
            "A Statement about something",
            "A Statement that has changed",
        )
    )

    result = runner.invoke(
        cli.main, ["manage", "lint", "--dump", "out.json", "--fail-on-error"]
    )
    assert result.exit_code == ExitCodes.LINT_FAILURE
    expected_error_log = (
        "trudag.manage",
        logging.WARNING,
        "Unreviewed Item: ROOT-001",
    )

    assert expected_error_log in caplog.record_tuples

    expected_error_log = (
        "trudag.manage",
        logging.WARNING,
        "Suspect Link: ROOT-001 -> INTERMEDIATE-001",
    )

    assert expected_error_log in caplog.record_tuples

    json_dump = project_workdir / "out.json"
    assert json_dump.is_file()

    json_dump_contents: object = None
    with json_dump.open("r") as file:
        json_dump_contents = json.load(file)

    assert json_dump_contents == {
        "unreviewed_items": ["ROOT-001"],
        "suspect_links": [{"parent": "ROOT-001", "child": "INTERMEDIATE-001"}],
    }


@pytest.mark.parametrize(
    "project_files",
    [empty_project_files, simple_project_files],
    ids=["empty project", "simple project"],
)
@pytest.mark.parametrize(
    "command",
    [["manage", "create-item", "TT", "TESTING", "./"]],
    ids=[" ".join(command) for command in REPORT_COMMAND],
)
def test_create_new_item(exec_command_in_project):
    project_path, command_result, _ = exec_command_in_project
    assert command_result.exit_code == 0
    item_path = Path(project_path / "TT-TESTING.md")
    assert item_path.is_file()
    assert yaml.safe_load((item_path.read_text().split("---\n")[1]))


invalid_scores_simple_project_files = copy.deepcopy(simple_project_files)

invalid_scores_simple_project_files = _update_source(
    invalid_scores_simple_project_files,
    "EVIDENCE-001",
    """---
normative: true
score: 0.1
---

Some actual basis for my claims
""",
    "items_source",
)


@pytest.mark.parametrize("command", [["score"]])
@pytest.mark.parametrize(
    "project_files",
    [
        _update_source(
            _update_source(
                invalid_scores_simple_project_files,
                '"EVIDENCE-001" [sha="51bff004630ff62f5b5a358a91dcd3886a16281bbeae3351e3615e1bb4b58657"]',
                '"EVIDENCE-001" [sha="941e887f3f05a4739d61e5d9536cf21d2ef27a60373161cc4736a59470c326b0"]',
            ),
            '"INTERMEDIATE-001" -> "EVIDENCE-001" [sha="55ee1fa200db304fc2144085389f5dd0ed595a4c456c1ad6444bd2ee9135f745"]',
            '"INTERMEDIATE-001" -> "EVIDENCE-001" [sha="f90646e9cc57fb8aa2d9f6f395c7c1c3508eb63b6b20ea025668a384e6789771"]',
        )
    ],
)
def test_invalid_scores(exec_command_in_project):
    project_path, command_result, command_log = exec_command_in_project
    assert command_result.exit_code == 0
    expected_warning_log = (
        "trudag.score",
        logging.WARNING,
        "Score provided for Item EVIDENCE-001 is invalid, no validator or artifact provided for the score. Score set to zero.",
    )
    assert expected_warning_log in command_log


links_project_files = copy.deepcopy(simple_project_files)
links_project_files = _update_source(
    links_project_files,
    '"INTERMEDIATE-001" -> "EVIDENCE-001" [sha="55ee1fa200db304fc2144085389f5dd0ed595a4c456c1ad6444bd2ee9135f745"]',
    '"INTERMEDIATE-001" -> "EVIDENCE-001"',
)


@pytest.mark.parametrize(
    "command", [["manage", "show-link", "INTERMEDIATE-001", "INTERMEDIATE-002"]]
)
@pytest.mark.parametrize(
    "project_files",
    [links_project_files],
)
def test_unlinked_link(exec_command_in_project):
    project_path, command_result, command_log = exec_command_in_project
    assert command_result.exit_code == 0
    assert str(LinkStatus.UNLINKED) in command_result.stdout


@pytest.mark.parametrize(
    "command", [["manage", "show-link", "INTERMEDIATE-001", "EVIDENCE-001"]]
)
@pytest.mark.parametrize("project_files", [links_project_files])
def test_suspect_link(exec_command_in_project):
    project_path, command_result, command_log = exec_command_in_project
    assert command_result.exit_code == 0
    assert str(LinkStatus.SUSPECT) in command_result.stdout


@pytest.mark.parametrize(
    "command", [["manage", "show-link", "ROOT-001", "INTERMEDIATE-001"]]
)
@pytest.mark.parametrize("project_files", [links_project_files])
def test_linked_link(exec_command_in_project):
    project_path, command_result, command_log = exec_command_in_project
    assert command_result.exit_code == 0
    assert str(LinkStatus.LINKED) in command_result.stdout


def test_validate_pick_levels_full(validate_pick_levels: ValidatePickLevels):
    assert validate_pick_levels(["1:2"]) == [(1, 2)]


def test_validate_pick_levels_select_all(validate_pick_levels: ValidatePickLevels):
    assert validate_pick_levels(["1:"]) == [(1, None)]
    assert validate_pick_levels([":2"]) == [(None, 2)]
    assert validate_pick_levels([":"]) == [(None, None)]


def test_validate_pick_levels_fail_not_int(validate_pick_levels: ValidatePickLevels):
    with pytest.raises(click.BadParameter):
        _ = validate_pick_levels(["1:badarg"])
    with pytest.raises(click.BadParameter):
        _ = validate_pick_levels(["badarg:1"])
    with pytest.raises(click.BadParameter):
        _ = validate_pick_levels(["1:2:3"])


def test_validate_pick_levels_fail_no_separator(
    validate_pick_levels: ValidatePickLevels,
):
    with pytest.raises(click.BadParameter):
        _ = validate_pick_levels(["1 2"])
    with pytest.raises(click.BadParameter):
        _ = validate_pick_levels([""])


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
    ids=["simple project"],
)
def test_lint_diff_missing_branch(project_workdir, monkeypatch, caplog):
    monkeypatch.chdir(project_workdir)
    git.Repo.init(project_workdir)
    runner = click.testing.CliRunner()
    result = runner.invoke(cli.main, ["manage", "lint", "--diff", "foo"])

    assert result.exit_code == 1
    expected_error_log = (
        "trudag.utils",
        logging.CRITICAL,
        "Failed to find target branch",
    )
    assert expected_error_log in caplog.record_tuples


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
    ids=["simple project"],
)
def test_lint_diff_missing_dotstop_from_branch(project_workdir, monkeypatch, caplog):
    monkeypatch.chdir(project_workdir)
    repo = git.Repo.init(project_workdir)
    commit = repo.index.commit("empty")
    runner = click.testing.CliRunner()
    result = runner.invoke(cli.main, ["manage", "lint", "--diff", commit.hexsha])

    assert result.exit_code == 1
    expected_error_log = (
        "trudag.utils",
        logging.CRITICAL,
        "Failed to find .dotstop.dot in the target branch",
    )
    assert expected_error_log in caplog.record_tuples


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
    ids=["simple project"],
)
def test_lint_diff_dirty(project_workdir, monkeypatch, caplog):
    monkeypatch.chdir(project_workdir)

    dirty_path = Path("dirty.txt")
    dirty_path.write_text("this is not dirty")

    repo = git.Repo.init(project_workdir)
    repo.index.add(["*", ".dotstop.dot"])
    commit = repo.index.commit("initial")

    dirty_content = "this is dirty"
    dirty_path.write_text(dirty_content)

    runner = click.testing.CliRunner()
    result = runner.invoke(
        cli.main, ["manage", "lint", "--fail-on-error", "--diff", commit.hexsha]
    )

    assert result.exit_code == ExitCodes.SUCCESS
    expected_error_log = (
        "trudag.manage",
        logging.WARNING,
        "Stashing dirty changes before checking out branch, ensure uncommited files are restored from stash",
    )
    assert expected_error_log in caplog.record_tuples
    expected_error_log = (
        "trudag.manage",
        logging.INFO,
        "restored uncommited git changes",
    )
    assert expected_error_log in caplog.record_tuples

    assert dirty_path.is_file()
    assert dirty_path.read_text() == dirty_content
