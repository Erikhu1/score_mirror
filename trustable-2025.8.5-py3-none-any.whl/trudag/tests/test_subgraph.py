import pytest

from trudag.dotstop.core.exception import InvalidArgumentError
from trudag.dotstop.core.graph import LinkStatus, TrustableGraph, build_trustable_graph
from trudag.dotstop.core.item import BaseItem
from trudag.dotstop.tests import FakeItem
from trudag.plot import build_subgraph


@pytest.fixture
def graph() -> TrustableGraph:
    """
    Generates and returns a `TrustableGraph` for testing.

    The following generates the following graph:

                                     ITEM-1-ROOT
                                      |       |
                              ITEM-2-1        ITEM-2-2
                                |                    |
                    _____________                    ________________
                   |             |                  |                |
           ITEM-3-1          ITEM-3-2            ITEM-3-3            ITEM-3-4
           |      |          |      |            |      |            |      |
    ITEM-4-1  ITEM-4-2  ITEM-4-3  ITEM-4-4  ITEM-4-5  ITEM-4-6  ITEM-4-7  ITEM-4-8
    """

    items: list[BaseItem] = [
        FakeItem({"name": "ITEM-1-ROOT"}),
        FakeItem({"name": "ITEM-2-1"}),
        FakeItem({"name": "ITEM-2-2"}),
        FakeItem({"name": "ITEM-3-1"}),
        FakeItem({"name": "ITEM-3-2"}),
        FakeItem({"name": "ITEM-3-3"}),
        FakeItem({"name": "ITEM-3-4"}),
        FakeItem({"name": "ITEM-4-1"}),
        FakeItem({"name": "ITEM-4-2"}),
        FakeItem({"name": "ITEM-4-3"}),
        FakeItem({"name": "ITEM-4-4"}),
        FakeItem({"name": "ITEM-4-5"}),
        FakeItem({"name": "ITEM-4-6"}),
        FakeItem({"name": "ITEM-4-7"}),
        FakeItem({"name": "ITEM-4-8"}),
    ]
    dot = """digraph G {
        "ITEM-1-ROOT"
        "ITEM-2-1"
        "ITEM-2-2"
        "ITEM-3-1"
        "ITEM-3-2"
        "ITEM-3-3"
        "ITEM-3-4"
        "ITEM-4-1"
        "ITEM-4-2"
        "ITEM-4-3"
        "ITEM-4-4"
        "ITEM-4-5"
        "ITEM-4-6"
        "ITEM-4-7"
        "ITEM-4-8"
        "ITEM-1-ROOT" -> "ITEM-2-1"
        "ITEM-1-ROOT" -> "ITEM-2-2"
        "ITEM-2-1" -> "ITEM-3-1"
        "ITEM-2-1" -> "ITEM-3-2"
        "ITEM-2-2" -> "ITEM-3-3"
        "ITEM-2-2" -> "ITEM-3-4"
        "ITEM-3-1" -> "ITEM-4-1"
        "ITEM-3-1" -> "ITEM-4-2"
        "ITEM-3-2" -> "ITEM-4-3"
        "ITEM-3-2" -> "ITEM-4-4"
        "ITEM-3-3" -> "ITEM-4-5"
        "ITEM-3-3" -> "ITEM-4-6"
        "ITEM-3-4" -> "ITEM-4-7"
        "ITEM-3-4" -> "ITEM-4-8"
        }
    """

    return build_trustable_graph(graph_source=dot, items_source=items)


def test_orphan_nodes_filter(graph: TrustableGraph) -> None:
    """
    Tests orphan nodes filter.
    """

    orphan_node_items: list[BaseItem] = [
        FakeItem({"name": "ORPHAN-NODE"}),
        FakeItem({"name": "ORPHAN-NODE2"}),
        FakeItem({"name": "ORPHAN-NODE3"}),
    ]
    graph.add_items(orphan_node_items)

    initial_count = len(graph.items)
    removed_count = build_subgraph(graph, [], True)

    assert removed_count == initial_count - len(orphan_node_items)
    assert len(graph.items) == len(orphan_node_items)

    for item in orphan_node_items:
        assert _no_parents(graph, item.name)
        assert _no_children(graph, item.name)


def test_root_levels_0(graph: TrustableGraph) -> None:
    """
    Tests root filtering with both levels of 0.
    """

    initial_count = len(graph.items)
    removed_count = build_subgraph(graph, [("ITEM-2-1", 0, 0)], False)

    # calculation results in remaining count (current number of items)
    assert initial_count - removed_count == 1
    assert initial_count - removed_count == len(graph.items)

    assert _no_parents(graph, "ITEM-2-1")
    assert _no_children(graph, "ITEM-2-1")


def test_root_child_level_1(graph: TrustableGraph) -> None:
    """
    Tests root filtering with child level of 1.
    There are two roots selected here and they do not intersect.
    """

    initial_count = len(graph.items)
    removed_count = build_subgraph(
        graph, [("ITEM-2-1", 0, 1), ("ITEM-3-3", 0, 1)], False
    )

    # calculation results in remaining count (current number of items)
    assert initial_count - removed_count == 6
    assert initial_count - removed_count == len(graph.items)

    # ITEM-2-1 root
    assert _suspect(graph, "ITEM-2-1", "ITEM-3-1")
    assert _suspect(graph, "ITEM-2-1", "ITEM-3-2")
    assert _no_parents(graph, "ITEM-2-1")
    assert _no_children(graph, "ITEM-3-1")
    assert _no_children(graph, "ITEM-3-2")

    # ITEM-3-3 root
    assert _suspect(graph, "ITEM-3-3", "ITEM-4-5")
    assert _suspect(graph, "ITEM-3-3", "ITEM-4-6")
    assert _no_parents(graph, "ITEM-3-3")
    assert _no_children(graph, "ITEM-4-5")
    assert _no_children(graph, "ITEM-4-6")


def test_root_parent_level_1(graph: TrustableGraph) -> None:
    """
    Tests root filtering with parent level of 1.
    There are two roots selected here and they do not intersect.
    """

    initial_count = len(graph.items)
    removed_count = build_subgraph(
        graph, [("ITEM-2-1", 1, 0), ("ITEM-3-3", 1, 0)], False
    )

    # calculation results in remaining count (current number of items)
    assert initial_count - removed_count == 4
    assert initial_count - removed_count == len(graph.items)

    # ITEM-2-1 root
    assert _suspect(graph, "ITEM-1-ROOT", "ITEM-2-1")
    assert _no_parents(graph, "ITEM-1-ROOT")
    assert _no_children(graph, "ITEM-2-1")

    # ITEM-3-3 root
    assert _suspect(graph, "ITEM-2-2", "ITEM-3-3")
    assert _suspect(graph, "ITEM-1-ROOT", "ITEM-2-2")
    assert _no_children(graph, "ITEM-3-3")


def test_root_child_level_1_intersect(graph: TrustableGraph) -> None:
    """
    Tests root filtering with child level of 1.
    There are two roots selected here and they intersect.
    """

    initial_count = len(graph.items)
    removed_count = build_subgraph(
        graph, [("ITEM-2-1", 0, 1), ("ITEM-3-2", 0, 1)], False
    )

    # calculation results in remaining count (current number of items)
    assert initial_count - removed_count == 5
    assert initial_count - removed_count == len(graph.items)

    # ITEM-2-1 root
    assert _suspect(graph, "ITEM-2-1", "ITEM-3-1")
    assert _suspect(graph, "ITEM-2-1", "ITEM-3-2")
    assert _no_children(graph, "ITEM-3-1")
    assert len(graph.get_item_children("ITEM-3-2")) == 2

    # ITEM-3-2 root
    assert _suspect(graph, "ITEM-3-2", "ITEM-4-3")
    assert _suspect(graph, "ITEM-3-2", "ITEM-4-4")

    assert _suspect(graph, "ITEM-2-1", "ITEM-3-2")
    assert len(graph.get_item_parents("ITEM-3-2")) == 1

    assert _suspect(graph, "ITEM-2-1", "ITEM-3-2")


def test_root_child_level_2(graph: TrustableGraph) -> None:
    """
    Tests root filtering with parent level of 2.
    This picks one root.
    """

    initial_count = len(graph.items)
    removed_count = build_subgraph(graph, [("ITEM-4-2", 2, 0)], False)

    # calculation results in remaining count (current number of items)
    assert initial_count - removed_count == 3
    assert initial_count - removed_count == len(graph.items)

    assert _suspect(graph, "ITEM-3-1", "ITEM-4-2")
    assert _suspect(graph, "ITEM-2-1", "ITEM-3-1")
    assert _no_children(graph, "ITEM-4-2")
    assert _no_parents(graph, "ITEM-2-1")


def test_root_child_level_2_same_root(graph: TrustableGraph) -> None:
    """
    Tests root filtering with child level of 2.
    Uses same root as before the filtering.
    """

    initial_count = len(graph.items)
    removed_count = build_subgraph(graph, [("ITEM-1-ROOT", 0, 2)], False)

    # calculation results in remaining count (current number of items)
    assert initial_count - removed_count == 7
    assert initial_count - removed_count == len(graph.items)

    assert _suspect(graph, "ITEM-1-ROOT", "ITEM-2-1")
    assert _suspect(graph, "ITEM-1-ROOT", "ITEM-2-2")
    assert _suspect(graph, "ITEM-2-1", "ITEM-3-1")
    assert _suspect(graph, "ITEM-2-1", "ITEM-3-2")
    assert _suspect(graph, "ITEM-2-2", "ITEM-3-3")
    assert _suspect(graph, "ITEM-2-2", "ITEM-3-4")
    assert _no_children(graph, "ITEM-3-1")
    assert _no_children(graph, "ITEM-3-2")
    assert _no_children(graph, "ITEM-3-3")
    assert _no_children(graph, "ITEM-3-4")
    assert _no_parents(graph, "ITEM-1-ROOT")


def test_root_parent_level_same_root(graph: TrustableGraph) -> None:
    """
    Tests root filtering with parent level of 2.
    Uses same root as before the filtering.
    """

    initial_count = len(graph.items)
    removed_count = build_subgraph(graph, [("ITEM-1-ROOT", 2, 0)], False)

    # calculation results in remaining count (current number of items)
    assert initial_count - removed_count == 1
    assert initial_count - removed_count == len(graph.items)

    assert _no_children(graph, "ITEM-1-ROOT")
    assert _no_parents(graph, "ITEM-1-ROOT")


def test_root_child_level_excessive(graph: TrustableGraph) -> None:
    """
    Tests filtering by root with more than enough child levels to cover the entire graph.
    """

    initial_count = len(graph.items)
    removed_count = build_subgraph(graph, [("ITEM-2-1", 0, 1000)], False)

    # calculation results in remaining count (current number of items)
    assert initial_count - removed_count == 7
    assert initial_count - removed_count == len(graph.items)

    assert _suspect(graph, "ITEM-2-1", "ITEM-3-1")
    assert _suspect(graph, "ITEM-2-1", "ITEM-3-2")
    assert _suspect(graph, "ITEM-3-1", "ITEM-4-1")
    assert _suspect(graph, "ITEM-3-1", "ITEM-4-2")
    assert _suspect(graph, "ITEM-3-2", "ITEM-4-3")
    assert _suspect(graph, "ITEM-3-2", "ITEM-4-4")
    assert _no_children(graph, "ITEM-4-1")
    assert _no_children(graph, "ITEM-4-2")
    assert _no_children(graph, "ITEM-4-3")
    assert _no_children(graph, "ITEM-4-4")
    assert _no_parents(graph, "ITEM-2-1")


def test_orphan_nodes_and_root(graph: TrustableGraph) -> None:
    """
    Tests combining orphan nodes and root filtering.
    """

    orphan_node_items: list[BaseItem] = [
        FakeItem({"name": "ORPHAN-NODE"}),
        FakeItem({"name": "ORPHAN-NODE2"}),
        FakeItem({"name": "ORPHAN-NODE3"}),
    ]
    graph.add_items(orphan_node_items)

    initial_count = len(graph.items)
    removed_count = build_subgraph(graph, [("ITEM-2-1", 1, 1)], True)

    # 3 orphan nodes, 1 from new root parents, 3 from new root children
    assert initial_count - removed_count == 3 + 1 + 3
    assert initial_count - removed_count == len(graph.items)

    for item in orphan_node_items:
        assert _no_parents(graph, item.name)
        assert _no_children(graph, item.name)

    # ITEM-2-1 root
    assert _suspect(graph, "ITEM-2-1", "ITEM-3-1")
    assert _suspect(graph, "ITEM-2-1", "ITEM-3-2")
    assert _suspect(graph, "ITEM-1-ROOT", "ITEM-2-1")
    assert _no_parents(graph, "ITEM-1-ROOT")
    assert _no_children(graph, "ITEM-3-1")
    assert _no_children(graph, "ITEM-3-2")


def test_all_parents(graph: TrustableGraph) -> None:
    """
    Tests selecting all levels of parents
    """
    initial_count = len(graph.items)
    removed_count = build_subgraph(graph, [("ITEM-3-2", None, 0)], False)

    # calculation results in remaining count (current number of items)
    assert initial_count - removed_count == 3
    assert initial_count - removed_count == len(graph.items)

    assert _suspect(graph, "ITEM-2-1", "ITEM-3-2")
    assert _suspect(graph, "ITEM-1-ROOT", "ITEM-2-1")
    assert _no_children(graph, "ITEM-3-2")
    assert _no_parents(graph, "ITEM-1-ROOT")


def test_all_children(graph: TrustableGraph) -> None:
    """
    Tests selecting all levels of children
    """
    initial_count = len(graph.items)
    removed_count = build_subgraph(graph, [("ITEM-2-1", 0, None)], False)

    # calculation results in remaining count (current number of items)
    assert initial_count - removed_count == 7
    assert initial_count - removed_count == len(graph.items)

    assert _suspect(graph, "ITEM-2-1", "ITEM-3-1")
    assert _suspect(graph, "ITEM-2-1", "ITEM-3-2")
    assert _suspect(graph, "ITEM-3-1", "ITEM-4-1")
    assert _suspect(graph, "ITEM-3-1", "ITEM-4-2")
    assert _suspect(graph, "ITEM-3-2", "ITEM-4-3")
    assert _suspect(graph, "ITEM-3-2", "ITEM-4-4")
    assert _no_children(graph, "ITEM-4-1")
    assert _no_children(graph, "ITEM-4-2")
    assert _no_children(graph, "ITEM-4-3")
    assert _no_children(graph, "ITEM-4-4")
    assert _no_parents(graph, "ITEM-2-1")


def test_root_level_invalid(graph: TrustableGraph) -> None:
    """
    Tests invalid depth value.
    """

    with pytest.raises(InvalidArgumentError):
        _ = build_subgraph(graph, [("ITEM-2-1", 0, 0), ("ITEM-3-2", 0, -1)], False)

    with pytest.raises(InvalidArgumentError):
        _ = build_subgraph(graph, [("ITEM-2-1", 0, 0), ("ITEM-3-2", -1, 0)], False)


def _no_children(graph: TrustableGraph, item: str) -> bool:
    return not graph.get_item_children(item)


def _no_parents(graph: TrustableGraph, item: str) -> bool:
    return not graph.get_item_parents(item)


def _suspect(graph: TrustableGraph, parent: str, child: str) -> bool:
    return graph.get_link_status(parent, child) == LinkStatus.SUSPECT
