import pytest
import pathlib
import logging
import copy
from trudag import manage, dotstop
from trudag.error import ExitCodes
from trudag.dotstop.tests import FakeItem
from trudag.dotstop.core.graph import TrustableGraph, build_trustable_graph
from colorama import Fore, Style


@pytest.fixture
def example_reference(tmp_path: pathlib.Path) -> str:
    """
    A named temporary reference file in './files/'.
    """
    reference_path = tmp_path / "phonebook.txt"
    with reference_path.open("w", encoding="utf-8") as reference_file:
        reference_file.write("Alice: 0800 00 1066")
    return reference_path.as_posix()


@pytest.fixture
def example_workspace(example_reference: str) -> dict:
    r"""
    Example `graph`, included in a dictionary together with its component parts
    and a path to a reference.


                                ┌─────┐
                             ┌──│EXP-1├──┐
                             │  └─────┘  │
                             │           │
                             │           │
                          ┌──▼──┐     ┌──▼──┐
           ┌───────────┬──┤ASN-1├─┐ ┌─┤ASN-2├──┐
           │           │  └─────┘ │ │ └─────┘  │
           │           │          │ │          │
           │           │          │ │          │
        ┌──▼──┐     ┌──▼──┐     ┌─▼─▼─┐     ┌──▼──┐
        │TST-1│     │TST-2│     │DOC-1│     │TST-3│
        └─────┘     └─────┘     └─────┘     └─────┘


    All links are suspect, and all items unreviewed, except:
    - ASN-1
    - DOC-1
    - ASN-1 -> DOC-1
    - EXP-1 -> ASN-1
    """

    items = [
        FakeItem(obj_dict)
        for obj_dict in [
            {
                "name": "EXP-1",
                "text": "Bob and Alice know each other",
            },
            {
                "name": "ASN-CONTEXT",
                "text": "To work out if Alice and Bob know each other we consider each person in turn.",
                "normative": False,
                "score": {"SME Engineer": 0.5},
            },
            {
                "name": "ASN-1",
                "text": "Alice knows Bob",
                "fallacies": {
                    "MISTAKEN": dotstop.Fallacy(
                        "Alice is mistaken",
                        dotstop.LocalFileReference(example_reference),
                    )
                },
            },
            {
                "name": "ASN-2",
                "text": "Bob knows Alice",
            },
            {
                "name": "TST-1",
                "text": "Alice can recognize Bob",
            },
            {
                "name": "TST-2",
                "text": "Alice recognizes Carol is not Bob",
            },
            {
                "name": "TST-3",
                "text": "Bob can recognize Alice",
            },
            {
                "name": "DOC-1",
                "text": "Alice is in Bob's Address Book",
                "references": [dotstop.LocalFileReference(example_reference)],
                "score": 0.5,
            },
        ]
    ]
    dot = f"""digraph G {{
        "EXP-1";
        "EXP-1" -> "ASN-1" [sha="{items[0].sha_link(items[2])}"]
        "EXP-1" -> "ASN-2"
        "ASN-CONTEXT" [sha="{items[1].sha}"]
        "ASN-1" [sha="{items[2].sha}"]
        "ASN-2" [sha="frfawuf4383e4rfhf48h5hfqle3j94hfqj3q84hf5gjwdjwoighwihdw5th58888"]
        "ASN-1" -> "TST-1"
        "ASN-1" -> "TST-2"
        "ASN-1" -> "DOC-1" [sha="{items[2].sha_link(items[7])}"]
        "ASN-2" -> "TST-3"
        "ASN-2" -> "DOC-1" [sha="3a933614862ber7ae19f3542448ea1673d9f24c4dd40e7701cad80ffaf8fa90f"]
        "TST-1" [sha="g7a6874845e72e48faadee30b9036b1b20b80d36ef7d38d006c683245711a987d"]
        "TST-2"
        "TST-3"
        "DOC-1" [sha="{items[7].sha}"]
        }}
        """
    return {
        "graph": build_trustable_graph(graph_source=dot, items_source=items),
        "items": items,
        "reference": example_reference,
    }


@pytest.fixture
def example_graph(example_workspace: dict) -> TrustableGraph:
    r"""
    Simple fixture containing only the `Graph` object from `example_workspace`.
    """
    return example_workspace["graph"]


def test_manage_lint_compare_ok(example_graph: TrustableGraph):
    _, unreviewed_items, suspect_links = manage._lint(example_graph, None)  # noqa SLF001

    exit_code = manage._compare_lint_outputs(  # noqa SLF001
        unreviewed_items, suspect_links, unreviewed_items, suspect_links
    )
    assert exit_code == ExitCodes.SUCCESS


def test_graph_items_diff_ok(example_graph: TrustableGraph):
    changed_items, changed_items_with_sme_scores = manage._get_changed_items(  # noqa SLF001
        example_graph, example_graph
    )
    assert changed_items == []
    assert changed_items_with_sme_scores == {}


def test_manage_set_item_links(example_graph: TrustableGraph):
    # Set ASN-2 (mocks the set-item)
    example_graph.set_review_status("ASN-2", True)

    # Set all links function
    manage.set_all_link_status_linked(example_graph, "ASN-2")

    # All links between ASN-2 and reviewed items should be LINKED
    assert example_graph.get_link_status("ASN-2", "DOC-1") == dotstop.LinkStatus.LINKED

    # All links between ASN-2 and non-reviewed items should be unchanged
    assert example_graph.get_link_status("ASN-2", "TST-3") == dotstop.LinkStatus.SUSPECT
    assert example_graph.get_link_status("EXP-1", "ASN-2") == dotstop.LinkStatus.SUSPECT


def test_manage_lint_diff_warning(caplog, example_graph: TrustableGraph):
    _, unreviewed_items, suspect_links = manage._lint(example_graph, None)  # noqa SLF001

    modified_graph = copy.deepcopy(example_graph)
    modified_graph.add_items(
        [FakeItem({"name": "NEW_ITEM", "text": "EXAMPLE NEW ITEM", "score": 0.5})]
    )

    # Create a new unreviewed item
    modified_graph.set_review_status("ASN-1", False)
    expected_new_unreviewed_item = "ASN-1"

    # Remove item
    #   - removes unreviewed item
    #   - removes suspect link
    modified_graph.remove_item("EXP-1")
    expected_removed_unreviewed_item = "EXP-1"
    expected_removed_suspect_links = "EXP-1 -> ASN-2"

    # Modify item
    modified_graph.get_item("ASN-CONTEXT").obj_dict["text"] = "NEW TEXT"
    modified_graph.set_review_status("ASN-CONTEXT", True)

    # Create new suspect link
    modified_graph.set_link_status("ASN-1", "DOC-1", dotstop.LinkStatus.SUSPECT)
    expected_new_suspect_link = "ASN-1 -> DOC-1"

    _, modified_unreviewed_items, modified_suspect_links = manage._lint(  # noqa SLF001
        modified_graph, None
    )

    exit_code = manage._compare_lint_outputs(  # noqa SLF001
        modified_unreviewed_items,
        modified_suspect_links,
        unreviewed_items,
        suspect_links,
    )
    assert exit_code == ExitCodes.LINT_FAILURE

    warning_msgs = [
        f"Unreviewed items added:\n\n{Fore.GREEN}  {expected_new_unreviewed_item}{Style.RESET_ALL}\n",
        f"Unreviewed items removed:\n\n{Fore.RED}  {expected_removed_unreviewed_item}{Style.RESET_ALL}\n",
        f"Suspect links added:\n\n{Fore.GREEN}  {expected_new_suspect_link}{Style.RESET_ALL}\n",
        f"Suspect links removed:\n\n{Fore.RED}  {expected_removed_suspect_links}{Style.RESET_ALL}\n",
    ]

    for warning_msg in warning_msgs:
        assert (
            "trudag.manage",
            logging.WARNING,
            warning_msg,
        ) in caplog.record_tuples

    changed_items, changed_items_with_sme_scores = manage._get_changed_items(  # noqa SLF001
        example_graph, modified_graph
    )

    assert sorted(changed_items) == sorted(["ASN-1", "ASN-CONTEXT"])
    assert changed_items_with_sme_scores == {"ASN-CONTEXT": {"SME Engineer": 0.5}}
