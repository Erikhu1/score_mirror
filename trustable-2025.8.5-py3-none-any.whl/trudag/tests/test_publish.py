from trudag.publish import publish
from trudag.dotstop.tests import FakeItem
from trudag.dotstop.core.graph import TrustableGraph, build_trustable_graph
from pathlib import Path
import pytest
import re
from trudag.tests.expected_reports import (
    ASN_REPORT_FIGURES,
    EXP_REPORT_FIGURES,
    PROJECT_NAME,
    NAV,
    REPORT,
    ASN_REPORT,
    EXP_REPORT,
    DASH,
)


def replace_datetime_dot_now(markdown_str: str):
    return re.sub(r"\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d{6}", "NOW", markdown_str)


class MockDataStoreClient:
    def pull(self) -> list[dict]:
        return [
            {
                "scores": [
                    {"id": "EXP-1", "score": 0.69},
                    {"id": "ASN-2", "score": 0.69},
                    {"id": "ASN-1", "score": 0.69},
                ],
                "info": {
                    "Commit date/time": "Wed Jun 11 04:20:00 2025",
                    "Commit SHA": "test",
                    "Commit tag": "test",
                    "Repository root": "test",
                    "CI job id": "test",
                    "Schema version": "test",
                    "Branch name": "test",
                },
            }
        ]


@pytest.fixture(scope="module")
def graph() -> TrustableGraph:
    items = [
        FakeItem(obj_dict)
        for obj_dict in [
            {"name": "EXP-1", "text": "Bob and Alice know each other"},
            {"name": "ASN-1", "text": "Alice knows Bob"},
            {"name": "ASN-2", "text": "Bob knows Alice"},
        ]
    ]
    dot = """digraph G {
        "EXP-1";
        "EXP-1" -> "ASN-1"
        "EXP-1" -> "ASN-2"
        "ASN-1" 
        "ASN-2" 
        }
        """
    return build_trustable_graph(graph_source=dot, items_source=items)


@pytest.fixture
def make_report(tmp_path: Path, graph: TrustableGraph):
    publish(graph, PROJECT_NAME, True, tmp_path, True)


@pytest.fixture
def make_report_figures(tmp_path: Path, graph: TrustableGraph):
    publish(
        graph,
        PROJECT_NAME,
        True,
        tmp_path,
        True,
        figures=True,
        data_store_client=MockDataStoreClient(),
    )


def test_report_figures(tmp_path: Path, make_report_figures):
    for file, expected in [
        ("EXP.md", EXP_REPORT_FIGURES),
        ("ASN.md", ASN_REPORT_FIGURES),
    ]:
        assert replace_datetime_dot_now((tmp_path / file).read_text()) == expected


def test_nav(make_report, tmp_path: Path):
    assert (tmp_path / "nav.md").read_text() == NAV


def test_dashboard(make_report, tmp_path: Path):
    assert (tmp_path / "dashboard.md").read_text() == DASH


def test_trustable_report(make_report, tmp_path: Path):
    assert (tmp_path / f"trustable_report_for_{PROJECT_NAME}.md").read_text() == REPORT


def test_item_summaries(make_report, tmp_path: Path):
    for file, expected in [
        ("EXP.md", EXP_REPORT),
        ("ASN.md", ASN_REPORT),
    ]:
        assert (tmp_path / file).read_text() == expected
