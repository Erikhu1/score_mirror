from trudag import utils

PROJECT_NAME = "test_proj"

NAV = f"""- [Compliance report](trustable_report_for_{PROJECT_NAME}.md)
- [Dashboard](dashboard.md)
* [ASN](ASN.md)
* [EXP](EXP.md)
"""
DASH = """# Dashboard
## Evidence Score Distribution

The distribution of scores for evidence nodes across the graph.

![No Image](figs/evidence_hist.svg)

??? example "click to view figure as table"

    |bin|count|
    |-|-|
    |0.0-0.1 {style="background-color:hsl(12.0, 100%, 61%)"} |2|
    |0.1-0.2 {style="background-color:hsl(24.0, 100%, 58%)"} |0|
    |0.2-0.3 {style="background-color:hsl(36.0, 100%, 54%)"} |0|
    |0.3-0.4 {style="background-color:hsl(48.0, 100%, 51%)"} |0|
    |0.4-0.5 {style="background-color:hsl(60.0, 100%, 47%)"} |0|
    |0.5-0.6 {style="background-color:hsl(72.0, 100%, 44%)"} |0|
    |0.6-0.7 {style="background-color:hsl(84.0, 100%, 40%)"} |0|
    |0.7-0.8 {style="background-color:hsl(96.0, 100%, 37%)"} |0|
    |0.8-0.9 {style="background-color:hsl(108.0, 100%, 33%)"} |0|
    |0.9-1.0 {style="background-color:hsl(120.0, 100%, 30%)"} |0|
## Expectations Score Distribution

The distribution of scores for expectations nodes across the graph.

![No Image](figs/expectations_hist.svg)

??? example "click to view figure as table"

    |bin|count|
    |-|-|
    |0.0-0.1 {style="background-color:hsl(12.0, 100%, 61%)"} |1|
    |0.1-0.2 {style="background-color:hsl(24.0, 100%, 58%)"} |0|
    |0.2-0.3 {style="background-color:hsl(36.0, 100%, 54%)"} |0|
    |0.3-0.4 {style="background-color:hsl(48.0, 100%, 51%)"} |0|
    |0.4-0.5 {style="background-color:hsl(60.0, 100%, 47%)"} |0|
    |0.5-0.6 {style="background-color:hsl(72.0, 100%, 44%)"} |0|
    |0.6-0.7 {style="background-color:hsl(84.0, 100%, 40%)"} |0|
    |0.7-0.8 {style="background-color:hsl(96.0, 100%, 37%)"} |0|
    |0.8-0.9 {style="background-color:hsl(108.0, 100%, 33%)"} |0|
    |0.9-1.0 {style="background-color:hsl(120.0, 100%, 30%)"} |0|
## All Score Distribution

The distribution of scores for all nodes across the graph.

![No Image](figs/all_hist.svg)

??? example "click to view figure as table"

    |bin|count|
    |-|-|
    |0.0-0.1 {style="background-color:hsl(12.0, 100%, 61%)"} |3|
    |0.1-0.2 {style="background-color:hsl(24.0, 100%, 58%)"} |0|
    |0.2-0.3 {style="background-color:hsl(36.0, 100%, 54%)"} |0|
    |0.3-0.4 {style="background-color:hsl(48.0, 100%, 51%)"} |0|
    |0.4-0.5 {style="background-color:hsl(60.0, 100%, 47%)"} |0|
    |0.5-0.6 {style="background-color:hsl(72.0, 100%, 44%)"} |0|
    |0.6-0.7 {style="background-color:hsl(84.0, 100%, 40%)"} |0|
    |0.7-0.8 {style="background-color:hsl(96.0, 100%, 37%)"} |0|
    |0.8-0.9 {style="background-color:hsl(108.0, 100%, 33%)"} |0|
    |0.9-1.0 {style="background-color:hsl(120.0, 100%, 30%)"} |0|
## Summary


| Category | Count |
|----------|-------|
|statements|3|
|reviewed statements|0|
|unreviewed statements|3|
|orphaned statements|0|
|statements with evidence|1|
|evidence|2|
|expectations|1|
"""

REPORT = f"""# Trustable Compliance Report



## Item status guide ## {{ .subsection }}

Each item in a Trustable Graph is scored with a number between 0 and 1.
The score represents aggregated organizational confidence in a given Statement, with larger numbers corresponding to higher confidence.
Scores in the report are indicated by both a numerical score and the colormap below:
<div class="br" style="height: 26px; width: 80%;background: linear-gradient(to right in hsl, hsl(0.0, 100%, 65%) 0%, hsl(120.0, 100%, 30%) 100%);">
<span style="float:right;">1.00&nbsp</span>
<span style="float:left;">&nbsp0.00</span>
</div>


The status of an item and its links also affect the score.

Unreviewed items are indicated by a strikethrough.
The score of unreviewed items is always set to zero.


Suspect links are indicated by italics.
The contribution to the score of a parent item by a suspiciously linked child is always zero, regardless of the child's own score.
## Compliance for ASN

| Item   | Summary | Score |
|--------|---------|-------|
| [ASN-1](ASN.md#asn-1) {{class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}}| ASN-1Alice knows Bob | 0.00 |
| [ASN-2](ASN.md#asn-2) {{class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}}| ASN-2Bob knows Alice | 0.00 |

## Compliance for EXP

| Item   | Summary | Score |
|--------|---------|-------|
| [EXP-1](EXP.md#exp-1) {{class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}}| EXP-1Bob and Alice know each other | 0.00 |


---

_Generated for: test_proj_

* _Repository root: {utils.get_root_dir()}_
* _Commit SHA: {utils.get_commit_sha()}_
* _Commit date/time: {utils.get_commit_date()}_
* _Commit tag: {utils.get_last_tag()}_
"""

ASN_REPORT = """

---

### ASN-1 ### {: .item-element .item-section class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}

Alice knows Bob
{: .expanded-item-element }

**Supported Requests:**

- [EXP-1](EXP.md#exp-1){.item-element class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}

**Supporting Items:**

_None_

{% raw %}

**References:**

_None_

{% endraw %}

**Fallacies:**

_None_


---

### ASN-2 ### {: .item-element .item-section class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}

Bob knows Alice
{: .expanded-item-element }

**Supported Requests:**

- [EXP-1](EXP.md#exp-1){.item-element class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}

**Supporting Items:**

_None_

{% raw %}

**References:**

_None_

{% endraw %}

**Fallacies:**

_None_
"""

EXP_REPORT = """

---

### EXP-1 ### {: .item-element .item-section class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}

Bob and Alice know each other
{: .expanded-item-element }

**Supported Requests:**


**Supporting Items:**

- [ASN-1](ASN.md#asn-1){.item-element class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}
- [ASN-2](ASN.md#asn-2){.item-element class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}

{% raw %}

**References:**

_None_

{% endraw %}

**Fallacies:**

_None_
"""

EXP_REPORT_FIGURES = """

---

### EXP-1 ### {: .item-element .item-section class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}

Bob and Alice know each other
{: .expanded-item-element }

**Supported Requests:**


**Supporting Items:**

- [ASN-1](ASN.md#asn-1){.item-element class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}
- [ASN-2](ASN.md#asn-2){.item-element class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}

{% raw %}

**References:**

_None_

{% endraw %}

**Fallacies:**

_None_

**Graph:**

![No Image](figs/EXP-1.svg)

??? example "Graph Data as Table"
    |date-time|EXP-1|ASN-1|ASN-2|
    |-|-|-|-|
    |2025-06-11 04:20:00|0.69 {style="background-color:hsl(82.8, 100%, 40%)"}|0.69 {style="background-color:hsl(82.8, 100%, 40%)"}|0.69 {style="background-color:hsl(82.8, 100%, 40%)"}|
    |NOW|0.00 {style="background-color:hsl(0.0, 100%, 65%)"}|0.00 {style="background-color:hsl(0.0, 100%, 65%)"}|0.00 {style="background-color:hsl(0.0, 100%, 65%)"}|

"""

ASN_REPORT_FIGURES = """

---

### ASN-1 ### {: .item-element .item-section class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}

Alice knows Bob
{: .expanded-item-element }

**Supported Requests:**

- [EXP-1](EXP.md#exp-1){.item-element class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}

**Supporting Items:**

_None_

{% raw %}

**References:**

_None_

{% endraw %}

**Fallacies:**

_None_

**Graph:**

![No Image](figs/ASN-1.svg)

??? example "Graph Data as Table"
    |date-time|ASN-1|
    |-|-|
    |2025-06-11 04:20:00|0.69 {style="background-color:hsl(82.8, 100%, 40%)"}|
    |NOW|0.00 {style="background-color:hsl(0.0, 100%, 65%)"}|



---

### ASN-2 ### {: .item-element .item-section class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}

Bob knows Alice
{: .expanded-item-element }

**Supported Requests:**

- [EXP-1](EXP.md#exp-1){.item-element class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)" .status-unreviewed}

**Supporting Items:**

_None_

{% raw %}

**References:**

_None_

{% endraw %}

**Fallacies:**

_None_

**Graph:**

![No Image](figs/ASN-2.svg)

??? example "Graph Data as Table"
    |date-time|ASN-2|
    |-|-|
    |2025-06-11 04:20:00|0.69 {style="background-color:hsl(82.8, 100%, 40%)"}|
    |NOW|0.00 {style="background-color:hsl(0.0, 100%, 65%)"}|

"""
