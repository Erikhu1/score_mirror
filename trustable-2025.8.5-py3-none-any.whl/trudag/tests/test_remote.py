import pytest
import click.testing
import trudag.cli as cli
import trudag.utils as utils

from pathlib import Path

"""
Example dot source code and item files for an empty project.
"""

simple_project_files = {
    "dot_source": (
        """digraph G {
        "ROOT-001" [sha="1cfd3f78157e6d24efb274d094dfe7ff829d4184c86e5f8cb8c8243d21f8fdf4"];
        "EVIDENCE-001" [sha="51bff004630ff62f5b5a358a91dcd3886a16281bbeae3351e3615e1bb4b58657"];
        "INTERMEDIATE-001" [sha="890da812aaa60be08197c0dfda860fc5a54838245d0ffd0e5dfc493b9ca85237"];
        "INTERMEDIATE-002"  [sha=f5d5ba0f75e9323c18adb9114485194bb8752f705d37ff82c501b72f0a03304f];
        "INTERMEDIATE-003" [sha=fd740090c729dbead29c6e59b63434451fd2403950616066705dee742c8f3b46];
        "ROOT-001" -> "INTERMEDIATE-001" [sha="27298d4dac7edabeac67c9bbc49f142301c377606ba8dcf46e27f29e6f02918a"];
        "INTERMEDIATE-001" -> "EVIDENCE-001" [sha="55ee1fa200db304fc2144085389f5dd0ed595a4c456c1ad6444bd2ee9135f745"];
    }
        """
    ),
    "items_source": {
        "ROOT-001": (
            """---
            normative: true
            ---

            A Statement about something
            """
        ),
        "INTERMEDIATE-001": (
            """---
            normative: true
            ---

            Some valid reasoning
            """
        ),
        "INTERMEDIATE-002": (
            """---
            normative: true
            ---

            Some more valid reasoning
            """
        ),
        "INTERMEDIATE-003": (
            """---
            normative: true
            ---

            Even more valid reasoning
            """
        ),
        "EVIDENCE-001": (
            """---
            normative: true
            ---

            Some actual basis for my claims
            """
        ),
    },
    "expected_scores_csv": lambda: f"""EVIDENCE-001,0.0
INTERMEDIATE-001,0.0
INTERMEDIATE-002,0.0
INTERMEDIATE-003,0.0
ROOT-001,0.0
Repository root,{utils.get_root_dir()}
Commit SHA,{utils.get_commit_sha()}
Commit date/time,{utils.get_commit_date()}
Commit tag,{utils.get_last_tag()}
""",
    "expected_scores_json": lambda: {
        "scores": [
            {"id": "INTERMEDIATE-002", "score": 0.0},
            {"id": "ROOT-001", "score": 0.0},
            {"id": "INTERMEDIATE-001", "score": 0.0},
            {"id": "EVIDENCE-001", "score": 0.0},
            {"id": "INTERMEDIATE-003", "score": 0.0},
        ],
        "info": {
            "Repository root": utils.get_root_dir(),
            "Commit SHA": utils.get_commit_sha(),
            "Commit date/time": utils.get_commit_date(),
            "Commit tag": utils.get_last_tag(),
            "Branch name": utils.get_branch_name(),
            "CI job id": utils.get_ci_job_id(),
        },
    },
    "expected_report": lambda: """# Trustable Compliance Report



## Item status guide ## { .subsection }

Each item in a Trustable Graph is scored with a number between 0 and 1.
The score represents aggregated organizational confidence in a given Statement, with larger numbers corresponding to higher confidence.
Scores in the report are indicated by both a numerical score and the colormap below:
<div class="br" style="height: 26px; width: 80%;background: linear-gradient(to right in hsl, hsl(0.0, 100%, 65%) 0%, hsl(120.0, 100%, 30%) 100%);">
<span style="float:right;">1.00&nbsp</span>
<span style="float:left;">&nbsp0.00</span>
</div>


The status of an item and its links also affect the score.

Unreviewed items are indicated by a strikethrough.
The score of unreviewed items is always set to zero.


Suspect links are indicated by italics.
The contribution to the score of a parent item by a suspiciously linked child is always zero, regardless of the child's own score.
## Compliance for EVIDENCE

| Item   | Summary | Score |
|--------|---------|-------|
| [EVIDENCE-001](EVIDENCE.md#evidence-001) {class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)"}|  Some actual basis for my claims | 0.00 |

## Compliance for INTERMEDIATE

| Item   | Summary | Score |
|--------|---------|-------|
| [INTERMEDIATE-001](INTERMEDIATE.md#intermediate-001) {class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)"}|  Some valid reasoning | 0.00 |
| [INTERMEDIATE-002](INTERMEDIATE.md#intermediate-002) {class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)"}|  Some more valid reasoning | 0.00 |
| [INTERMEDIATE-003](INTERMEDIATE.md#intermediate-003) {class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)"}|  Even more valid reasoning | 0.00 |

## Compliance for ROOT

| Item   | Summary | Score |
|--------|---------|-------|
| [ROOT-001](ROOT.md#root-001) {class="tsf-score" style="background-color:hsl(0.0, 100%, 65%)"}|  A Statement about something | 0.00 |


"""
    + f"""---

_Generated for: TEST_

* _Repository root: {utils.get_root_dir()}_
* _Commit SHA: {utils.get_commit_sha()}_
* _Commit date/time: {utils.get_commit_date()}_
* _Commit tag: {utils.get_last_tag()}_
""",
    "expected_navigation": """- [Compliance report](trustable_report_for_TEST.md)
- [Dashboard](dashboard.md)
* [EVIDENCE-001](EVIDENCE-001.md)
* [EVIDENCE](EVIDENCE.md)
* [INTERMEDIATE-001](INTERMEDIATE-001.md)
* [INTERMEDIATE-002](INTERMEDIATE-002.md)
* [INTERMEDIATE-003](INTERMEDIATE-003.md)
* [INTERMEDIATE](INTERMEDIATE.md)
* [ROOT-001](ROOT-001.md)
* [ROOT](ROOT.md)
""",
}

"""
Remote configuration file name
"""
REMOTE_FILE = ".remote-graphs.yml"


"""
Remote graph example file definition
"""
REMOTE = """
repos:
  - alias: repo1
    url: https://gitlab.com/CodethinkLabs/trustable/trustable.git
    type: "git"
    tag: main
  - alias: repo2
    url: https://gitlab.com/CodethinkLabs/trustable/trustable.git
    type: "git"
    tag: v2025.06.25
"""

REMOTE_COMMANDS_PULL = [
    ["remote", "pull"],
    ["remote", "pull", "--netrc-file", ".netrc"],
]


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
)
@pytest.mark.parametrize(
    "command",
    REMOTE_COMMANDS_PULL,
    ids=[" ".join(command) for command in REMOTE_COMMANDS_PULL],
)
def test_remote_pull(project_workdir_git, command, monkeypatch):
    monkeypatch.chdir(project_workdir_git)
    with Path(REMOTE_FILE).open("w") as f:
        f.write(REMOTE)
    runner = click.testing.CliRunner()
    result = runner.invoke(
        cli.main,
        [
            *command,
        ],
    )
    assert result.exit_code == 0


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
)
def test_remote_pull_no_netrc(project_workdir_git, caplog):
    with (project_workdir_git / REMOTE_FILE).open("w") as f:
        f.write(REMOTE)

    assert (
        click.testing.CliRunner()
        .invoke(
            cli.main,
            [
                "remote",
                "pull",
                "--netrc-file",
                f"{project_workdir_git / '.notnetrc'}",
            ],
        )
        .exit_code
        != 0
    )

    assert "Failed to find netrc file" in caplog.messages[0]


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
)
def test_remote_pull_netrc_warning(project_workdir_git, caplog):
    with (project_workdir_git / REMOTE_FILE).open("w") as f:
        f.write(REMOTE)

    click.testing.CliRunner().invoke(
        cli.main,
        [
            "remote",
            "pull",
            "--netrc-file",
            f"{project_workdir_git / '.netrc'}",
        ],
    )

    assert "Failed to find in netrc file a credential for gitlab.com" in caplog.messages


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
)
def test_remote_without_config(project_workdir_git, monkeypatch):
    monkeypatch.chdir(project_workdir_git)
    result = click.testing.CliRunner().invoke(cli.main, ["remote", "pull"])
    assert (
        "Missing remote definitions, not proceeding with any command" in result.stderr
    )
    assert result.exit_code != 0


INVALID_REMOTE_COMMANDS_SCORES = [
    [
        "remote",
        "score",
        "--from",
        "INTERMEDIATE-001",
        "--to",
        "repo1",
        "--to",
        "repo1",
    ],
    [
        "remote",
        "score",
        "--from",
        "INTERMEDIATE-001",
        "--from",
        "INTERMEDIATE-002",
        "--from",
        "INTERMEDIATE-003",
        "--to",
        "repo1",
        "--to",
        "repo2",
    ],
    [
        "remote",
        "score",
        "--from",
        "TRUSTABLE-SOFTWARE",
        "--to",
        "repo1",
        "--to",
        "repo2",
    ],
]

REMOTE_COMMANDS_SHOW = [
    [
        "remote",
        "show",
        "repo1",
    ],
    [
        "remote",
        "show",
        "repo2",
    ],
]
INVALID_REMOTE_COMMANDS_SHOW_ITEM = [
    [
        "remote",
        "show-item",
        "TA-INPUTS",
        "repo5",
    ],
]
REMOTE_COMMANDS_SHOW_ITEM = [
    [
        "remote",
        "show-item",
        "TA-INPUTS",
        "repo1",
    ],
    [
        "remote",
        "show-item",
        "TA-INPUTS",
        "repo1",
    ],
]

INVALID_REMOTE_COMMANDS_SHOW = [
    [
        "remote",
        "show",
        "repo5",
    ],
    [
        "remote",
        "show",
        "repo6",
    ],
]


REMOTE_COMMANDS_SCORES = [
    [
        "remote",
        "score",
        "--from",
        "INTERMEDIATE-002",
        "--to",
        "repo1",
        "--from",
        "INTERMEDIATE-001",
        "--to",
        "repo2",
    ],
    [
        "remote",
        "score",
        "--from",
        "INTERMEDIATE-001",
        "--to",
        "repo1",
        "--to",
        "repo2",
        "--destination",
        "funnnnn",
    ],
]


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
)
@pytest.mark.parametrize(
    "commands",
    INVALID_REMOTE_COMMANDS_SCORES,
)
def test_remote_score_invalid(
    project_workdir_git,
    commands,
    caplog,
    monkeypatch,
):
    monkeypatch.chdir(project_workdir_git)
    with Path(REMOTE_FILE).open("w") as f:
        f.write(REMOTE)

    result = click.testing.CliRunner().invoke(cli.main, [*commands])

    count = commands.count("--from")

    if "TRUSTABLE-SOFTWARE" in commands:
        assert (
            "Origin node TRUSTABLE-SOFTWARE is not part of local graph"
            in caplog.messages
        )

    elif count == 3:
        assert (
            "Error: Invalid value: Must provide equal --from and --to arguments"
            in result.stderr
        )

    else:
        assert (
            "Error: Invalid value for '--to': Can't connect to the same graph more than once"
            in result.stderr
        )
    assert result.exit_code != 0


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
)
@pytest.mark.parametrize(
    "commands",
    REMOTE_COMMANDS_SCORES,
)
def test_remote_score_valid(project_workdir_git, commands, monkeypatch):
    monkeypatch.chdir(project_workdir_git)
    with Path(REMOTE_FILE).open("w") as f:
        f.write(REMOTE)

    click.testing.CliRunner().invoke(cli.main, ["remote", "pull"])
    result = click.testing.CliRunner().invoke(cli.main, [*commands])
    assert result.exit_code == 0
    if "funnnnn" in commands:
        assert (project_workdir_git / "funnnnn").exists()
        assert (project_workdir_git / "funnnnn" / "merged-scores").stat().st_size > 0
        assert (
            project_workdir_git / "funnnnn" / "merged-graphs.dot"
        ).stat().st_size > 0
    else:
        assert (project_workdir_git / "trudag-out").exists()
        assert (project_workdir_git / "trudag-out" / "merged-scores").stat().st_size > 0
        assert (
            project_workdir_git / "trudag-out" / "merged-graphs.dot"
        ).stat().st_size > 0


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
)
@pytest.mark.parametrize(
    "commands",
    REMOTE_COMMANDS_SHOW,
)
def test_remote_show(project_workdir_git, commands, monkeypatch):
    monkeypatch.chdir(project_workdir_git)
    with Path(REMOTE_FILE).open("w") as f:
        f.write(REMOTE)

    click.testing.CliRunner().invoke(cli.main, ["remote", "pull"])
    result = click.testing.CliRunner().invoke(cli.main, [*commands])
    assert result.exit_code == 0


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
)
@pytest.mark.parametrize(
    "commands",
    REMOTE_COMMANDS_SHOW_ITEM,
)
def test_remote_show_item(project_workdir_git, commands, monkeypatch):
    monkeypatch.chdir(project_workdir_git)
    with Path(REMOTE_FILE).open("w") as f:
        f.write(REMOTE)

    click.testing.CliRunner().invoke(cli.main, ["remote", "pull"])
    result = click.testing.CliRunner().invoke(cli.main, [*commands])
    assert result.exit_code == 0


@pytest.mark.parametrize(
    "files",
    [simple_project_files],
)
@pytest.mark.parametrize(
    "commands",
    INVALID_REMOTE_COMMANDS_SHOW_ITEM,
)
def test_remote_show_item_invalid(project_workdir_git, commands, monkeypatch):
    monkeypatch.chdir(project_workdir_git)
    with Path(REMOTE_FILE).open("w") as f:
        f.write(REMOTE)

    click.testing.CliRunner().invoke(cli.main, ["remote", "pull"])
    result = click.testing.CliRunner().invoke(cli.main, [*commands])
    assert result.exit_code != 0
