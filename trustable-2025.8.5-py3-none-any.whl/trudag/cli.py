# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

"""
The `trudag` CLI frontend.
"""

import logging
import importlib.metadata
import os

from pathlib import Path

import click
import doorstop

from schema import SchemaError
from yaml import YAMLError
from git import GitCommandError, InvalidGitRepositoryError

import trudag.publish
import trudag.plot
import trudag.score
import trudag.manage
import trudag.utils as utils
from trudag.dotstop import (
    GraphStructureError,
    GraphActionError,
    ItemError,
    LinkStatus,
    DotstopError,
    DataModelError,
    PluginError,
    GitError,
    remote as RemoteGraph,
)

from trudag.dotstop.core.graph import build_trustable_graph
from trudag.dotstop.core.constants import IGNORE_FILE

handler = logging.StreamHandler()
handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))

# Use the `trudag` package logger, so that all configuration here is inherited.
logger = logging.getLogger("trudag")
logger.setLevel(logging.INFO)
logger.addHandler(handler)

# Define some reusable options that do not belong to a single group.
validate_option = click.option(
    "--validate/--no-validate",
    default=False,
    type=bool,
    is_flag=True,
    help="Run automated validators when scoring.",
)
fail_on_error_option = click.option(
    "--fail-on-error/--no-fail-on-error",
    default=False,
    type=bool,
    is_flag=True,
    help="fail with exit code on errors during the command run.",
)

dump_option = click.option(
    "--dump",
    "-d",
    type=Path,
    help="Output file path for the Trustable Scores file, currently supports .csv and .json file extensions or a configured data store",
)


@click.group(name="trudag", invoke_without_command=True)
@click.version_option(importlib.metadata.version("trustable"))
@click.option(
    "--dot / --door",
    default=True,
    type=bool,
    is_flag=True,
    help="Use dotstop backend, not doorstop.",
    show_default=True,
)
@click.option(
    "--verbose",
    default=False,
    type=bool,
    is_flag=True,
    help="Enable verbose logging.",
)
@click.option(
    "--init",
    default=False,
    type=bool,
    is_flag=True,
    help="Initialize an empty dot database.",
)
@click.option(
    "--workers",
    "-w",
    type=int,
    help="Set the upperbound for the allowed number of worker threads to spawn when doing parallel tasks. Default: Available software cores.",
)
@click.pass_context
@utils.abort_click_on(
    FileNotFoundError, FileExistsError, ItemError, GraphStructureError
)
def main(
    ctx: click.Context, dot: bool, verbose: bool, init: bool, workers: int
) -> None:
    """
    Manipulate, analyze and present the contents of a Trustable Acyclic Graph.\f

    Args:
        ctx (click.Context): Context to append and pass to subcommands
        dot (bool): Build graph from `.dotstop.dot`
        verbose (bool): Set logging level to `DEBUG`
        init(bool): Create an empty dot database
        workers (int): Set the upperbound for spawning worker threads
    """
    utils.check_for_help(ctx)

    if verbose:
        logger.setLevel(logging.DEBUG)

    workdir = utils.get_workdir()

    # ensure relative paths are resolved correctly relative to the workdir
    os.chdir(workdir)

    ctx.ensure_object(dict)
    if init:
        # Temporary check, required until doorstop backend is deprecated.
        if dot:
            utils.make_dotfile(workdir / utils.DOTSTOP_DEFAULT_FILENAME)
        else:
            logger.warning("Cannot create dot database when using doorstop backend.")

    if dot:
        # passthrough ignore file if it exists.
        trustable_ignore: Path | None = (
            workdir / IGNORE_FILE if (workdir / IGNORE_FILE).exists() else None
        )

        ctx.obj["graph"] = build_trustable_graph(
            workdir / utils.DOTSTOP_DEFAULT_FILENAME,
            workdir,
            trustable_ignore=trustable_ignore,
        )

    else:
        logger.warning(
            "Deprecation of support for the doorstop backend is planned. Consider migrating to avoid compatibility problems with later releases."
        )
        ctx.obj["graph"] = build_trustable_graph(doorstop_source=doorstop.build())

    ctx.obj["workers"] = workers
    ctx.obj["dotstop_file"] = workdir / utils.DOTSTOP_DEFAULT_FILENAME
    ctx.obj["item_directory"] = workdir


@click.command(name="publish")
@click.option(
    "--name",
    "-n",
    default="Software",
    show_default=True,
    type=str,
    help="Project name.",
)
@click.option(
    "--all-bodies/--normative-bodies",
    "-a",
    default=False,
    show_default=True,
    type=bool,
    help="Include text of non-normative items.",
)
@click.option(
    "--figures",
    "-f",
    is_flag=True,
    type=bool,
    help="Include graphs in reports (requires configured data store)",
)
@click.option(
    "--output-dir",
    "-o",
    default="docs/doorstop",
    show_default=True,
    type=Path,
    help="Output directory for reports.",
)
@validate_option
@dump_option
@click.pass_context
@utils.abort_click_on(ItemError, ReferenceError, PluginError, DataModelError)
def _publish(
    ctx: click.Context,
    name: str,
    all_bodies: bool,
    figures: bool,
    output_dir: Path,
    validate: bool,
    dump: Path | None = None,
) -> None:
    """
    Report the status and scores of items as markdown.

    Args:
        ctx (click.Context): Command context, including a `dotstop.Graph`.
        name (str): Software project name.
        all_bodies (bool): Include bodies of non-normative records.
        output_dir (Path): Output directory.
        validate (str): Run automated validators.
        dump (Path): Output file path for the Trustable Scores file
    """
    trudag.publish.publish(
        ctx.obj["graph"], name, all_bodies, output_dir, validate, dump, figures
    )


def validate_pick_levels(
    _ctx, _param, value: list[tuple[str, str]]
) -> list[tuple[str, int | None, int | None]]:
    new_value = []
    for arg in value:
        picked, levels = arg
        if ":" not in levels:
            raise click.BadParameter(
                "format of levels should be `parent_levels:children_levels`, either can be unspecified but the `:` separator is required"
            )

        parent_levels_raw, _, child_levels_raw = levels.partition(":")

        parent_levels_raw = parent_levels_raw.strip()
        parent_levels = None
        if parent_levels_raw:
            if not parent_levels_raw.isdigit():
                raise click.BadParameter(
                    "format of levels should be `parent_levels:children_levels` where they are both integer values or unspecified"
                )
            parent_levels = int(parent_levels_raw)

        child_levels_raw = child_levels_raw.strip()
        child_levels = None
        if child_levels_raw:
            if not child_levels_raw.isdigit():
                raise click.BadParameter(
                    "format of levels should be `parent_levels:children_levels` where they are both integer values or unspecified"
                )
            child_levels = int(child_levels_raw)

        new_value.append((picked, parent_levels, child_levels))

    return new_value


@click.command(name="plot")
@click.option(
    "--output-file-path",
    "-o",
    default="./graph.svg",
    show_default=True,
    type=Path,
    help="file path for the output graph.",
)
@click.option(
    "--line-length",
    "-l",
    default=32,
    show_default=True,
    type=int,
    help="Soft limit on characters-per-line for plotted items.",
)
@click.option(
    "--url",
    "-u",
    default="",
    type=str,
    help="If specified, items have tooltip: <TEXT>/<DOC>.html#<ITEM>",
)
# Doorstop does not allow commas in UIDs, so this CLI interface supports all possible Doorstop Item UIDs.
@click.option(
    "--same-rank",
    "-s",
    default=[],
    type=str,
    multiple=True,
    help="Fix items on the same vertical rank. Provide as a comma-separated list of item names.",
)
# Doorstop does not allow commas in UIDs, so this CLI interface supports all possible Doorstop Item UIDs.
@click.option(
    "--invis-deps",
    "-i",
    default=[],
    type=(str, str),
    multiple=True,
    help="Add invisible links between items. "
    "Links are temporary and used only for visualization. "
    "Provide as pairs of item names separated by a space. ",
)
@click.option(
    "--pick",
    default=[],
    type=(str, str),
    multiple=True,
    callback=validate_pick_levels,
    help="Picks a node and its parents / children recursively to specified levels. "
    "You must specify the node, and optionally the levels of parents and children to be retained. "
    "The levels of parents / children is formatted as `parents:children`, "
    "for example, the argument `1:2` will pick 1 level of the node's parents, and 2 levels of the children. "
    "You may skip a value to pick all levels recursively, for example: `:1` will pick all levels of parents, "
    "and one level of the children. "
    "You may specify `0:0` to only select the picked node. "
    "This argument can be used multiple times to pick multiple nodes. "
    "You may use this argument together with --orphan-nodes to pick specified nodes and orphan-nodes. ",
)
@click.option(
    "--orphan-nodes",
    type=bool,
    is_flag=True,
    help="Retain nodes that aren't linked with anything else. "
    "You may use this argument together with --pick to retain orphan-nodes and picked nodes. ",
)
@click.pass_context
@utils.abort_click_on(GraphActionError, ItemError)
def _plot(
    ctx: click.Context,
    line_length: int,
    same_rank: str,
    output_file_path: Path,
    url: str,
    invis_deps: tuple[str, str],
    pick: list[tuple[str, int | None, int | None]],
    orphan_nodes: bool,
) -> None:
    """
    Produce a graphic of items and their links.

    All graphics are rendered from dot using graphviz.\f

    Args:
        ctx (click.Context): Command context, including a `dotstop.Graph`.
        line_length (int): Soft CPL limit for plotted items
        same_rank (str): Comma-separated string of items to place on same vertical rank.
        output_file_path (Path): output file path for rendered image (default is graph.svg).
        url (str): Tooltip.
        invis_deps (tuple[str, str]): Invisible links used to manipulate item placement in rendered image.
        pick: (list[tuple[str, int | None, int | None]]): Picks nodes to be retained in the graph, specified by item name and levels of parent / child to be picked.
        orphan_nodes (bool): Only keep nodes that isn't linked with anything else.
    """
    # Parse tuples of document prefixes and item identifiers.
    trudag.plot.plot(
        ctx.obj["graph"],
        line_length,
        _parse_ranks(same_rank),
        invis_deps,
        pick,
        orphan_nodes,
        output_file_path=output_file_path,
        base_url=url,
    )


def _parse_ranks(rank_list_str: list[str]) -> list[list[str]]:
    """
    Parse the 'list as string' of a rank tuple into a Python list.
    """
    rank_list = []
    for item_list_str in rank_list_str:
        item_list = [item.strip() for item in item_list_str.split(",")]
        rank_list.append(item_list)
    return rank_list


@click.group(help="Manage the status of items and their links.")
@click.pass_context
def manage(ctx: click.Context):
    ctx.ensure_object(dict)


@manage.command(name="show-link")
@click.argument("parent", type=str)
@click.argument("child", type=str)
@click.pass_context
@utils.abort_click_on(GraphActionError, ItemError)
def _show_link(ctx: click.Context, parent: str, child: str) -> None:
    """
    Show status of the link from PARENT to CHILD.\f

    Args:
        ctx (click.Context): Command context, including a `dotstop.Graph`.
        parent (str): Parent item name
        child (str): Child item name
    """
    status = str(ctx.obj["graph"].get_link_status(parent, child))
    click.echo(parent + " -> " + child + " => " + status)


@manage.command(name="set-link")
@click.argument("parent", type=str, nargs=1)
@click.argument("child", type=str, nargs=1)
@click.option(
    "--status",
    "-s",
    default="LINKED",
    type=str,
    help="Set status as LINKED, UNLINKED or SUSPECT.",
)
@click.pass_context
@utils.abort_click_on(GraphActionError, ItemError)
def _set_link(ctx: click.Context, parent: str, child: str, status: str):
    """
    Set status of the link from PARENT to CHILD as LINKED.\f

    Args:
        ctx (click.Context): Command context, including a `dotstop.Graph`.
        parent (str): Parent item name
        child (str): Child item name
        status (str): A valid `LinkStatus` string, valid options are SUSPECT or LINKED.
    """

    try:
        status_enum = LinkStatus(status.upper())
    except ValueError as value_error:
        err_msg = (
            f"Cannot set link to invalid status {status}. Options are SUSPECT, LINKED."
        )
        raise GraphActionError(err_msg) from value_error
    ctx.obj["graph"].set_link_status(parent, child, status_enum)
    ctx.obj["graph"].to_file(ctx.obj["dotstop_file"])


@manage.command(name="set-item")
@click.argument("items", nargs=-1)
@click.option(
    "--links",
    type=bool,
    is_flag=True,
    show_default=False,
    help="Set status of the links from this item(s) to other valid items as LINKED.",
)
@click.pass_context
@utils.abort_click_on(GraphActionError, ItemError)
def _set_item(ctx: click.Context, items: tuple[str, ...], links: bool):
    """
    Set item review status to True.\f

    Args:
        ctx (click.Context): Command context, including a `dotstop.Graph`.
        items (tuple[str, ...]): Item(s) given for setting the review status to `True`.
    """
    for item in items:
        ctx.obj["graph"].set_review_status(item, status=True)
        if links:
            trudag.manage.set_all_link_status_linked(ctx.obj["graph"], item)
    ctx.obj["graph"].to_file(ctx.obj["dotstop_file"])


@manage.command(name="show-item")
@click.argument("items", nargs=-1)
@click.option(
    "--statement",
    type=bool,
    is_flag=True,
    show_default=True,
    help="Display item statement.",
)
@click.pass_context
@utils.abort_click_on(GraphActionError, ItemError)
def _show_item(ctx, items: tuple[str, ...], statement: bool):
    """
    Show items current review status.\f

    Args:
        ctx (click.Context): Command context, including a `dotstop.Graph`.
        item (tuple[str, ...]): Item(s) to be described.
        statement (bool): Adds statement information in the output
    """

    for item in items:
        output = trudag.manage.describe_item(ctx.obj["graph"], item, statement)
        click.echo(utils.OUTPUT_SEPARATOR)
        click.echo(output)
        click.echo(utils.OUTPUT_SEPARATOR)


@manage.command(name="create-link")
@click.argument("parent", nargs=1)
@click.argument("child", nargs=1)
@click.pass_context
@utils.abort_click_on(GraphActionError, ItemError)
def _create_link(ctx: click.Context, parent: str, child: str) -> None:
    """
    Create a link from PARENT to CHILD.

    The new link will have status LINKED.\f

    Args:
        ctx (click.Context): Command context, including a `dotstop.Graph`.
        parent (str): Parent item name
        child (str): Child item name
    """
    ctx.obj["graph"].set_link_status(parent, child, LinkStatus.LINKED)
    ctx.obj["graph"].to_file(ctx.obj["dotstop_file"])


@manage.command(name="create-item")
@click.option(
    "--parent",
    "-p",
    type=str,
    default="",
    help="Set item TEXT as parent.",
)
@click.argument("prefix", nargs=1)
@click.argument("id", nargs=1)
@click.argument("path", nargs=1)
@click.pass_context
@utils.abort_click_on(GraphActionError, FileExistsError)
def _create_item(ctx, path: str, prefix: str, id: str, parent: str) -> None:
    """
    Create a new item in PATH named PREFIX-ID.

    The new item will be reviewed and any new links will have status LINKED.
    Item files are intended for human editing and dtag intentionally provides no options for modifying them from the CLI.\f

    Creates a Markdown file and populate it with all the required attributes.
    The UID of an item is defined by its filename without the extension. An UID
    consists of two parts, the prefix and a number or name

    Args:
        ctx (click.Context): Command context, including a `dotstop.Graph`.
        path (str): Path to a directory for item files
        prefix (str): Part of the item name preceeding the last `-` character.
        id (str): Part of the item name following the last `-` character.
        parent (str): Name of a parent item (default: None)

    Returns: `None`
    """
    trudag.manage.create_new_item(
        prefix.strip(),
        Path(path),
        parent,
        id.strip(),
        ctx.obj["dotstop_file"],
        ctx.obj["graph"],
    )


@manage.command(name="remove-link")
@click.argument("parent", nargs=1)
@click.argument("child", nargs=1)
@click.pass_context
@utils.abort_click_on(GraphActionError)
def _remove_link(ctx: click.Context, parent: str, child: str) -> None:
    """
    Remove the link from PARENT to CHILD.

    Args:
        ctx (click.Context): Command context, including a `dotstop.Graph`.
        parent (str): Parent item name
        child (str): Child item name
    """
    ctx.obj["graph"].set_link_status(parent, child, LinkStatus.UNLINKED)
    ctx.obj["graph"].to_file(ctx.obj["dotstop_file"])


@manage.command(name="remove-item")
@click.argument("items", nargs=-1)
@click.pass_context
@utils.abort_click_on(GraphActionError, FileExistsError)
def _remove_item(ctx, items: tuple[str, ...]) -> None:
    """
    Remove the item named `name` and all links to it.

    The Markdown file containing the item's definition will not be removed.\f

    Args:
        ctx (click.Context): Command context, including a `dotstop.Graph`.
        items (tuple[str, ...]): Name of the item(s) to be removed.

    """
    for item in items:
        ctx.obj["graph"].remove_item(item)
    ctx.obj["graph"].to_file(ctx.obj["dotstop_file"])


@manage.command(name="lint", short_help="Check the graph for issues.")
@fail_on_error_option
@click.option(
    "--diff",
    type=str,
    help="Compare the lint warnings of current graph with a graph in the given git branch",
)
@click.option(
    "--dump",
    type=Path,
    help="Dumps the result into a specified path. Works if not used with `--diff`. Extensions allowed: `.json`",
)
@click.pass_context
@utils.abort_click_on(ItemError, GitError, ValueError)
def _lint(
    ctx: click.Context, fail_on_error: bool, diff: str, dump: Path | None
) -> None:
    """
    Log all issues with the Graph.\f

    Args:
        ctx (click.Context): Command context, including a `dotstop.Graph`.
        fail_on_error: bool, fails lint command if there's an error during linting.
        diff (str): Optional branch name to compare the current graph against for lint differences.
        dump (Path | None): Dumps the result into a specified path. Extension determines the format of the dump.
            - Works if not used with `diff`
            - Allowed extensions: `.json`

    """
    if diff:
        exit_code = trudag.manage.lint_diff(ctx.obj["graph"], diff, ctx.obj["workers"])
    else:
        exit_code = trudag.manage.lint(ctx.obj["graph"], dump, ctx.obj["workers"])

    if fail_on_error:
        ctx.exit(exit_code)


@manage.command(name="migrate")
@click.pass_context
def _migrate(ctx: click.Context) -> None:
    """
    Convert a doorstop database to dot.\f

    Args:
        ctx (click.Context): Command context, including output path.
    """
    build_trustable_graph(doorstop_source=doorstop.build()).to_file(
        ctx.obj["dotstop_file"]
    )


@click.command(
    name="score",
    short_help="Compute the Trustable Score of every item.",
)
@validate_option
@dump_option
@click.pass_context
@utils.abort_click_on(DotstopError, PluginError)
def _score(ctx: click.Context, validate: bool, dump: Path | None = None) -> None:
    """
    Recursively compute the Trustable score of all items in the Graph.

    Scores are computed upwards from the Evidence items, with items that are not
    scored assumed to have score zero. Suspect links and unreviewed items are
    ignored when computing scores.\f


    Args:
        ctx (click.Context): Command context, including a `dotstop.Graph`.
        validate (bool): Run automated validators.
        dump (Path): Output file path for the Trustable Scores file
    """
    all_scores = trudag.score.score(ctx.obj["graph"], validate, dump)
    for key, value in all_scores.items():
        click.echo(f"{key} = {value}")


@click.pass_context
def __remote_graph_build(ctx: click.Context):
    """
    Helper function to build remote graphs only when they are required
    This should be used only in the remote command group.
    """
    # we don't need to validate here as the command level already do it for us.
    if flter := ctx.params.get("to", ctx.params.get("alias")):
        remotes = {
            alias: config
            for alias, config in ctx.obj["remote_config"].items()
            if alias in flter
        }
        with RemoteGraph.temporary_folder_change(RemoteGraph.make_remote_folder()):
            ctx.obj["remote_graphs"] = RemoteGraph.build_remote_graph(
                remote_base_path=Path(),
                dotstop_entry_point=utils.DOTSTOP_DEFAULT_FILENAME,
                remote_configs=remotes,
                build_graph_func=build_trustable_graph,
            )
    else:
        raise click.ClickException("Failed to build remote graph")


@click.group(name="remote", help="Remote graph pulling options.")
@click.pass_context
@utils.abort_click_on(SchemaError)
def remote(ctx: click.Context):
    if (
        remote_conf := utils.get_workdir() / Path(RemoteGraph.REMOTE_CONFIG)
    ) and remote_conf.exists():
        ctx.obj["remote_config"] = RemoteGraph.load_remote_config(remote_conf)
    else:
        raise click.ClickException(
            "Missing remote definitions, not proceeding with any command"
        )


@remote.command(name="show", help="Show the whole remote graph")
@click.argument("alias", type=RemoteGraph.AliasChoice())
@click.pass_context
def _show_remote(ctx: click.Context, alias: str):
    __remote_graph_build()
    click.echo(f"Graph aliased as {alias}")
    click.echo(utils.OUTPUT_SEPARATOR)
    click.echo(ctx.obj["remote_graphs"][alias])
    click.echo(utils.OUTPUT_SEPARATOR)


@remote.command(name="pull")
@click.pass_context
@click.option(
    "--netrc-file",
    type=click.Path(exists=False, dir_okay=False, path_type=Path),
    default=None,
    required=False,
    help="Path to a netrc file.",
)
@utils.abort_click_on(FileNotFoundError, YAMLError, SchemaError, GitCommandError)
def _pull_remote(_ctx: click.Context, netrc_file: Path) -> None:
    workdir = Path(utils.get_root_dir())
    remote_configs = RemoteGraph.load_remote_config(
        workdir / RemoteGraph.REMOTE_CONFIG, netrc_file
    )
    remote_folder = RemoteGraph.make_remote_folder()

    with RemoteGraph.temporary_folder_change(remote_folder):
        if remote_configs:
            for alias, config in remote_configs.items():
                RemoteGraph.clone_or_update(alias, Path(alias), config)


@remote.command(
    name="score",
    help="Add one or more graphs and score them altogether",
)
@click.option(
    "--from",
    "frm",
    callback=RemoteGraph.validate_from,
    multiple=True,
    required=True,
    type=str,
    help="Item from the local graph that is going to be the anchor to append remote graph",
)
@click.option(
    "--to",
    type=RemoteGraph.AliasChoice(),
    callback=RemoteGraph.validate_to,
    multiple=True,
    required=True,
    help="Remote graph alias that is going to connected with local graph",
)
@click.option(
    "--destination",
    type=click.Path(
        exists=False,
        readable=False,
        path_type=Path,
    ),
    default=Path(RemoteGraph.MERGE_FOLDER),
    required=False,
    help="Results folder",
)
@click.option(
    "--output-prefix",
    "prefix",
    type=str,
    default="merged",
    required=False,
    help="Prefix that will attached to result files",
)
@utils.abort_click_on(
    GitCommandError,
    utils.InvalidGitRepositoryError,
)
@click.pass_context
def _remote_score(
    ctx: click.Context,
    frm: tuple[str, ...],
    to: tuple[str, ...],
    destination: Path,
    prefix: str,
):
    __remote_graph_build()
    remote_root = RemoteGraph.make_remote_folder().absolute()
    destination.mkdir(exist_ok=True, parents=True)
    with RemoteGraph.temporary_folder_change(destination):
        local_graph = ctx.obj["graph"]
        remote_graphs = ctx.obj["remote_graphs"]
        all_scores = trudag.score.scores_from_graph(local_graph)
        if len(frm) == 1:
            if len(to) > 1:
                logger.debug(
                    f"Connecting {frm[0]} two or more remote graphs {', '.join(to)} into same node"
                )
            for graph in to:
                if not (remote_root / Path(graph)).exists():
                    raise click.ClickException(
                        f"Missing remote graph {graph} content, you need to run trudag remote pull first"
                    )
                with RemoteGraph.temporary_folder_change(remote_root / Path(graph)):
                    remote = remote_graphs.get(graph).add_namespace(graph)
                    all_scores.update(trudag.score.scores_from_graph(remote))
                    local_graph.add_remote_graph(frm[0], remote)
        elif RemoteGraph.validate_pairs(frm, to):
            for pair in zip(frm, to):
                with RemoteGraph.temporary_folder_change(remote_root / Path(pair[-1])):
                    remote = remote_graphs.get(pair[-1]).add_namespace(pair[-1])
                    all_scores.update(trudag.score.scores_from_graph(remote))
                    local_graph.add_remote_graph(pair[0], remote)

        with Path(f"{prefix}-scores").open("w") as p:
            for key, score in all_scores.items():
                p.write(f"{key}={score}\n")

        local_graph.to_file(Path(f"{prefix}-graphs.dot"))


@remote.command(name="show-item")
@click.argument("items", nargs=-1)
@click.option(
    "--statement",
    type=bool,
    is_flag=True,
    show_default=True,
    help="Display item statement.",
)
@click.argument(
    "remote",
    type=RemoteGraph.AliasChoice(),
    required=True,
)
@click.pass_context
@utils.abort_click_on(
    GraphActionError, ItemError, GitCommandError, InvalidGitRepositoryError
)
def _show_remote_item(ctx, items: tuple[str, ...], statement: bool, remote: str):
    """
    Show items current review status.\f

    Args:
        ctx (click.Context): Command context, including a `dotstop.Graph`.
        item (tuple[str, ...]): Item(s) to be described.
        statement (bool): Adds statement information in the output
        remote(str): remote alias used to build remote graph
    """

    click.echo(f"Displaying items from repo aliased as {remote}")
    with RemoteGraph.temporary_folder_change(RemoteGraph.make_remote_folder()):
        remote_graph = RemoteGraph.build_remote_graph(
            remote_base_path=Path(),
            dotstop_entry_point=utils.DOTSTOP_DEFAULT_FILENAME,
            remote_configs={remote: ctx.obj["remote_config"][remote]},
            build_graph_func=build_trustable_graph,
        )

        for item in items:
            output = trudag.manage.describe_item(remote_graph[remote], item, statement)
            click.echo(utils.OUTPUT_SEPARATOR)
            click.echo(output)
            click.echo(utils.OUTPUT_SEPARATOR)


main.add_command(_publish)
main.add_command(_plot)
main.add_command(_score)
main.add_command(manage)
main.add_command(remote)


if __name__ == "__main__":
    main()
