# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

"""
Extensible classes for storing References to Artifacts
"""

import hashlib
import tabulate
import pygments.lexers
import urllib
import logging
import os
import re

from abc import ABC, abstractmethod
from pathlib import Path


from trudag.dotstop.core.exception import ReferenceError


logger = logging.getLogger(__name__)


class BaseReference(ABC):
    """
    Abstract base class for defining References to Artifacts.

    Concrete subclasses of [`BaseReference`][trudag.dotstop.core.reference.references.BaseReference] are
    identified by their [`type`][trudag.dotstop.core.reference.references.BaseReference.type] property and:

    - Are expressible as a string of valid markdown using [`as_markdown()`][trudag.dotstop.core.reference.references.BaseReference.as_markdown]
    - Have a persistent sha256 checksum [`sha`][trudag.dotstop.core.reference.references.BaseReference.sha]
    - Express a relationship to a specific sequence of `bytes`, [`content`][trudag.dotstop.core.reference.references.BaseReference.content]
    """

    @property
    def sha(self) -> str:
        """
        The content of the Referenced Artifact as a sha256 checksum, formatted as a hexadecimal `str`.

        Raises a `ReferenceError` if the content cannot accessed.
        """
        hash = hashlib.sha256()
        hash.update(self.content)
        return hash.hexdigest()

    @classmethod
    def from_dict(
        cls, reference_dict: dict[str, bool | int | float | str]
    ) -> "BaseReference":
        """
        Construct a [`BaseReference`][trudag.dotstop.core.reference.references.BaseReference] from a dictionary with the appropriate `type` value.

        Raises a `ReferenceError` if the object cannot be built.

        Args:
            reference_dict (dict[str, bool | int | float | str]): Dictionary used to construct [`BaseReference`][trudag.dotstop.core.reference.references.BaseReference] instance.
        """
        if reference_dict["type"] != cls.type():
            err_msg = f"Cannot construct reference of type {cls.type()} from data of type {reference_dict['type']}."
            raise ReferenceError(err_msg)
        args = {key: value for (key, value) in reference_dict.items() if key != "type"}

        try:
            obj = cls(**args)
        except TypeError as err:
            err_msg = (
                f"Cannot construct reference of type {reference_dict['type']}: {err}"
            )
            raise ReferenceError(err_msg) from err
        return obj

    @classmethod
    @abstractmethod
    def type(cls) -> str:
        """
        A unique human-readable identifier for the Reference.

        This identifier is used by [`ReferenceBuilder`][trudag.dotstop.core.reference.builder.ReferenceBuilder] to select the appropriate reference type.
        This type is usually specified in non-python contexts, such as markdown frontmatter.
        """
        ...

    @property
    @abstractmethod
    def content(self) -> bytes:
        """
        The content of the Referenced Artifact as `bytes`.
        """

    @abstractmethod
    def as_markdown(self, filepath: Path | None = None) -> str:
        """
        The content of the Referenced Artifact as a string of valid markdown.

        The optional argument `filepath` is provided to allow subclasses of [`BaseReference`][trudag.dotstop.core.reference.references.BaseReference] to express links to other documentation or data.
        This is required as markdown links are always relative.

        Args:
            filepath (Path | None, optional): Path to markdown file being written to. Defaults to None.
        """
        ...


class FileReference(BaseReference, ABC):
    """
    Abstract base class for References to Artifacts that are regular files.

    Provides a concrete implementation of  [`as_markdown()`][trudag.dotstop.core.reference.references.FileReference.as_markdown].
    """

    _FILE_REFERENCE_FORMATS = [
        alias
        for _, aliases, _, _ in pygments.lexers.get_all_lexers()
        for alias in aliases
    ]
    """
    File formats that can be written as markdown by a `FileReference`.

    Mkdocs uses pygments for syntax highlighting, so we support all file formats
    that can be lexed by pygments.
    """
    FILE_EXTENSION_ALIASES = {".yml": ".yaml", ".bst": ".yaml", ".conf": ".txt"}
    """
    Aliases for unusual file formats.

    Each key-value pair expresses a mapping from a non-standard file extension (the key) to an extension supported by [pygments](https://pygments.org/) (the value).
    This allows unusual files to be formatted correctly in a fenced markdown block.
    """

    @property
    @abstractmethod
    def extension(self) -> str:
        """
        File extension of Referenced Artifact.
        """

    def _get_extension_alias(self) -> str:
        return self.FILE_EXTENSION_ALIASES.get(self.extension, self.extension).lstrip(
            "."
        )

    def as_markdown(self, filepath: Path | None = None) -> str:  # noqa ARG001
        """
        The content of the Referenced Artifact as a string of valid markdown.

        Supports all file formats that are supported by [pygments](https://pygments.org/).

        !!! Note
            `.csv` format files are always assumed to use a comma delimiter, as
            the delimiter of a csv file cannot be reliably determined.

        Args:
            filepath (Path | None, optional): Path to markdown file being written to. Defaults to None.
        """
        if self._get_extension_alias() == "csv":
            return f"{csv_to_markdown_table(self.content.decode())}\n"

        if self._get_extension_alias() in self._FILE_REFERENCE_FORMATS:
            return f"````{self._get_extension_alias()}\n{self.content.decode()}\n````\n"

        logger.warning(
            f"Warning: Unsupported reference format {self.extension}, including as a summary only."
        )
        return f"```text\n{str(self)}\n```\n"


class LocalFileReference(FileReference):
    def __init__(self, path: str, **kwargs) -> None:
        """
        References to Artifacts that are regular local files, in the git sense.

        This means any regular file that is present in the git tree for the current
        commit of the local repository.

        Args:
            path (Path): Path to the Artifact, relative to the root of the repository.
        """
        self._path = Path(path)

    @classmethod
    def type(cls) -> str:
        return "file"

    @property
    def content(self) -> bytes:
        if not self._path.is_file():
            raise ReferenceError(
                f"Cannot get non-existent or non-regular file {self._path}"
            )
        with self._path.open("rb") as reference_content:
            return reference_content.read()

    @property
    def extension(self) -> str:
        return self._path.suffix

    def as_markdown(self, filepath: Path | None = None) -> str:
        if self._get_extension_alias() == "svg" and filepath:
            # Use of os for getting the relative path to a file is required when
            # walking up (i.e. where the resulting relative path contains one or
            #  more `..` components. pathlib only has this functionality in
            # versions >=3.12. See https://docs.python.org/3/library/pathlib.html#pathlib.PurePath.relative_to
            return f"![]({str(os.path.relpath(self._path, start=filepath.parent))})\n"
        return super().as_markdown()

    def __str__(self) -> str:
        return str(self._path)


class GitlabFileReference(FileReference):
    DEFAULT_TOKEN_ENV_VAR = "CI_JOB_TOKEN"

    def __init__(
        self,
        url: str,
        id: int,
        path: str,
        ref: str,
        token: str = "GITLAB_CI_TOKEN",
        public: bool = False,
        **kwargs,
    ) -> None:
        """
        References to Artifacts that are regular files in a remote GitLab repository.

        A valid [gitlab access token](https://docs.gitlab.com/security/tokens/) with sufficient read permissions must be available in the current environment.
        Several attempts are made to get a token, with the following precedence:

        1. User-specified `token` argument
        2. `$GITLAB_CI_TOKEN`
        3. `$CI_JOB_TOKEN`

        Args:
            url (str): Url of gitlab instance (e.g. `"gitlab.com"`)
            id (int): Repository/project id (this is an integer value, unique to repository)
            path (str): Path to the Artifact, relative to the root of the repository
            ref (str): Tag, branch or sha
            token (str, optional): Environmental variable containing a suitable access token. Defaults to "GITLAB_CI_TOKEN".
        """
        self._token_env_var = token
        self._public = public
        self._url = url
        self._id = id
        self._path = Path(path)
        self._ref = ref

    @classmethod
    def type(cls) -> str:
        return "gitlab"

    def _get_query(self, access_token: str | None = None) -> str:
        query = f"{self._url}/api/v4/projects/{str(self._id)}/repository/files/{urllib.parse.quote(str(self._path), safe='')}/raw?ref={self._ref}"
        if access_token:
            query += f"&access_token={access_token}"
        return query

    @property
    def content(self) -> bytes:
        OBSCURED_TOKEN = "*" * 10
        token = None
        if self._public:
            query = self._get_query()
        else:
            token = os.environ.get(self._token_env_var)
            if not token:
                token = os.environ.get(GitlabFileReference.DEFAULT_TOKEN_ENV_VAR)
            if not token:
                err_msg = f"Access token must be set in ${self._token_env_var} or ${GitlabFileReference.DEFAULT_TOKEN_ENV_VAR} for GET {self._get_query(access_token=OBSCURED_TOKEN)}"
                raise ReferenceError(err_msg)
            query = self._get_query(access_token=token)

        try:
            gitlab_response = urllib.request.urlopen(query)
        except urllib.error.URLError as url_error:
            err_msg = f"Could not GET {self._get_query(access_token=None if self._public else OBSCURED_TOKEN)}."
            raise ReferenceError(err_msg) from url_error
        # catches all undocumented errors
        # only URLError is noted to be raised in https://docs.python.org/3/library/urllib.request.html#urllib.request.urlopen
        except Exception as err:
            # obscure URL containing token
            obscured_args = []
            for arg in err.args:
                if isinstance(arg, str):
                    obscured_args.append(arg.replace(token, OBSCURED_TOKEN))
                else:
                    obscured_args.append(arg)
            err.args = tuple(obscured_args)

            # wrap the error
            err_msg = f"Could not GET: {err}"
            raise ReferenceError(err_msg) from err
        return gitlab_response.read()

    @property
    def extension(self) -> str:
        return self._path.suffix

    def __str__(self) -> str:
        return self._get_query()


class SourceSpanReference(BaseReference, ABC):
    @abstractmethod
    def language():
        """
        The markdown name of the language of the source code you are
        referencing.
        """

    def __init__(self, path: Path, span: list[tuple[int, int]]):
        """
        References to a span of source code in the repository.

        Probably shouldn't be used directly, but instead used as the base class for your own reference types
        that find the span of the references source code at reference-time - say, by looking up a function name.

        Args:
            path (Path): Path to the source file, relative to the root of the repository
            span (list[tuple[int,int]]): list of two 2-tuples.  The tuples are the start and end [line, character] positions
                        spanning the code we wish to reference.
        """
        self.path = path
        self.span = span
        self.code = b""
        with self.path.open("rb") as f:
            contents = f.read()
            lines = contents.splitlines(keepends=True)

        for line_num in range(
            span[0][0],
            min(span[1][0] + 1, len(lines)),
        ):
            line = lines[line_num]
            if line_num == span[0][0]:
                self.code += line[span[0][1] :]
            elif line_num == span[1][0]:
                self.code += line[: span[1][1] + 1]
            else:
                self.code += line

    @property
    def content(self) -> bytes:
        return self.code

    def as_markdown(self, filepath: Path | None = None) -> str:  # noqa ARG002
        return fence_code_block(self.content.decode(), type(self).language())

    def __str__(self) -> str:
        f"{self.path} : ({self.span[0]}) - ({self.span[1]})"


def fence_code_block(code: str, language: str) -> str:
    longest_tilde_sequence = len(max(re.compile("(~+~)*").findall(code)))
    # Code block should be a number of tildes longer than the largest number of such in the
    # fenced content, to prevent matching with anything in the content.
    delimiter = "~" * (max(longest_tilde_sequence, 3) + 1)
    return f"{delimiter}{language}\n{code}\n{delimiter}"


def csv_to_markdown_table(csv: str, delimiter: str = ",") -> str:
    """
    Given a string in csv format, return the data formatted as a GitLab-flavoured-markdown table.

    Args:
        csv (str): Data to write as a table.
        delimiter (str, optional): Character used as the column delimiter. Defaults to ",".
    """
    table = []
    for row in csv.splitlines():
        table.append(row.split(delimiter))
    return tabulate.tabulate(table, headers="firstrow", tablefmt="github")
