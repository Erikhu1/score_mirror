# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

"""
Tools for managing the construction of [`BaseReference`][trudag.dotstop.core.reference.references.BaseReference], whether they are built-in,
locally-defined plugins or packaged plugins.
"""

import importlib
import abc
import inspect
import logging

from pathlib import Path
from importlib.metadata import entry_points
from typing import Any
from functools import partial

import trudag.dotstop.core.reference as reference

logger = logging.getLogger(__name__)


class ReferenceBuilder:
    _SYSTEM_REFERENCES_ENTRY_POINT = "trustable.reference.plugins"
    _LOCAL_REFERENCES_PATH = Path(".dotstop_extensions/references.py")
    _LOCAL_REFERENCES_MODULE = "localplugins"

    def __init__(self, dir_path: Path | None = None) -> None:
        """
        Functionality for building References to Artifacts whose types are not known until runtime.

        Create a map of Reference [types][trudag.dotstop.core.reference.references.BaseReference.type] to their implementation as subclasses of [`BaseReference`][trudag.dotstop.core.reference.references.BaseReference].
        All derived subclasses of [`BaseReference`][trudag.dotstop.core.reference.references.BaseReference] are available when using this builder,
        including those provided by local and packaged plugins.

        Local reference plugins are loaded from `./.dotstop_extensions/references.py`.

        Packaged plugins are identified by the presence of a `trustable.reference.plugins` [entry point](https://packaging.python.org/en/latest/specifications/entry-points/) in their package metadata
        and imported as objects into the current module namespace.
        """
        self._reference_types = {}
        # Set up references defined by the module
        self._add_references_from_module(reference)
        # Set up reference plugins available in the current python environment
        for entry_point in entry_points(
            group=ReferenceBuilder._SYSTEM_REFERENCES_ENTRY_POINT
        ):
            self._add_references_from_module(entry_point.load())
        # Import locally defined plugins, if they exist
        if ReferenceBuilder._LOCAL_REFERENCES_PATH.is_file():
            local_spec = importlib.util.spec_from_file_location(
                ReferenceBuilder._LOCAL_REFERENCES_MODULE,
                Path.cwd() / ReferenceBuilder._LOCAL_REFERENCES_PATH
                if not dir_path
                else dir_path / ReferenceBuilder._LOCAL_REFERENCES_PATH,
            )
            localplugins = importlib.util.module_from_spec(local_spec)
            local_spec.loader.exec_module(localplugins)
            self._add_references_from_module(localplugins)

    def build(
        self, reference_dict: dict[str, bool | int | float | str]
    ) -> reference.BaseReference:
        """
        Build a [BaseReference][trudag.dotstop.core.reference.references.BaseReference] subclass, inferring [types][trudag.dotstop.core.reference.references.BaseReference.type] from dictionary field `type`.

        Args:
            reference_dict (dict[str, bool  |  int  |  float  |  str]): Dictionary to be passed to [BaseReference.from_dict][trudag.dotstop.core.reference.references.BaseReference.from_dict].
        """
        return self._reference_types[reference_dict["type"]].from_dict(reference_dict)

    def _add_references_from_module(self, module):
        for name, object in inspect.getmembers(
            module,
            partial(ReferenceBuilder.is_concrete_subclass, cls=reference.BaseReference),
        ):
            if object.type() in self._reference_types:
                logger.warning(
                    f"Reference object {object} shadows an existing Reference with name {name} and was not imported."
                )
            else:
                self._reference_types[object.type()] = object

    @staticmethod
    def is_concrete_subclass(anything: Any, cls: abc.ABCMeta) -> bool:
        """
        True if the provided object `anything` is a concrete subclass of `cls`.
        """
        return (
            inspect.isclass(anything)
            and issubclass(anything, cls)
            and not anything.__abstractmethods__
        )
