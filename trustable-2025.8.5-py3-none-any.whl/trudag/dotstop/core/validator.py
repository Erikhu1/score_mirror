# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

import importlib
import inspect
import logging
import time
from datetime import datetime


from typing import TypeAlias, Any
from importlib.metadata import entry_points
from pathlib import Path

from trudag.dotstop.core.exception import PluginError

logger = logging.getLogger(__name__)


yaml: TypeAlias = str | int | float | list["yaml"] | dict[str, "yaml"]
"""
Type alias for loaded yaml data stored as a nested `dict`/`list` data structure.
"""


class Validator:
    """
    Find, store and provide access to validator functions that are not known
    until runtime.

    On construction, the `Validator` object will collect all functions with
    the signature:

    ```python
    (configuration: dict[str, yaml]) -> Generator(Exception | Warning, None, float)
    ```

    that are available in the directory `.dotstop_extensions/validators.py`,
    or are available in module entry points belonging to the group
    `trustable.validator.plugins`.
    """

    _CONFIGURATION_PARAMETER = inspect.Parameter(
        "configuration",
        inspect.Parameter.POSITIONAL_OR_KEYWORD,
        annotation=dict[str, yaml],
    )
    _SIGNATURE = inspect.Signature(
        parameters=[_CONFIGURATION_PARAMETER],
        return_annotation=tuple[float, list[Exception | Warning]],
    )
    _SYSTEM_VALIDATORS_ENTRY_POINT = "trustable.validator.plugins"
    _LOCAL_VALIDATORS_PATH = Path.cwd() / Path(".dotstop_extensions/validators.py")
    _LOCAL_VALIDATORS_MODULE = "localplugins"

    def __init__(self) -> None:
        """
        Build a `Validator` instance.
        """
        self._validator_functions = {}
        # Set up validator plugins available in the current python environment
        for entry_point in entry_points(group=Validator._SYSTEM_VALIDATORS_ENTRY_POINT):
            if entry_point.name not in self._validator_functions:
                self._add_validators_from_module(entry_point.load())
        # Import locally defined plugins, if they exist
        if Validator._LOCAL_VALIDATORS_PATH.is_file():
            local_spec = importlib.util.spec_from_file_location(
                Validator._LOCAL_VALIDATORS_MODULE, Validator._LOCAL_VALIDATORS_PATH
            )
            localplugins = importlib.util.module_from_spec(local_spec)
            local_spec.loader.exec_module(localplugins)
            self._add_validators_from_module(localplugins)

    def _add_validators_from_module(self, module):
        for name, object in inspect.getmembers(module, Validator.is_validator_function):
            if name in self._validator_functions:
                logger.warning(
                    "Validator %s, named %s, shadows an existing validator.",
                    name,
                    object,
                )
            else:
                self._validator_functions[name] = object

    @staticmethod
    def is_validator_function(anything: Any) -> bool:
        """
        True if the provided object is a validator function.
        """
        return (
            callable(anything) and inspect.signature(anything) == Validator._SIGNATURE
        )

    def validate(self, type: str, configuration: yaml) -> float:
        """
        Call the validator function `type` with argument `configuration`.

        Log all reported Exceptions and Warnings.
        """
        validator_function = self._validator_functions.get(type)
        if validator_function:
            logger.info(f"Executing validator: {type} at {datetime.now()}")
            start_time = time.time()
            try:
                score, logs = validator_function(configuration)
                logger.info(
                    f"Validator: {type} finished execution in {time.time() - start_time:.2f}s at {datetime.now()}"
                )
            except Exception as exception:
                logger.info(
                    f"Validator: {type} failed execution in {time.time() - start_time:.2f}s at {datetime.now()}"
                )
                score = 0.0
                logs = [exception]
        else:
            score = 0.0
            err_msg = f"Cannot find a validator function for type {type}."
            logs = [PluginError(err_msg)]
        for log in logs:
            if isinstance(log, Warning):
                logger.warning(log)
            elif isinstance(log, Exception):
                logger.error(log)
            else:
                logger.info(log)
        return score


class ValidatorSingleton:
    """
    Simple class to ensure only one instance of validator exists
    """

    validator: Validator | None = None

    def get(self) -> Validator:
        if self.validator is None:
            self.validator = Validator()

        return self.validator


VALIDATOR_SINGLETON = ValidatorSingleton()
