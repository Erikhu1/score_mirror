import schema

from collections import Counter
from datetime import datetime
from trudag.dotstop.core.exception import DataModelError


def _convert_date_time(string: str) -> datetime:
    return datetime.strptime(string, "%a %b %d %H:%M:%S %Y")


_DATA_SCHEMA = schema.Schema(
    [
        {
            "scores": [{"id": str, "score": schema.Use(float)}],
            "info": {
                "Repository root": str,
                "Commit SHA": str,
                "Commit date/time": schema.And(_convert_date_time),
                "Commit tag": str,
                "CI job id": str,
                "Branch name": str,
                "Schema version": str,
            },
        }
    ],
    ignore_extra_keys=True,
)


def validate_data(data: list[dict]):
    try:
        _DATA_SCHEMA.validate(data)
        for entry in data:
            ids = [dp["id"] for dp in entry["scores"]]
            duplicate_ids = [id_ for id_, count in Counter(ids).items() if count > 1]
            if duplicate_ids:
                raise DataModelError(
                    f"the following ids are not unique {duplicate_ids}"
                )
    except (schema.SchemaError, DataModelError) as exception:
        msg = f"invalid data recieved from data store {exception}"
        raise DataModelError(msg) from exception
