import inspect
from hashlib import sha256
from importlib.metadata import version
import trudag.dotstop.core.data_store.data_model as data_model

data_model_hash = sha256(inspect.getsource(data_model).encode()).hexdigest()

SCHEMA_VERSION = version("trustable") + "_" + data_model_hash
