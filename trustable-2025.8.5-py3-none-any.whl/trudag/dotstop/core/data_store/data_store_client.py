import importlib

from inspect import getmembers, isfunction
from pathlib import Path
from typing import Callable
from trudag.dotstop import PluginError


def not_impl(name: str) -> Callable:
    def foo(*_):
        raise PluginError(f"{name} is not implemented")

    return foo


class DataStoreClient:
    """
    Class to handle interactions with the data store defined by the user in
    .dotstop_extensions/data_store.py
    """

    # Assumes working dir is projects root dir.
    _LOCAL_DSC_PATH = Path.cwd() / Path(".dotstop_extensions/data_store.py")
    _LOCAL_DSC_MODULE = "localplugins"
    _EXTERNAL_PULL_FUNC_NAME = "data_store_pull"
    _EXTERNAL_PUSH_FUNC_NAME = "data_store_push"

    def __init__(self):
        self.pull: Callable[[], list[dict]] = not_impl("DataStoreClient.pull")
        self.push: Callable[[list[dict]], None] = not_impl("DataStoreClient.push")
        if DataStoreClient._LOCAL_DSC_PATH.is_file():
            local_spec = importlib.util.spec_from_file_location(
                DataStoreClient._LOCAL_DSC_MODULE, DataStoreClient._LOCAL_DSC_PATH
            )
            localplugins = importlib.util.module_from_spec(local_spec)
            local_spec.loader.exec_module(localplugins)
            self._add_client_functions_from_module(localplugins)
        else:
            raise PluginError(f"Can't find file: {DataStoreClient._LOCAL_DSC_PATH}")

    def _add_client_functions_from_module(self, module):
        members = dict(getmembers(module, isfunction))
        self.pull = members.get(DataStoreClient._EXTERNAL_PULL_FUNC_NAME, self.pull)
        self.push = members.get(DataStoreClient._EXTERNAL_PUSH_FUNC_NAME, self.push)


class DataStoreClientSingleton:
    """
    Simple class to ensure only one instance of data store client exists
    """

    data_store_client: DataStoreClient | None = None

    def get(self) -> DataStoreClient:
        if self.data_store_client is None:
            self.data_store_client = DataStoreClient()

        return self.data_store_client


DATA_STORE_CLIENT_SINGLETON = DataStoreClientSingleton()
