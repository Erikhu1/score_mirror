# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

"""
Classes for managing the items in a [`TrustableGraph`][trudag.dotstop.core.graph.TrustableGraph].
"""

import copy
from dataclasses import dataclass
import hashlib
import yaml
import doorstop
import schema
import logging

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Callable
from trudag.dotstop.core.reference import (
    BaseReference,
    LocalFileReference,
    ReferenceBuilder,
)
from trudag.dotstop.core.validator import VALIDATOR_SINGLETON, Validator
from trudag.dotstop.core.exception import ItemError, ReferenceError, map_and_raise
from trudag.dotstop.core.fallacy import Fallacy
from trudag.dotstop.core.constants import ITEM_SEPARATOR

logger = logging.getLogger(__name__)

DOORSTOP_ITEM_SCORE_KEY = "score"
_ITEM_VALIDATOR_KEY = "evidence"
_ITEM_SCORE_SCHEMA = schema.Schema(schema.Or({str: float}, float))


def map_and_raise_itemerror(
    prefix: str, *map_from: type[Exception]
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    def map_to_itemerror(err: type[Exception], *args, **kwargs):
        if not args:
            raise TypeError(
                "map_and_raise_itemerror applies to functions with a BaseItem as the first argument. Got no arguments."
            )
        if not isinstance(args[0], BaseItem):
            err_msg = f"map_and_raise_itemerror applies to functions with a BaseItem as the first argument. Got argument of type {type(args[0])}."
            raise TypeError(err_msg)
        item = args[0]
        err_msg = f"{prefix + ': ' if prefix else ''}{item}: {err}"
        mapped_err = ItemError(err_msg)
        mapped_err.__cause__ = err
        return mapped_err

    return map_and_raise(map_to_itemerror, *map_from)


class BaseItem(ABC):
    """
    Abstract base class defining the functionality required of an item in a [`TrustableGraph`][trudag.dotstop.core.graph.TrustableGraph].
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """
        The name of the [`BaseItem`][trudag.dotstop.core.item.BaseItem].

        The [`name`][trudag.dotstop.core.item.BaseItem.name] of an item is formed of two parts separated by a hyphen: `PREFIX-ID`.

        - `PREFIX` may contain any alphanumeric or special character except `.` and `"`.
          This is called the document prefix.
          Items with the same document prefix are grouped together in a [`TrustableGraph`][trudag.dotstop.core.graph.TrustableGraph] as a [document][trudag.dotstop.core.graph.TrustableGraph.documents].
        - `ID` may contain any alphanumeric or special character except `.`, `"` and `-`.
          This is used to uniquely identify the [`BaseItem`][trudag.dotstop.core.item.BaseItem] within a document.
        """
        ...

    @name.setter
    @abstractmethod
    def name(self, value: str) -> None: ...
    @property
    @abstractmethod
    def score(self) -> float | None:
        """
        The probability that the Statement associated with the [`BaseItem`][trudag.dotstop.core.item.BaseItem] is True.

        This is an estimate produced by aggregating the self-assessed confidence of Calibrated SMEs.
        """
        ...

    @property
    @abstractmethod
    def sme_scores(self) -> dict[str, float] | None:
        """
        The SME scores associated with [`BaseItem`][trudag.dotstop.core.item.BaseItem]
        """
        ...

    @property
    def sha(self) -> str:
        """
        A sha256 checksum of the item's [`text`][trudag.dotstop.core.item.BaseItem.text], [`name`][trudag.dotstop.core.item.BaseItem.name], [`references()`][trudag.dotstop.core.item.BaseItem.references] and [`fallacies()`][trudag.dotstop.core.item.BaseItem.fallacies]
        """
        return self.sha256().hexdigest()

    @property
    @abstractmethod
    def text(self) -> str:
        """
        The Statement associated with a Normative [`BaseItem`][trudag.dotstop.core.item.BaseItem].

        If the [`BaseItem`][trudag.dotstop.core.item.BaseItem] is not Normative, then this can be any valid markdown.
        """
        ...

    @property
    @abstractmethod
    def normative(self) -> bool:
        """
        `True` if the [`BaseItem`][trudag.dotstop.core.item.BaseItem] represents a Normative Statement, `False` otherwise.
        """
        ...

    @property
    def document(self) -> str:
        """
        Prefix of the document the item belongs to.
        """
        return ITEM_SEPARATOR.join(str(self).split(ITEM_SEPARATOR)[0:-1])

    @property
    @abstractmethod
    def order(self) -> "ItemOrder":
        """
        Defines item ordering for a report within a document prefix.

        Item ordering is managed through "group" and "order".

        Using group would group the items with the same group name.
        Group themselves are ordered by the group name.
        Order applies within a group sorted from low to high numbers.

        If group is unspecified, those items would be pushed to the top and the order property applies to ungrouped items.

        If order is unspecified, those items would be pushed to the top of the group, and it would be automatically sorted by name.

        Returns:
            t (ItemOrder)
        """
        ...

    @property
    @abstractmethod
    def _level(self) -> doorstop.core.types.Level | None:
        """
        Item ordering from the legacy doorstop backend.

        Note that the new `order` item ordering takes priority over this.
        Using `order` and `_level` together will force `order` to be prioritised first.

        !!! warning
            '_level' is closely tied to the doorstop data model. It is therefore
            unstable and may be subject to frequent breaking changes.
        """
        ...

    @abstractmethod
    def header(self, include_name: bool = True) -> str:
        """
        A short text summary of the [`BaseItem`][trudag.dotstop.core.item.BaseItem], containing more information than the [`name`][trudag.dotstop.core.item.BaseItem.name] alone.

        Args:
            include_name (bool, optional): Prepend the Item's [`name`][trudag.dotstop.core.item.BaseItem.name]. Defaults to True.
        """
        ...

    @abstractmethod
    def references(self) -> list[BaseReference]:
        """
        A list of the Artifacts referenced by the [`BaseItem`][trudag.dotstop.core.item.BaseItem].
        """
        ...

    @abstractmethod
    def fallacies(self) -> dict[str, Fallacy]:
        """
        The list of [`Fallacy`][trudag.dotstop.core.fallacy.Fallacy]s associated with the [`BaseItem`][trudag.dotstop.core.item.BaseItem]'s Statement.
        """
        ...

    @abstractmethod
    def validate(self) -> float | None:
        """
        The probability that the Statement associated with the [`BaseItem`][trudag.dotstop.core.item.BaseItem] is True.

        This is an estimate produced by executing a Validator for the Item.
        """
        ...

    def __str__(self) -> str:
        return self.name

    def __lt__(self, other: "BaseItem") -> bool:
        if self._level is not None and other._level is None:
            return False
        if other._level is not None and self._level is None:
            return True

        if (
            not self.order.order_specified()
            and not other.order.order_specified()
            and self._level is None
            and other._level is None
        ):
            return self.name < other.name
        if self.order.order_specified() or other.order.order_specified():
            return self._item_order_both_defined(other)

        return self._item_order_legacy(other, other._level)

    def _item_order_both_defined(self, other: "BaseItem") -> bool:
        if self.order.group == other.order.group:
            if self.order.priority is None and other.order.priority is None:
                return self.name < other.name
            if self.order.priority is None:
                return True
            if other.order.priority is None:
                return False
            return self.order.priority < other.order.priority
        if self.order.group is None:
            return True
        if other.order.group is None:
            return False
        return self.order.group < other.order.group

    def _item_order_legacy(
        self, other: "BaseItem", other_level: doorstop.core.types.Level
    ) -> bool:
        if self._level == other_level:
            return self.name < other.name
        return self._level < other_level

    def sha_link(self, child: "BaseItem") -> str:
        """
        A sha256 checksum of the link between `self` and `child`.

        Computed from the [`sha`][trudag.dotstop.core.item.BaseItem.sha]s of `self` and of `child`.
        """
        hash = hashlib.sha256()
        hash.update(self.sha256().digest() + child.sha256().digest())
        return hash.hexdigest()

    @map_and_raise_itemerror("Cannot get sha", ReferenceError)
    def sha256(self) -> hashlib.sha256:
        hash = hashlib.sha256()
        hash.update(str(self).encode())
        hash.update(self.text.encode())
        hash.update(self.normative.to_bytes(1, "little"))
        for reference in self.references():
            hash.update(reference.sha.encode())
        for id, fallacy in self.fallacies().items():
            hash.update(id.encode())
            hash.update(fallacy.sha.encode())
        return hash


@dataclass
class ItemOrder:
    """
    Storage for item order.

    For more information, check BaseItem.order.
    """

    group: str | None
    priority: int | None

    def __init__(self, group: str | None, order: int | None) -> None:
        self.group = group
        self.priority = order

    def order_specified(self) -> bool:
        return (self.group is not None) or (self.priority is not None)


class DoorstopItem(BaseItem):
    def __init__(self, name: str) -> "DoorstopItem":
        """
        A facade for doorstop items that ensures safe use with a [`TrustableGraph][trudag.dotstop.core.graph.TrustableGraph].
        """
        self._doorstop_item = doorstop.core.item.UnknownItem(name)

    @property
    def name(self) -> str:
        return self._doorstop_item.uid.value

    @name.setter
    @abstractmethod
    def name(self, value: str) -> None:
        logger.warning(
            "Changing doorstop name during runtime is not supported for a DoorstopItem"
        )
        return

    @property
    def score(self) -> float | None:
        if self._doorstop_item.attribute(DOORSTOP_ITEM_SCORE_KEY):
            score = _ITEM_SCORE_SCHEMA.validate(
                self._doorstop_item.attribute(DOORSTOP_ITEM_SCORE_KEY),
            )
            if isinstance(score, float):
                return score
            return sum(score.values()) / len(score.values())
        return None

    @property
    def text(self) -> str:
        return self._doorstop_item.text

    @property
    def normative(self) -> bool:
        return self._doorstop_item.normative

    @property
    def _level(self) -> doorstop.core.types.Level | None:
        return self._doorstop_item.level

    @property
    def order(self) -> ItemOrder:
        return ItemOrder(None, None)

    def header(self, include_name: bool = True) -> str:
        header_preamble = self._doorstop_item.uid.value + ":" if include_name else ""

        if self._doorstop_item.header:
            return header_preamble + " " + self._doorstop_item.header

        if self._doorstop_item.itemformat == "yaml":
            # For yaml, we naively take the first non-empty line.
            lines = [line for line in self.text.splitlines() if line]
            if not lines:
                raise ItemError(
                    f"Cannot get header for body-less item {self.uid.value}",
                )
            return header_preamble + " " + lines[0]

        if self._doorstop_item.itemformat == "markdown":
            # For markdown, we take the first non-empty line, using the Markdown syntax definition of a line.
            lines = list(self.text.strip().splitlines())
            if not lines:
                raise ItemError(
                    f"Cannot get header for body-less item {self.name}",
                )
            header = header_preamble
            for line in lines:
                if line:
                    header += " " + line.strip()
                else:
                    break
            return header

        raise Exception(
            f"Cannot get header for unsupported format {self._doorstop_item.itemformat}.",
        )

    def references(self) -> list[BaseReference]:
        references = self._doorstop_item.data.get("references", [])
        return [
            LocalFileReference.from_dict(reference)
            for reference in references
            if reference
        ]

    def fallacies(self) -> dict[str, Fallacy]:
        logger.warning(
            "Fallacies not supported for DoorstopItem %s.",
            str(self),
        )
        return {}

    def validate(self) -> float | None:
        logger.warning(
            "Automated Validation not supported for DoorstopItem %s.",
            str(self),
        )
        return None

    @staticmethod
    def from_doorstop_item(item: doorstop.core.Item) -> "DoorstopItem":
        """
        Build a [`DoorstopItem`][trudag.dotstop.core.item.DoorstopItem] from a `doorstop.core.Item`.
        """
        new_item = DoorstopItem(item.uid.value)
        new_item._doorstop_item = item
        return new_item


class MarkdownItem(BaseItem):
    _FRONTMATTER_SCHEMA = schema.Schema(
        {
            "normative": bool,
            schema.Optional("references"): list,
            schema.Optional("evidence"): {"type": str, "configuration": dict},
            schema.Optional("ref"): str,
            schema.Optional("reviewed"): str,
            schema.Optional("active"): bool,
            schema.Optional("derived"): bool,
            schema.Optional("links"): [{str: str}],
            schema.Optional("level"): schema.Or(
                schema.Regex(r"[0-9]+(\.[0-9]+)*"), float
            ),
            schema.Optional("score"): schema.Or(float, schema.Schema({str: float})),
            schema.Optional("fallacies"): {
                str: {"description": str, "reference": dict},
            },
            schema.Optional("publish"): {
                schema.Optional("group"): str,
                schema.Optional("order"): int,
            },
        },
        ignore_extra_keys=True,
    )
    """
    Schema defining allowed fields and structure in the frontmatter.
    """

    @map_and_raise_itemerror("Invalid frontmatter", schema.SchemaError)
    @map_and_raise_itemerror("Invalid reference", ReferenceError)
    def __init__(
        self,
        name: str,
        text: str,
        frontmatter: dict,
        reference_builder: ReferenceBuilder = ReferenceBuilder(),
        validator: Validator | None = None,
    ) -> None:
        """
        An item in a [`BaseGraph`][trudag.dotstop.core.graph.TrustableGraph] which is stored as markdown.

        Args:
            name (str): Name for the item.
            text (str): Statement associated with the item if Normative, otherwise any valid markdown.
            frontmatter (dict): yaml frontmatter describing the Item's properties.
            reference_builder (ReferenceBuilder, optional): Use to build the Item's References. Defaults to ReferenceBuilder().
            validator (Validator, optional): Use to provide the Item's Validator plugin. Defaults to Validator().
        """
        self._name = name
        self.__validator = validator or None
        # `_data` member captures the raw data (as built-in types) that describe
        # the contents of the markdown file that stores the item definition.
        self._data = MarkdownItem._FRONTMATTER_SCHEMA.validate(frontmatter)
        self._data["text"] = text

        self._references = [
            reference_builder.build(ref) for ref in frontmatter.get("references", [])
        ]
        self._fallacies = {
            id: Fallacy(
                fallacy["description"],
                reference_builder.build(fallacy["reference"]),
            )
            for id, fallacy in frontmatter.get("fallacies", {}).items()
        }

    @property
    def _validator(self) -> Validator:
        if self.__validator is None:
            self.__validator = VALIDATOR_SINGLETON.get()

        return self.__validator

    def __item_header(self) -> str:
        """
        A helper function for `self.header()`  and according to
        https://doorstop.readthedocs.io/en/v3.0/reference/item.html#level: if the level
        ends with .0 and the item is non-normative, [...] the item is treated as a
        document heading
        """
        if self._level and self._level.value[-1] == 0 and not self.normative:
            return self.text
        return ""

    def header(self, include_name: bool = True) -> str:
        header_preamble: str = self.name + ":" if include_name else ""
        if self.__item_header():
            return header_preamble + " " + self.__item_header()
        lines: list[str] = self.text.strip().splitlines()
        if not lines:
            raise ItemError(
                f"Cannot get header for body-less item {self.name}",
            )
        line: str
        for line in lines:
            if line:
                header_preamble += " " + line.strip()
            else:
                break
        return header_preamble

    def references(self) -> list[BaseReference]:
        return self._references

    def fallacies(self) -> dict[str, Fallacy]:
        return self._fallacies

    @property
    def text(self) -> str:
        return self._data.get("text", "")

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value

    @property
    def normative(self) -> bool:
        return self._data.get("normative", False)

    @property
    def _level(self) -> doorstop.core.types.Level:
        level_raw = self._data.get("level")
        if level_raw is None:
            return None
        return doorstop.core.types.Level(value=level_raw)

    @property
    def order(self) -> ItemOrder:
        publish = self._data.get("publish", {})
        return ItemOrder(publish.get("group"), publish.get("order"))

    @property
    def score(self) -> float | None:
        if "score" in self._data:
            score = _ITEM_SCORE_SCHEMA.validate(self._data["score"])
            if isinstance(score, float):
                return score
            return sum(score.values()) / len(score.values())
        return None

    @property
    def sme_scores(self) -> dict[str, float] | None:
        score_data = self._data.get("score")
        if score_data is None:
            return None

        validated_score = _ITEM_SCORE_SCHEMA.validate(score_data)

        if isinstance(validated_score, float):
            return None

        return validated_score

    def as_markdown(self) -> str:
        """
        Write the [`MarkdownItem`][trudag.dotstop.core.item.MarkdownItem] as a markdown string, including frontmatter.
        """
        data: dict[str, Any] = copy.copy(self._data)
        text: str = data.pop("text", "")

        return "---\n" + (str(yaml.safe_dump(data)) or "") + "---\n\n" + text

    def validate(self) -> float | None:
        if self._data.get("evidence"):
            return self._validator.validate(
                self._data["evidence"]["type"], self._data["evidence"]["configuration"]
            )
        return None

    @staticmethod
    def _get_default_markdown_object() -> dict[str, Any]:
        """
        Returns the simplest object needed to populate a `Markdown` item
        Args:

        Returns: `dict[str, Any]`
        """
        return {
            "normative": True,
            "level": 1.1,
        }

    @classmethod
    def create_default_item(
        cls,
        dirpath: Path,
        item_name: str,
        reference_builder: ReferenceBuilder = ReferenceBuilder(),
        validator: Validator | None = None,
    ) -> "MarkdownItem":
        """
        Create an empty item named `f"{item_name}.md"` in `dirpath`.

        Args:
            dirpath (Path): Path to directory to create Item in.
            item_name (str): Name of item.
            reference_builder (ReferenceBuilder, optional): Use to build the Item's References. Defaults to ReferenceBuilder().
            validator (Validator, optional): Use to provide the Item's Validator plugin. Defaults to Validator().
        """
        item = cls(
            item_name,
            "",
            cls._get_default_markdown_object(),
            reference_builder=reference_builder,
            validator=validator,
        )

        filename: Path = dirpath / f"{item_name}.md"
        if filename.exists():
            err_msg = f"Cannot create MarkdownItem {item_name}. Filename {filename} already exists."
            raise FileExistsError(err_msg)

        with filename.open("w") as file:
            file.write(item.as_markdown())

        return item

    @classmethod
    def from_markdown(
        cls,
        item_name: str,
        markdown_str: str,
        reference_builder: ReferenceBuilder = ReferenceBuilder(),
        validator: Validator | None = None,
    ) -> "MarkdownItem":
        """
        Build a [`MarkdownItem`][trudag.dotstop.core.item.MarkdownItem] from a string of markdown and a name.

        Args:
            item_name (str): Name of the item.
            markdown_str (str): Contents of the markdown file.
            reference_builder (ReferenceBuilder, optional): Use to build the Item's References. Defaults to ReferenceBuilder().
            validator (Validator, optional): Use to provide the Item's Validator plugin. Defaults to Validator().

        Raises:
            ItemError: If handled error is encountered
        """
        front_delimiter: str = "---"
        splits = markdown_str.split(front_delimiter, 2)
        if len(splits) <= 2 or not splits[1]:
            err_msg = f"Cannot build MarkdownItem {item_name} without frontmatter and content."
            raise ItemError(err_msg)
        try:
            yaml_frontmatter = yaml.safe_load(splits[1])
        except yaml.scanner.ScannerError as err:
            raise ItemError(f"Invalid frontmatter:\n{err}") from None

        return MarkdownItem(
            item_name,
            splits[2].strip("\n"),
            yaml_frontmatter,
            reference_builder=reference_builder,
            validator=validator,
        )
