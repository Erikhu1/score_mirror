"""
Categories of Error that can be encountered when using dotstop.
"""

from typing import Callable, Any


class DotstopError(Exception):
    """
    Generic Exception for all Errors encountered by the dotstop library.
    """


class PluginError(DotstopError):
    """
    An Error encountered when using a plugin.
    """


class DataModelError(Exception):
    """
    An Error caused by a mismatch between the data schema used by the tool and the data schema used by a store.
    """


class GraphActionError(DotstopError):
    """
    An Error caused by trying to perform a invalid action (e.g. a query or operation) on a valid graph.
    """


class GraphStructureError(DotstopError):
    """
    An Error caused by trying create (or perform a valid action on) an invalid graph.
    """


class ItemError(DotstopError):
    """
    An Error caused by discovery of an invalid item, either when creating, using or modifying it.
    """


class ReferenceError(DotstopError):
    """
    An Error encountered when checking references in dotstop item
    """


class InvalidArgumentError(ValueError):
    """
    An error caused by an illegal argument value
    """


class GitError(DotstopError):
    """
    An error caused by git operation failing
    """


def map_and_raise(
    map_func: Callable[[type[Exception]], type[Exception]],
    *map_from: type[Exception],
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """
    Returns a decorator that catches all exceptions of types `map_from`, applies the function `map` to the caught exception and raises the result.
    """

    def map_err_decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        def map_err_wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return func(*args, **kwargs)
            except map_from as err:
                raise map_func(err, *args, **kwargs) from err

        return map_err_wrapper

    return map_err_decorator
