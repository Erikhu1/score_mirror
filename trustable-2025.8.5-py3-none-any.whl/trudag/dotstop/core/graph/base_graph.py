# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

from abc import ABC, abstractmethod
from pathlib import Path
import numpy as np
from collections.abc import Iterable
from typing import TypeAlias

Attribute: TypeAlias = str | int | float | None


class BaseGraph(ABC):
    """
    A base abstract class that describes abstract methods that must be implemented
    for a class to serve as the backend for TrustableGraph.
    """

    @classmethod
    @abstractmethod
    def empty(cls) -> "BaseGraph":
        """
        Create an instance of `BaseGraph` with no nodes or edges.

        """
        ...

    @classmethod
    @abstractmethod
    def from_string(cls, src: str) -> "BaseGraph":
        """
        Construct an instance of `BaseGraph` from a string source.
        """
        ...

    @abstractmethod
    def to_string(self, sort: bool = True) -> str:
        """
        Returns the graph as a string, this will also be used when writing the graph to a file.

        Args:
            sort (bool): Whether the string should sort nodes and edges to minimise git conflicts.
        """
        ...

    @classmethod
    @abstractmethod
    def from_file(cls, path: Path) -> "BaseGraph":
        """
        Construct an instance of `BaseGraph` from a file.

        Args:
            path (Path): Path to file to build graph from
        """
        ...

    @abstractmethod
    def is_directed(self) -> bool:
        """
        True if the graph is a directed graph.
        """
        ...

    def __str__(self) -> str:
        return self.to_string()

    @abstractmethod
    def set_graph_attrs(self, **attrs: Attribute) -> None:
        """
        Set the attributes for each key-value pair in `attrs` for graph.
        """
        ...

    @abstractmethod
    def get_graph_attr(self, key: str) -> Attribute:
        """
        Get the attribute assoiciated with `key` from graph.

        Returns:
            String if value exists, otherwise None
        """
        ...

    @abstractmethod
    def get_graph_attrs(self) -> dict[str, Attribute]:
        """
        Get all attributes for graph.
        """
        ...

    # Nodes methods.
    @abstractmethod
    def nodes(self) -> list[str]:
        """
        Returns all nodes contained in the graph.
        """
        ...

    @abstractmethod
    def add_node(self, node_id: str) -> None:
        """
        Add a new node with node_id to the graph.
        """
        ...

    @abstractmethod
    def remove_node(self, node_id: str) -> None:
        """
        Remove a node with node_id from the graph.
        """
        ...

    @abstractmethod
    def has_node(self, node_id: str) -> bool:
        """
        True if node with node_id exists in graph.
        """
        ...

    @abstractmethod
    def set_node_attrs(self, node_id: str, **attrs: Attribute) -> None:
        """
        Set the attributes for each key-value pair in `attrs` for node with node_id.
        """
        ...

    @abstractmethod
    def get_node_attr(self, node_id: str, key: str) -> Attribute:
        """
        Get the attribute assoiciated with `key` from node with node_id.

        Returns:
            String if value exists, otherwise None
        """
        ...

    @abstractmethod
    def get_node_attrs(self, node_id: str) -> dict[str, Attribute]:
        """
        Get all attributes for node with node_id.
        """
        ...

    # Edge methods.
    @abstractmethod
    def edges(self) -> list[tuple[str, str]]:
        """
        Returns all edges in the graph.

        Returns:
            A list of tuples reprsenting edges where the first element is  \
            the source node and the second element is the destination node.
        """

        ...

    @abstractmethod
    def add_edge(self, parent_id: str, child_id: str) -> None:
        """
        Add the edge `parent_id -> child_id` to the graph.
        """
        ...

    @abstractmethod
    def remove_edge(self, parent_id: str, child_id: str) -> None:
        """
        Remove the edge `parent_id -> child_id` from the graph.
        """
        ...

    @abstractmethod
    def has_edge(self, parent_id: str, child_id: str) -> bool:
        """
        True if the edge `parent_id -> child_id` exists in the graph.
        """
        ...

    @abstractmethod
    def set_edge_attrs(self, parent_id: str, child_id: str, **attrs: Attribute) -> None:
        """
        Set the attributes for each key-value pair in `attrs` for edge `parent_id -> child_id`.
        Attributes should operate like a dictionary, existing attributes are updated, new attributes are appended.
        """
        ...

    @abstractmethod
    def get_edge_attr(self, parent_id: str, child_id: str, key: str) -> Attribute:
        """
        Get the attribute associated with `key` from edge parent_id -> child_id.

        Returns:
            String if attribute exists, otherwise None.
        """
        ...

    @abstractmethod
    def get_edge_attrs(self, parent_id: str, child_id: str) -> dict[str, Attribute]:
        """
        Get all attributes of edge `parent_id -> child_id`.
        """
        ...

    # Graph methods (overridable).
    def predecessors(self, child_id: str) -> list[str]:
        """
        Returns nodes which have an outgoing edge to the specified node.
        """
        return [src for src, dst in self.edges() if dst == child_id]

    def successors(self, parent_id: str) -> list[str]:
        """
        Returns nodes which have an incoming edge from the specified node.
        """
        return [dst for src, dst in self.edges() if src == parent_id]

    def leaf_nodes(self) -> list[str]:
        """
        Returns nodes with no outgoing edges.
        """
        all_nodes = set(self.nodes())
        nodes_with_outgoing = {src for src, _ in self.edges()}
        return list(all_nodes - nodes_with_outgoing)

    def root_nodes(self) -> list[str]:
        """
        Return nodes with no incoming edges.
        """
        all_nodes = set(self.nodes())
        nodes_with_incoming = {dst for _, dst in self.edges()}
        return list(all_nodes - nodes_with_incoming)

    def adjacency_matrix(self, node_order: Iterable[str]) -> np.ndarray:
        """
        The unweighted adjacency matrix of the graph.

        Args:
            node_order (Iterable[str]): The order of nodes in the adjacency matrix.
        """
        node_to_index = {node_id: idx for idx, node_id in enumerate(node_order)}
        num_nodes = len(node_to_index)
        adjacency = np.zeros((num_nodes, num_nodes))
        for src, dst in self.edges():
            adjacency[node_to_index[src]][node_to_index[dst]] = 1.0
        return adjacency
