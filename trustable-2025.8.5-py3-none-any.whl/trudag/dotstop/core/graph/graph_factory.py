# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

from collections import defaultdict

import doorstop
from pathlib import Path
from trudag.dotstop.core.exception import DotstopError, GraphStructureError
from trudag.dotstop.core.item import BaseItem, DoorstopItem, MarkdownItem
from trudag.dotstop.core.graph import TrustableGraph, LinkStatus, PydotGraph, BaseGraph
from trudag.dotstop.core.reference.builder import ReferenceBuilder
from functools import cache


@cache
def _ref_builder(dir_path):
    # note we must wrap this as you cannot cache a constructor
    return ReferenceBuilder(dir_path=dir_path)


def build_trustable_graph(
    graph_source: Path | str | None = None,
    items_source: Path | list[BaseItem] | None = None,
    doorstop_source: doorstop.Tree | None = None,
    trustable_ignore: Path | None = None,
) -> TrustableGraph:
    """
    Builds a TrustableGraph from given sources.

    Args:
        graph_source(Path | str | None): DOT file path or string, or None for an empty graph.
        items_source(Path | list[BaseItem] | None): Markdown directory path, raw items list, or None for an empty list.
        doorstop_source(doorstop.Tree | None): Doorstop tree provides items and graph (legacy).
        trustable_ignore (Path | None) : trustable ignore file like gitignore without globs feature.

    Returns:
        TrustableGraph: Complete TrustableGraph object.
    """

    if doorstop_source:
        return _graph_from_doorstop(doorstop_source)

    graph = _load_base_graph(graph_source)
    items = _load_base_items(
        graph.nodes(), items_source, trustable_ignore=trustable_ignore
    )

    return TrustableGraph(graph, items)


def _load_base_graph(source: Path | str | None = None) -> BaseGraph:
    if source is None:
        graph = PydotGraph()
    elif isinstance(source, Path):
        graph = PydotGraph.from_file(source)
    elif isinstance(source, str):
        graph = PydotGraph.from_string(source)
    else:
        raise DotstopError(f"Invalid graph source type: {type(source)}")
    return graph


def _load_base_items(
    item_names: list[str],
    source: Path | list[BaseItem] | None = None,
    trustable_ignore: Path | None = None,
) -> list[BaseItem]:
    if source is None:
        items: list[BaseItem] = []
    elif isinstance(source, Path):
        items = _md_items_from_dir(source, item_names, trustable_ignore)
    elif isinstance(source, list):
        items = source
    else:
        raise DotstopError(f"Invalid items source type: {type(source)}")
    return items


def _load_excluded_content(ignore_file: Path) -> set[str]:
    """
    Simple ignore list that accept files or folders, it doesn't support
    globbing.
    """

    with ignore_file.open() as f:
        return {line.strip() for line in f if line.strip() and not line.startswith("#")}


def _filter_content(path: Path, root: Path, excluded_dirs: set[str]) -> bool:
    rel_parts = path.relative_to(root).parts
    return any(
        rel_parts[: len(Path(excl).parts)] == tuple(Path(excl).parts)
        for excl in excluded_dirs
    )


def _md_items_from_dir(
    dir_path: Path, item_names: list[str], trustable_ignore: Path | None = None
) -> list[BaseItem]:
    file_iter = dir_path.rglob("*.md")
    if trustable_ignore and (
        ignore_content := _load_excluded_content(trustable_ignore)
    ):
        file_iter = (
            md_file
            for md_file in file_iter
            if not _filter_content(md_file, dir_path, ignore_content)
        )

    name_to_files = defaultdict(list)

    for file in file_iter:
        name_to_files[file.stem].append(file)

    items = []

    for name in item_names:
        files = name_to_files[name]
        if not files:
            raise FileNotFoundError(f"Could not find file for item {name}")
        if len(files) > 1:
            duplicate_files = "\n".join(str(file) for file in files)
            raise GraphStructureError(
                f"Found multiple files for item {name}: \n{duplicate_files}"
            )
        items.append(
            MarkdownItem.from_markdown(
                name,
                files[0].read_text(),
                reference_builder=_ref_builder(dir_path),
            )
        )
    return items


def _graph_from_doorstop(tree: doorstop.Tree) -> TrustableGraph:
    graph = PydotGraph()
    items = [item for document in tree.documents for item in document.item]
    for item in items:
        graph.add_node(item.uid.value)
        child_items = [
            child_item
            for document in tree.documents
            for child_item in document.items
            if item.uid in child_item.links
        ]
        for child in child_items:
            graph.add_edge(item.uid.value, child.uid.value)

    trustable_graph = TrustableGraph(graph, [DoorstopItem(item) for item in items])
    for item in items:
        trustable_graph.set_review_status(item.uid.value, item.reviewed)
        for link in item.links:
            parent = tree.find_item(link)
            status = (
                LinkStatus.LINKED
                if link.stamp == parent.stamp()
                else LinkStatus.UNLINKED
            )
            trustable_graph.set_link_status(link.value, item.uid.value, status)
    return trustable_graph
