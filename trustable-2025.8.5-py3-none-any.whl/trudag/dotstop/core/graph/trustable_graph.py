# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

# Remove this try when we move to python 3.11
try:
    from typing import Self
except ImportError:
    from typing_extensions import Self

import numpy as np
import logging
from collections import Counter
from enum import Enum
from pathlib import Path
from trudag.dotstop.core.constants import ITEM_SEPARATOR, FILE_MARKER
from trudag.dotstop.core.graph import BaseGraph
from trudag.dotstop.core.item import BaseItem
from trudag.dotstop.core.exception import GraphActionError, GraphStructureError

logger = logging.getLogger(__name__)


class LinkStatus(Enum):
    """
    Possible statuses of relationships between a pair of [`BaseItem`][trudag.dotstop.core.item.BaseItem]s in a [`TrustableGraph`][trudag.dotstop.core.graph.TrustableGraph].
    """

    UNLINKED = "UNLINKED"
    """
    The two items are not linked.
    """
    SUSPECT = "SUSPECT"
    """
    The two items are linked, but one or more of the items has changed since the link was last reviewed.
    """
    LINKED = "LINKED"
    """
    The two items are linked and both items have not been changed since the link was last reviewed.
    """

    def __str__(self) -> str:
        return self.value


class TrustableGraph:
    def __init__(
        self,
        graph: BaseGraph,
        items: list[BaseItem],
    ):
        """
        Construct an instance of TrustableGraph with a `BaseGraph` and a list of `BaseItem`s.
        The elements in both the nodes of the graph and the names of the items are expected to be equivalent.

        Args:
            graph (BaseGraph): An object describing relationships between items that implements the BaseGraph abstract class.
            items (list[BaseItems]): A list of BaseItems.
        """
        self._items = {item.name: item for item in items}
        self._graph = graph
        self.check()

    @property
    def items(self) -> list[BaseItem]:
        return list(self._items.values())

    @property
    def adjacency(self) -> np.ndarray:
        """
        The unweighted adjacency matrix of the graph. Ordering is consistent with `items`.
        """
        return self._graph.adjacency_matrix(node_order=self._items.keys())

    def documents_to_items_map(self) -> dict[str, list[BaseItem]]:
        """
        A dictionary of document names and their constituent `BaseItem`s.

        `BaseItem`s are returned in ascending order. Documents are sorted alphabetically by name.
        """
        documents = {}
        for item in self._items.values():
            if item.document in documents:
                documents[item.document].append(item)
            else:
                documents[item.document] = [item]
        for entry in documents:
            documents[entry].sort()
        return dict(sorted(documents.items()))

    def get_item(self, name: str) -> BaseItem:
        """
        Return the `BaseItem` with [name][trudag.dotstop.core.item.BaseItem.name].

        Raises a [`GraphActionError`][trudag.dotstop.core.exception.GraphActionError] if no such item is in the graph.
        """
        item = self._items.get(name)
        if not item:
            raise GraphActionError(f"Cannot get non-existent item {name}")
        return item

    def add_items(self, new_items: list[BaseItem], parent: str | None = None) -> None:
        """
        Add new items as nodes (and edges, if parent item exists).

        Args:
            new_items: a list of `BaseItem`s to insert.
            parent: the [name][trudag.dotstop.core.item.BaseItem.name] of an optional parent/source.

        Raises a GraphActionError if item already exists.
        """
        for item in new_items:
            if self._graph.has_node(item.name):
                raise GraphActionError(f"Cannot add pre-existing item: {item}")
            self._graph.add_node(item.name)
            self._items[item.name] = item
            self.set_review_status(item.name, True)
            if parent:
                self._graph.add_edge(parent, item.name)
                self.set_link_status(parent, item.name, LinkStatus.LINKED)

    def remove_item(self, name: str) -> None:
        """
        Remove the item with name `name`.

        Raises a `GraphActionError` if the item does not exist.
        """
        if not self._items.pop(name):
            raise GraphActionError(f"Attempted to remove non-existent item {name}")
        parents, children = self._graph.predecessors(name), self._graph.successors(name)
        for parent in parents:
            self._graph.remove_edge(parent, name)
        for child in children:
            self._graph.remove_edge(name, child)
        self._graph.remove_node(name)

    def get_item_children(self, name: str) -> list[BaseItem]:
        """
        Return the list of children of the `BaseItem` corresponding to `name`.

        Raises a [`GraphActionError`][trudag.dotstop.core.exception.GraphActionError] if no item named `name` is in the graph.
        """
        # Ensure item exists.
        self.get_item(name)
        return [self.get_item(child) for child in self._graph.successors(name)]

    def get_item_parents(self, name: str) -> list[BaseItem]:
        """
        Return the list of parents of the `BaseItem` corresponding to `name`.

        Raises a [`GraphActionError`][trudag.dotstop.core.exception.GraphActionError] if no item named `name` is in the graph.
        """
        # Ensure item exists.
        self.get_item(name)
        return [self.get_item(parent) for parent in self._graph.predecessors(name)]

    def get_orphaned_items(self) -> list[BaseItem]:
        """
        Returns a list of items with no parent and child nodes
        """
        return [
            item
            for item in self.items
            if not self.get_item_parents(item.name)
            and not self.get_item_children(item.name)
        ]

    def get_premises(self) -> list[BaseItem]:
        """
        Return the list of `BaseItem`s with no children.
        """
        return [
            item
            for name in self._graph.leaf_nodes()
            if (item := self.get_item(name)).normative
        ]

    def get_expectations(self) -> list[BaseItem]:
        """
        Return the list of [`BaseItem`][trudag.dotstop.core.item.BaseItem]s with no parents.

        [`BaseItem`][trudag.dotstop.core.item.BaseItem]s are returned in ascending order.
        """
        return [
            item
            for name in self._graph.root_nodes()
            if (item := self.get_item(name)).normative
        ]

    def set_review_status(self, name: str, status: bool) -> None:
        """
        Set the reviewed status of item `name` to `status`.

        Raises a [`GraphActionError`][trudag.dotstop.core.exception.GraphActionError] if no item named `name` is in the graph.
        """
        sha = self.get_item(name).sha if status else ""
        self._graph.set_node_attrs(name, sha=sha)

    def get_review_status(self, name: str) -> bool:
        """
        Return `True` if the `BaseItem` with name `name` is reviewed, `False` otherwise.

        Raises a [`GraphActionError`][trudag.dotstop.core.exception.GraphActionError] if no item named `name` is in the graph.
        """
        current_sha = self.get_item(name).sha
        stored_sha = self._graph.get_node_attr(name, "sha")
        return current_sha == stored_sha and stored_sha != ""

    def set_link_status(self, parent: str, child: str, status: LinkStatus) -> None:
        """
        Set the status of a link to `status`.

        Raises a `GraphActionError` if:
        - Either item does not exist
        - The link is set to its current status.
        - Attempt to set status from unlinked to suspect.
        """
        current_status = self.get_link_status(parent, child)
        if current_status == status:
            logger.warning(
                f"Attempted to set link to it's currently set status: {current_status}"
            )
            return
        match (current_status, status):
            case (_, LinkStatus.UNLINKED):
                self._graph.remove_edge(parent, child)
            case (LinkStatus.UNLINKED, LinkStatus.LINKED):
                self._graph.add_edge(parent, child)
                sha_link = self.sha_link(parent, child)
                self._graph.set_edge_attrs(parent, child, sha=sha_link)
            case (LinkStatus.SUSPECT, LinkStatus.LINKED):
                sha_link = self.sha_link(parent, child)
                self._graph.set_edge_attrs(parent, child, sha=sha_link)
            case (LinkStatus.LINKED, LinkStatus.SUSPECT):
                self._graph.set_edge_attrs(parent, child, sha="")
            case (LinkStatus.UNLINKED, LinkStatus.SUSPECT):
                raise GraphActionError(
                    f"Cannot set status of unlinked {parent} -> {child} to suspect"
                )

    def get_link_status(self, parent: str, child: str) -> LinkStatus:
        """
        Return the `LinkStatus` of the edge from `parent_name` to `child_name`.

        Raises a [`GraphActionError`][trudag.dotstop.core.exception.GraphActionError] if either item does not exist.
        """
        if not self._graph.has_edge(parent, child):
            return LinkStatus.UNLINKED
        parent_item, child_item = self.get_item(parent), self.get_item(child)
        current_edge_sha = self._graph.get_edge_attr(parent, child, "sha")
        if current_edge_sha and parent_item.sha_link(child_item) == current_edge_sha:
            return LinkStatus.LINKED
        return LinkStatus.SUSPECT

    def get_item_sha(self, name: str) -> str | None:
        """
        Get the stored sha256 checksum of the `BaseItem` with name `name`.
        """
        return self._graph.get_node_attr(name, "sha")

    def get_link_sha(self, parent: str, child: str) -> str | None:
        """
        Get the stored sha256 checksum of the link between items `parent` and `child`.
        """
        return self._graph.get_edge_attr(parent, child, "sha")

    def sha_link(self, parent: str, child: str) -> str:
        """
        A sha256 checksum of the link between `self` and `child`.

        Computed from the [`sha`][trudag.dotstop.core.item.BaseItem.sha]s of `self` and of `child`.
        """
        return self.get_item(parent).sha_link(self.get_item(child))

    def valid_subgraph(self) -> "TrustableGraph":
        """
        Return the subgraph containing only reviewed normative items and non-suspect links.
        """
        valid_items = [
            item
            for (name, item) in self._items.items()
            if self.get_review_status(name) and item.normative
        ]
        valid_graph = self._graph.empty()

        # Add valid nodes.
        for node in self._graph.nodes():
            if self.get_review_status(node) and self.get_item(node).normative:
                valid_graph.add_node(node)
                node_attrs = self._graph.get_node_attrs(node)
                valid_graph.set_node_attrs(node, **node_attrs)

        # Add valid edges.
        for src, dst in self._graph.edges():
            if (
                self.get_link_status(src, dst) == LinkStatus.LINKED
                and self.get_review_status(src)
                and self.get_review_status(dst)
            ):
                valid_graph.add_edge(src, dst)
                edge_attrs = self._graph.get_edge_attrs(src, dst)
                valid_graph.set_edge_attrs(src, dst, **edge_attrs)

        return TrustableGraph(valid_graph, valid_items)

    def __eq__(self, other: "TrustableGraph") -> bool:
        return str(self._graph) == str(other._graph) and self._items == other._items

    def check(self) -> None:
        """
        Raise a [`GraphStructureError`][trudag.dotstop.core.exception.GraphStructureError] if the `Graph` object contains illegal items or links.

        - The graph does not:
            - contain links to or from non-normative items
            - contain duplicate nodes or edges
        - The list of items has:
            - unique names
            - separator in name
            - names that correspond exactly with the set of node ids in the graph
        """
        lints = (
            self._check_item_node_equivalence()
            + self._check_seperators()
            + self._check_duplicate_nodes()
            + self._check_duplicate_edges()
            + self._check_non_normative_links()
        )
        if not self._graph.is_directed():
            lints.append("Graph must be a directed graph")
        if lints:
            for lint in lints:
                logger.error(lint)
            raise GraphStructureError(lints[0])

    def _check_item_node_equivalence(self) -> list[str]:
        return [
            f"Node/Item with no equivalent: {non_equivalent}"
            for non_equivalent in (set(self._items.keys()) ^ set(self._graph.nodes()))
        ]

    def _check_seperators(self) -> list[str]:
        return [
            f"Item {name} does not contain the separator character {ITEM_SEPARATOR}."
            for name in self._items
            if ITEM_SEPARATOR not in name
        ]

    def _check_duplicate_nodes(self) -> list[str]:
        counts = Counter(self._graph.nodes())
        return [
            f"Item {node}'s node is duplicated {count} times in the graph."
            for node, count in counts.items()
            if count > 1
        ]

    def _check_duplicate_edges(self) -> list[str]:
        counts = Counter(self._graph.edges())
        return [
            f"Edge {src} -> {dst} is duplicated {count} times in the graph."
            for (src, dst), count in counts.items()
            if count > 1
        ]

    def _check_non_normative_links(self) -> list[str]:
        non_normative = [id for id, item in self._items.items() if not item.normative]
        return [
            f"Graph contains edge {src} -> {dst} between non-normative item(s)"
            for src, dst in self._graph.edges()
            if src in non_normative or dst in non_normative
        ]

    def to_file(self, output_file: Path) -> None:
        """
        Check the file, then write to specified output_file.
        """
        if output_file.exists() and not output_file.is_file():
            raise FileExistsError(
                f"Cannot write to existing non-regular file {output_file}"
            )
        with output_file.open("w") as file_handle:
            file_handle.write(FILE_MARKER)
            file_handle.write(self._graph.to_string(sort=True))

    def add_namespace(self, namespace: str) -> Self:
        """
        Modify graph during runtime by adding a namespace to all nodes and edges.
        """
        nodes = self._graph.nodes()
        for node in nodes:
            namespaced = f"{namespace}.{node}"
            self._graph.add_node(namespaced)
            self._graph.set_node_attrs(namespaced, **self._graph.get_node_attrs(node))
            parents, children = (
                self._graph.predecessors(node),
                self._graph.successors(node),
            )
            for parent in parents:
                nparent = f"{namespace}.{parent}"
                self._graph.add_edge(nparent, namespaced)
                self._graph.set_edge_attrs(
                    nparent,
                    namespaced,
                    **self._graph.get_edge_attrs(parent, node),
                )
                self._graph.remove_edge(parent, node)

            for child in children:
                nchild = f"{namespace}.{child}"
                self._graph.add_edge(namespaced, nchild)
                self._graph.set_edge_attrs(
                    namespaced, nchild, **self._graph.get_edge_attrs(node, child)
                )
                self._graph.remove_edge(node, child)

            self._items[namespaced] = self._items.pop(node)
            self._items[namespaced].name = namespaced

            self._graph.remove_node(node)

        return self

    def _recursive_copy(
        self,
        item: BaseItem,
        other: "TrustableGraph",
        visited: set | None = None,
    ) -> None:
        other_graph = other._graph  # noqa: SLF001 "FRIEND method/class"
        if visited is None:
            visited = set()

        if item.name in visited:
            return

        visited.add(item.name)

        self._graph.add_node(item.name)
        self._graph.set_node_attrs(item.name, **other_graph.get_node_attrs(item.name))
        self._items[item.name] = item

        for child in other.get_item_children(item.name):
            if child.name not in visited:
                self._recursive_copy(child, other, visited)

            self._graph.add_edge(item.name, child.name)
            self._graph.set_edge_attrs(
                item.name,
                child.name,
                **other_graph.get_edge_attrs(item.name, child.name),
            )

    def add_remote_graph(self, local_node: str, other: "TrustableGraph") -> Self:
        self.get_item(local_node)
        if not isinstance(other, TrustableGraph):
            raise GraphStructureError("Merge is only allowed for trustable graphs")
        discard = other.get_orphaned_items()  # do not merge orphans.
        roots = [item for item in other.get_expectations() if item not in discard]
        visited = set()
        for root in roots:
            self._recursive_copy(root, other, visited)
            self._graph.add_edge(local_node, root.name)
            self.set_link_status(local_node, root.name, LinkStatus.LINKED)

        return self

    def __str__(self):
        return str(self._graph)
