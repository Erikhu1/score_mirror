# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

from pathlib import Path
import pydot
from typing import Any
from trudag.dotstop.core.exception import GraphStructureError
from trudag.dotstop.core.graph.base_graph import Attribute
from trudag.dotstop.core.graph import BaseGraph


def _quote(id: Any) -> str:
    return f'"{id}"'


def _unquote(id: Any) -> str:
    return "" if id is None else id.replace('"', "")


class PydotGraph(BaseGraph):
    def __init__(self, graph: pydot.Graph | None = None):
        self._graph = graph or pydot.Graph()

    @classmethod
    def empty(cls):
        return cls()

    @classmethod
    def from_string(cls, src: str) -> "PydotGraph":
        graphs = pydot.graph_from_dot_data(src)
        if not graphs or len(graphs) != 1:
            raise GraphStructureError("dot must contain only one graph.")
        return cls(graphs[0])

    def to_string(self, sort: bool = True) -> str:
        if not sort:
            return self._graph.to_string()
        nodes = self._graph.get_nodes()
        if not nodes:
            return self._graph.to_string()
        # Assuming that the first node is always the root)
        root = nodes[0]
        # NOTE: this set_sequence is a pydot thing to handle the insertion order
        # we need to figure out later a better approach to sort the string
        # content, maybe using the dict keys from basegraph interface?
        root.set_sequence(1)
        edges = self._graph.get_edges()

        sorted_nodes = sorted(nodes[1:], key=lambda node: node.get_name().lower())
        sorted_edges = sorted(
            edges,
            key=lambda edge: (
                # We need to prioritize root edges, if we don't, the graph
                # will break.
                0 if edge.get_source() == root.get_name() else 1,
                edge.get_source().lower(),
            ),
        )

        # NOTE: this set_sequence is a pydot thing to handle the insertion order
        # we need to figure out later a better approach to sort the string
        # content, maybe using the dict keys from basegraph interface?
        node_position = 2
        for _, node in enumerate(sorted_nodes):
            node.set_sequence(node_position)
            node_position += 1

        # Get the last value from nodes sorting and start adding the edges
        for position, edge in enumerate(sorted_edges, node_position + 1):
            edge.set_sequence(position)

        return self._graph.to_string()

    @classmethod
    def from_file(cls, path: Path) -> "PydotGraph":
        graphs = pydot.graph_from_dot_file(str(path))
        if not graphs or len(graphs) != 1:
            raise GraphStructureError("dot must contain only one graph.")
        return cls(graphs[0])

    def is_directed(self) -> bool:
        return self._graph.get_type() == "digraph"

    def set_graph_attrs(self, **attrs: Attribute):
        for key, value in attrs:
            self._graph.set(key, _quote(value))

    def get_graph_attr(self, key) -> Attribute | None:
        return self._graph.get(key)

    def get_graph_attrs(self) -> dict[str, Attribute]:
        return self._graph.get_attributes()

    def nodes(self) -> list[str]:
        return [_unquote(node.get_name()) for node in self._graph.get_node_list()]

    def add_node(self, node_id: str) -> None:
        self._graph.add_node(pydot.Node(_quote(node_id)))

    def remove_node(self, node_id: str) -> None:
        self._graph.del_node(_quote(node_id))

    def has_node(self, node_id: str) -> bool:
        return bool(self._graph.get_node(_quote(node_id)))

    def set_node_attrs(self, node_id: str, **attrs: Attribute) -> None:
        for key, value in attrs.items():
            self._graph.get_node(_quote(node_id))[0].set(key, _quote(value))

    def get_node_attr(self, node_id: str, key: str) -> Attribute:
        return _unquote(self._graph.get_node(_quote(node_id))[0].get(key))

    def get_node_attrs(self, node_id: str) -> dict[str, Attribute]:
        node = self._graph.get_node(_quote(node_id))[0]
        return {k: _unquote(v) for k, v in node.get_attributes().items()}

    def edges(self) -> list[tuple[str, str]]:
        return [
            (_unquote(edge.get_source()), _unquote(edge.get_destination()))
            for edge in self._graph.get_edge_list()
        ]

    def add_edge(self, parent_id: str, child_id: str) -> None:
        self._graph.add_edge(pydot.Edge(_quote(parent_id), _quote(child_id)))

    def remove_edge(self, parent_id: str, child_id: str) -> None:
        self._graph.del_edge(_quote(parent_id), _quote(child_id))

    def has_edge(self, parent_id: str, child_id: str) -> bool:
        return bool(self._graph.get_edge(_quote(parent_id), _quote(child_id)))

    def set_edge_attrs(self, parent_id: str, child_id: str, **attrs: Attribute) -> None:
        edge = self._graph.get_edge(_quote(parent_id), _quote(child_id))[0]
        for key, value in attrs.items():
            edge.set(key, _quote(value))

    def get_edge_attr(self, parent_id: str, child_id: str, key: str) -> Attribute:
        edge = self._graph.get_edge(_quote(parent_id), _quote(child_id))
        return _unquote(edge[0].get(key))

    def get_edge_attrs(self, parent_id: str, child_id: str) -> dict[str, Attribute]:
        edge = self._graph.get_edge(_quote(parent_id), _quote(child_id))[0]
        return {k: _unquote(v) for k, v in edge.get_attributes().items()}
