import click

from typing import Any, Literal

from trudag.utils import abort_click_on
from trudag.dotstop.core.exception import GraphActionError


class AliasChoice(click.ParamType):
    name = "alias"

    def convert(
        self, value: Any, param: click.Parameter | None, ctx: click.Context | None
    ):
        if not ctx:
            err = f"Invalid context provided to {self.name} click helper"
            raise click.ClickException(err)
        remotes: dict | None = ctx.obj.get("remote_config")
        if not remotes:
            raise click.ClickException("Missing remote graph content")

        choices = remotes.keys()
        if value not in choices:
            self.fail(
                f"Invalid choice: {value}. (choose from {', '.join(choices)})",
                param,
                ctx,
            )
        return value


@abort_click_on(GraphActionError)
def validate_from(ctx: click.Context, _param: click.Parameter, value: Any):
    if not value:
        raise click.BadParameter("--from cannot be empty")

    for v in value:
        # test if from nodes are valid if not raise exception
        try:
            ctx.obj.get("graph").get_item(v)
        except GraphActionError as e:
            err = f"Origin node {v} is not part of local graph"
            raise GraphActionError(err) from e

    return value


def validate_to(ctx: click.Context, _param: click.Parameter, value: Any):
    remotes = ctx.obj.get("remote_config", {})
    if not remotes:
        raise click.ClickException(message="Missing remote graphs configuration file")
    if not value:
        raise click.BadParameter("--to cannot be empty")

    aliases = remotes.keys()
    counts = {
        alias: sum(1 for remote in value if remote.startswith(alias))
        for alias in aliases
    }
    if any(count > 1 for count in counts.values()):
        raise click.BadParameter("Can't connect to the same graph more than once")
    return value


def validate_pairs(frms: tuple[str, ...], to: tuple[str, ...]) -> Literal[True]:
    if len(frms) != len(to):
        raise click.BadParameter("Must provide equal --from and --to arguments")
    return True
