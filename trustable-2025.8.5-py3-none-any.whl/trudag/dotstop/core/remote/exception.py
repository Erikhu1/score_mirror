class InvalidRemoteConfig(ValueError):
    """
    An error caused by an illegal remote definition
    """
