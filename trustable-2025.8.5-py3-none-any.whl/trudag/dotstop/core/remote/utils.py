import logging

from contextlib import contextmanager
from os import chdir
from typing import Callable, Optional
from pathlib import Path

from trudag.dotstop.core.graph import TrustableGraph
from trudag.dotstop.core.item import BaseItem


from git import Repo
from .loader import RemoteConfig
from .constants import (
    REMOTE_DOWNLOAD_FOLDER,
)

logger = logging.getLogger(__name__)


@contextmanager
def temporary_folder_change(on_entry_path: Path):
    on_exit_path: Path = Path.cwd()
    chdir(on_entry_path)
    try:
        yield
    finally:
        chdir(on_exit_path)


def _create_folder(path: Path) -> Path:
    path.mkdir(exist_ok=True, parents=True)
    return path


def make_remote_folder() -> Path:
    """
    Create a folder to store downloaded remote graphs.
    """
    folder = Path(REMOTE_DOWNLOAD_FOLDER)
    if not folder.exists():
        logger.debug(f"Creating remote folder for graphs {folder}")
    return _create_folder(folder)


def clone_or_update(alias: str, dest: Path, config: RemoteConfig) -> None:
    try:
        repo_str = f"{alias} - ({config.scheme}://{config.address})"
        if dest.exists() and (repo := Repo(dest)):
            if "origin" in repo.remotes:
                logger.debug(f"Fetching upstream data for {repo_str}")
                repo.remote().fetch()
        else:
            repo = Repo.clone_from(config.resolve, dest)
            logger.debug(f" {repo_str} cloned to {dest.absolute()}")

        repo.git.checkout(config.target)
        logger.debug(f"{alias} checkout to {config.target}")

    except Exception:
        raise


def build_remote_graph(
    *,
    remote_base_path: Path,
    dotstop_entry_point: Path,
    remote_configs: dict[str, RemoteConfig],
    build_graph_func: Callable[
        [
            Optional[Path | str | None],
            Optional[Path | list[BaseItem] | None],
            Optional[None],
            Optional[Path | None],
        ],
        TrustableGraph,
    ],
    trustable_ignore: Path | None = None,
) -> dict[str, TrustableGraph]:
    """
    This function accepts a path which is expected to be excluded from the local
    graph via trustable ignore to pull different trustable graphs to merge with
    local later.

    Args:
        remote_base_path (Path): Base path used to download remote graphs
        dotstop_entry_point (Path): .dotstop.dot file path.
        remote_configs (dict[str,RemoteConfig]: a dict of aliases with related dataclass that holds its definition.
        build_graph_func Callable: TrustableGraph builder function.
        trustable_ignore (Path | None) : trustable ignore file like gitignore without globs feature.
    """

    repos: dict[str, TrustableGraph] = dict()
    with temporary_folder_change(remote_base_path):
        for alias in remote_configs:
            remote_folder = Path(alias)
            remote_trustable_ignore = (
                remote_folder / ".trustable_ignore"
                if (remote_folder / ".trustable_ignore").exists()
                else None
            )
            if remote_folder.exists():
                with temporary_folder_change(remote_folder):
                    logger.debug(f"Building remote graph from {Path.cwd()}")
                    repos[alias] = build_graph_func(
                        dotstop_entry_point,
                        Path(),
                        None,
                        trustable_ignore
                        if trustable_ignore
                        else remote_trustable_ignore,
                    )
            else:
                logger.warning(
                    f"Missing remote graph content for {alias}, {remote_folder.absolute()} is empty or does not exist"
                )
    return repos
