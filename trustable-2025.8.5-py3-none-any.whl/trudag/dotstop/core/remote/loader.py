import logging
import netrc as nc
import yaml

from dataclasses import dataclass, field
from typing import Literal
from schema import Schema, And, SchemaError, Or
from pathlib import Path
from urllib.parse import urlparse

from .exception import InvalidRemoteConfig

logger = logging.getLogger(__name__)


@dataclass
class RemoteConfig:
    alias: str | None = None
    address: str | None = None
    login: str | None = field(repr=False, default=None)
    password: str | None = field(repr=False, default=None)
    target: str | None = None
    type_: str = "git"
    scheme: str = "https"

    @property
    def resolve(self) -> str:
        return (
            f"{self.scheme}://" + f"{self.login}:{self.password}@{self.address}"
            if self.password and self.login
            else f"{self.scheme}://{self.address}"
        )


def tag_or_commit_validator(repo: dict[str, str]) -> Literal[True]:
    if ("tag" in repo) ^ ("commit" in repo):
        return True
    raise SchemaError("Exactly one of 'tag' or 'commit' must be provided")


remote_schema = Schema(
    {
        "repos": [
            And(
                {
                    "alias": And(str, len, error="Missing or empty 'alias'"),
                    "url": And(str, len, error="Missing or empty 'url'"),
                    "type": And(str, "git", error="For now, it only has git support"),
                    Or("tag", "commit", only_one=True): str,
                },
                tag_or_commit_validator,
            )
        ]
    }
)


def fetch_netrc_credential(
    creds: nc.netrc, hostname: str
) -> tuple[str, str, str] | None:
    if valid := creds.authenticators(hostname):
        return valid

    logger.warning(f"Failed to find in netrc file a credential for {hostname}")
    return None


def generate_configs(
    re_config: list[dict[str, str]],
    netrc: Path | None = None,
) -> dict[str, RemoteConfig]:
    creds = None
    if netrc:
        try:
            creds = nc.netrc(netrc.expanduser())
        except FileNotFoundError as e:
            err = f"Incorrect path to netrc file {netrc.expanduser()}"
            raise FileNotFoundError(err) from e

    remote_config: dict[str, RemoteConfig] = {}

    for repo in re_config:
        if "type" in repo and repo["type"] != "git":
            logger.warning(
                f"We only support git references for now skipping alias {repo}"
            )
            continue

        config = RemoteConfig()

        config.alias = alias = repo["alias"]

        if "tag" in repo:
            config.target = repo["tag"]

        if "commit" in repo:
            config.target = repo["commit"]

        # Before proceeding check if scheme, netloc which means hostname and is
        # retriable, path can be optional. This doesn't accept for example,
        # www.gitlab.com/blabla/repo.git or # gitlab.com/blabla.repo,
        # a communication protocol must be specified, such as https is expected,
        if (tokens := urlparse(repo["url"])) and all(
            token is not None for token in tokens[:2]
        ):
            if (scheme := tokens.scheme) and scheme not in "https":
                config.scheme = scheme

            if (
                (hostname := tokens.hostname)
                and creds
                and (cred := fetch_netrc_credential(creds, hostname))
            ):
                config.login, _, config.password = cred

            config.address = f"{tokens.netloc}{tokens.path if tokens.path else ''}"
        else:
            err = f"Failed to parse remote url {repo['url']} for remote {alias} graph repo"
            raise InvalidRemoteConfig(err)

        remote_config[alias] = config

    return remote_config


def load_remote_config(
    remote_config: Path, netrc: Path | None = None
) -> dict[str, RemoteConfig] | None:
    try:
        with remote_config.open("rb") as fp:
            remote = yaml.safe_load(fp)
            remote_schema.validate(remote)
            # type: ignore, pyrefly can't identify content correctly, as we are loading some yaml
            # file through Unknown | None interface
            return generate_configs(remote["repos"], netrc)

    except (yaml.YAMLError, SchemaError, FileNotFoundError) as e:
        if isinstance(e, yaml.YAMLError):
            err = f"Failed to parse YAML from {remote_config}"
            raise yaml.YAMLError(err) from e
        if isinstance(e, SchemaError):
            err = f"Remote config validation failed for {remote_config}"
            raise SchemaError(err) from e
        if isinstance(e, FileNotFoundError):
            if not remote_config.exists():
                err = f"Remote graph config map {remote_config} doesn't exist"
            else:
                err = f"Failed to find netrc file {netrc}."
            raise FileNotFoundError(err) from e
