REMOTE_CONFIG = ".remote-graphs.yml"
REMOTE_DOWNLOAD_FOLDER = ".remote-graphs/"
MERGE_FOLDER = "trudag-out/"
