import hashlib

from trudag.dotstop.core.reference import BaseReference


class Fallacy:
    def __init__(self, description: str, reference: BaseReference) -> None:
        """
        Fallacies describe the states and/or conditions which could cause the related Statement to be False.

        Args:
            description (str): A short description of how the Artifact causes a Falsehood to occur.
            reference (BaseReference): An Artifact that describes the state or conditition leading to Falsehood.
        """
        self._description = description
        self._reference = reference

    @property
    def description(self) -> str:
        """
        Short description of how the state or condition causes the related Statement to be false.
        """
        return self._description

    @property
    def reference(self) -> str:
        """
        Artifact describing the state or condition which causes the related Statement to be false.
        """
        return self._reference

    @property
    def sha(self) -> str:
        """
        Sha256 checksum of the description and Artifact.
        """
        hash = hashlib.sha256()
        hash.update(self.description.encode())
        hash.update(self.reference.sha.encode())
        return hash.hexdigest()
