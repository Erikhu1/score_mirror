"""
A Library for managing Trustable Graphs stored as dot files.
"""

from trudag.dotstop.core.graph import (
    BaseGraph as BaseGraph,
    LinkStatus as LinkStatus,
    TrustableGraph as TrustableGraph,
)
from trudag.dotstop.core.item import (
    BaseItem as BaseItem,
    DoorstopItem as DoorstopItem,
    MarkdownItem as MarkdownItem,
)
from trudag.dotstop.core.reference import (
    BaseReference as BaseReference,
    FileReference as FileReference,
    LocalFileReference as LocalFileReference,
    GitlabFileReference as GitlabFileReference,
    ReferenceBuilder as ReferenceBuilder,
)
from trudag.dotstop.core.exception import (
    GraphActionError as GraphActionError,
    GraphStructureError as GraphStructureError,
    PluginError as PluginError,
    DotstopError as DotstopError,
    ItemError as ItemError,
    DataModelError as DataModelError,
    GitError as GitError,
)

from trudag.dotstop.core.fallacy import Fallacy as Fallacy
from trudag.dotstop.core.constants import (
    ITEM_SEPARATOR as ITEM_SEPARATOR,
    TRUSTABLE_VERSION as TRUSTABLE_VERSION,
    FILE_MARKER as FILE_MARKER,
)

from trudag.dotstop.core import remote as remote
