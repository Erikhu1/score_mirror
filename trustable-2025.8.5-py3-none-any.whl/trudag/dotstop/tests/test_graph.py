# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

import pathlib

import numpy as np
import pytest

from trudag import dotstop
from trudag.dotstop.core.graph import TrustableGraph, build_trustable_graph
from . import FakeItem


@pytest.fixture
def example_reference(tmp_path: pathlib.Path) -> pathlib.Path:
    """
    A named temporary reference file in './files/'.
    """
    reference_path = tmp_path / "phonebook.txt"
    with reference_path.open("w", encoding="utf-8") as reference_file:
        reference_file.write("Alice: 0800 00 1066")
    return reference_path


@pytest.fixture
def example_workspace(example_reference: pathlib.Path) -> dict:
    r"""
    Example `graph`, included in a dictionary together with its component parts
    and a path to a reference.


                                ┌─────┐
                             ┌──│EXP-1├──┐
                             │  └─────┘  │
                             │           │
                             │           │
                          ┌──▼──┐     ┌──▼──┐
           ┌───────────┬──┤ASN-1├─┐ ┌─┤ASN-2├──┐
           │           │  └─────┘ │ │ └─────┘  │
           │           │          │ │          │
           │           │          │ │          │
        ┌──▼──┐     ┌──▼──┐     ┌─▼─▼─┐     ┌──▼──┐
        │TST-1│     │TST-2│     │DOC-1│     │TST-3│
        └─────┘     └─────┘     └─────┘     └─────┘


    All links are suspect, and all items unreviewed, except:
    - ASN-1
    - DOC-1
    - ASN-1 -> DOC-1
    - EXP-1 -> ASN-1
    """

    items = [
        FakeItem(obj_dict)
        for obj_dict in [
            {
                "name": "EXP-1",
                "text": "Bob and Alice know each other",
            },
            {
                "name": "ASN-CONTEXT",
                "text": "To work out if Alice and Bob know each other we consider each person in turn.",
                "normative": False,
            },
            {
                "name": "ASN-1",
                "text": "Alice knows Bob",
                "fallacies": {
                    "MISTAKEN": dotstop.Fallacy(
                        "Alice is mistaken",
                        dotstop.LocalFileReference(example_reference),
                    )
                },
            },
            {
                "name": "ASN-2",
                "text": "Bob knows Alice",
            },
            {
                "name": "TST-1",
                "text": "Alice can recognize Bob",
            },
            {
                "name": "TST-2",
                "text": "Alice recognizes Carol is not Bob",
            },
            {
                "name": "TST-3",
                "text": "Bob can recognize Alice",
            },
            {
                "name": "DOC-1",
                "text": "Alice is in Bob's Address Book",
                "references": [dotstop.LocalFileReference(example_reference)],
            },
        ]
    ]
    dot = f"""digraph G {{
        "EXP-1";
        "EXP-1" -> "ASN-1" [sha="{items[0].sha_link(items[2])}"]
        "EXP-1" -> "ASN-2"
        "ASN-CONTEXT" [sha="{items[1].sha}"]
        "ASN-1" [sha="{items[2].sha}"]
        "ASN-2" [sha="frfawuf4383e4rfhf48h5hfqle3j94hfqj3q84hf5gjwdjwoighwihdw5th58888"]
        "ASN-1" -> "TST-1"
        "ASN-1" -> "TST-2"
        "ASN-1" -> "DOC-1" [sha="{items[2].sha_link(items[7])}"]
        "ASN-2" -> "TST-3"
        "ASN-2" -> "DOC-1" [sha="3a933614862ber7ae19f3542448ea1673d9f24c4dd40e7701cad80ffaf8fa90f"]
        "TST-1" [sha="g7a6874845e72e48faadee30b9036b1b20b80d36ef7d38d006c683245711a987d"]
        "TST-2"
        "TST-3"
        "DOC-1" [sha="{items[7].sha}"]
        }}
        """

    return {
        "graph": build_trustable_graph(graph_source=dot, items_source=items),
        "items": items,
        "reference": example_reference,
    }


@pytest.fixture
def example_graph(example_workspace: dict) -> TrustableGraph:
    r"""
    Simple fixture containing only the `Graph` object from `example_workspace`.
    """
    return example_workspace["graph"]


def test_constructor_duplicate_edge() -> None:
    """
    Verify that we cannot construct a graph with two instances of the same edge.
    """
    items = [
        FakeItem({"name": "ITEM-1"}),
        FakeItem({"name": "ITEM-2"}),
    ]
    dot = """digraph G {
        "ITEM-1"
        "ITEM-2"
        "ITEM-1" -> "ITEM-2"
        "ITEM-1" -> "ITEM-2"
        }
    """
    with pytest.raises(dotstop.GraphStructureError):
        build_trustable_graph(graph_source=dot, items_source=items)


def test_constructor_node_item_mismatch() -> None:
    """
    Verify that we cannot construct a Graph with a node-id-item-name-mismatch.
    """
    items = [
        FakeItem({"name": "ITEM-1"}),
        FakeItem({"name": "ITEM-3"}),
    ]
    dot = """digraph G {
        "ITEM-1"
        "ITEM-2"
        "ITEM-1" -> "ITEM-2"
        }
        """
    with pytest.raises(dotstop.GraphStructureError):
        build_trustable_graph(graph_source=dot, items_source=items)


def test_constructor_non_normative_link() -> None:
    """
    Verify that we cannot construct a graph with a link to a non-normative record.
    """
    items = [
        FakeItem({"name": "ITEM-1"}),
        FakeItem({"name": "ITEM-2", "normative": False}),
    ]
    dot = """digraph G {
        "ITEM-1"
        "ITEM-2"
        "ITEM-1" -> "ITEM-2"
        }
    """
    with pytest.raises(dotstop.GraphStructureError):
        build_trustable_graph(graph_source=dot, items_source=items)


def test_constructor_undirected_edge() -> None:
    """
    Verify that we cannot construct a graph from a undirected dot graph.
    """
    items = [
        FakeItem({"name": "ITEM-1"}),
        FakeItem({"name": "ITEM-2"}),
    ]
    dot = """graph G {
        "ITEM-1"
        "ITEM-2"
        "ITEM-1" -- "ITEM-2"
        }
    """
    with pytest.raises(dotstop.GraphStructureError):
        build_trustable_graph(graph_source=dot, items_source=items)


def test_get_item(example_workspace: dict) -> None:
    """
    Verify an item in the graph can be retrieved.
    """
    item = example_workspace["graph"].get_item("ASN-1")
    assert item == example_workspace["items"][2]


def test_get_item_missing(example_graph: TrustableGraph) -> None:
    """
    Verify retrieving an item not in the graph throws a `ValueError`.
    """
    with pytest.raises(dotstop.GraphActionError):
        example_graph.get_item("NOT-AN-ITEM")


def test_adjacency(example_graph: TrustableGraph) -> None:
    """
    Verify we get the correct adjacency matrix
    """
    assert np.allclose(
        example_graph.adjacency,
        np.array(
            [
                [0, 0, 1, 1, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 1, 1, 0, 1],
                [0, 0, 0, 0, 0, 0, 1, 1],
                [0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0],
            ],
        ),
    )


def test_valid_subgraph(example_workspace: dict) -> None:
    """
    Verify the 'valid' subgraph contains all and only all reviewed items and non-suspect links.
    """
    graph = example_workspace["graph"]
    valid_graph = graph.valid_subgraph()
    items = example_workspace["items"]
    valid_items = [items[2], items[7]]
    valid_dot_string = f"""digraph G {{
        "ASN-1" [sha="{items[2].sha}"]
        "ASN-1" -> "DOC-1" [sha="{items[2].sha_link(items[7])}"]
        "DOC-1" [sha="{items[7].sha}"]
        }}
        """
    assert valid_graph == build_trustable_graph(
        graph_source=valid_dot_string, items_source=valid_items
    )


def test_get_item_children(example_workspace: dict) -> None:
    """
    Verify we get only the expected child items, disregarding order
    """
    retrieved_children = example_workspace["graph"].get_item_children("ASN-2")
    expected_children = [example_workspace["items"][i] for i in [7, 6]]
    assert sorted(retrieved_children) == sorted(expected_children)


def test_get_item_parents(example_workspace: dict) -> None:
    """
    Verify we get only the expected parent items, disregarding order
    """
    retrieved_parents = example_workspace["graph"].get_item_parents("DOC-1")
    expected_parents = [example_workspace["items"][i] for i in [2, 3]]
    assert sorted(retrieved_parents) == sorted(expected_parents)


def test_get_expectations(example_workspace: dict) -> None:
    retrieved_expectations = example_workspace["graph"].get_expectations()
    expected_expectations = [example_workspace["items"][0]]
    print([str(item) for item in retrieved_expectations])
    assert retrieved_expectations == expected_expectations


def test_get_premises(example_workspace: dict) -> None:
    retrieved_evidence = example_workspace["graph"].get_premises()
    expected_evidence = [example_workspace["items"][i] for i in [4, 5, 6, 7]]
    print([str(item) for item in retrieved_evidence])
    assert sorted(retrieved_evidence) == sorted(expected_evidence)


def test_get_orphaned_items(example_workspace: dict) -> None:
    retrieved_items = example_workspace["graph"].get_orphaned_items()
    expected_items = [example_workspace["items"][1]]
    print([str(item) for item in retrieved_items])
    assert retrieved_items == expected_items


def test_get_item_children_missing(example_graph: TrustableGraph) -> None:
    """
    Verify getting the children of a non-existent item throws an error
    """
    with pytest.raises(dotstop.GraphActionError):
        example_graph.get_item_children("NOT-AN-ITEM")


def test_get_item_children_none(example_graph: TrustableGraph) -> None:
    """
    Verify getting the children of a childless item returns `None`
    """
    assert not example_graph.get_item_children("TST-1")


def test_get_review_status_true(example_graph: TrustableGraph) -> None:
    """
    Verify a correctly hashed item is reviewed
    """
    assert example_graph.get_review_status("ASN-1")


def test_get_review_status_missing_sha(example_graph: TrustableGraph) -> None:
    """
    Verify an item that is not hashed is unreviewed
    """
    assert not example_graph.get_review_status("EXP-1")


def test_get_review_status_false(example_graph: TrustableGraph) -> None:
    """
    Verify that an incorrectly hashed item is unreviewed
    """
    assert not example_graph.get_review_status("ASN-2")


def test_get_review_status_missing(example_graph: TrustableGraph) -> None:
    """
    Verify that a non-existent item throws an error when its review status is requested.
    """
    with pytest.raises(dotstop.GraphActionError):
        example_graph.get_review_status("NOT-AN-ITEM")


def test_get_review_status_normative(example_graph: TrustableGraph) -> None:
    """
    Verify that changing the "normative" status of a correctly hashed item marks it as unreviewed.
    """
    assertion_context = example_graph.get_item("ASN-CONTEXT")
    assertion_context.obj_dict["normative"] = True
    assert not example_graph.get_review_status("ASN-CONTEXT")


def test_get_review_status_edit_text(example_graph: TrustableGraph) -> None:
    """
    Verify that changing the text of a correctly hashed item sets its review status to false.
    """
    assert example_graph.get_review_status("ASN-1")
    assertion_1 = example_graph.get_item("ASN-1")
    assertion_1.obj_dict["text"] = "Alice knows Carol"
    assert not example_graph.get_review_status("ASN-1")


def test_get_review_status_edit_reference(example_workspace: dict) -> None:
    """
    Verify that changing the reference contents of a correctly hashed item sets its review status to false.
    """
    example_graph = example_workspace["graph"]
    assert example_graph.get_review_status("DOC-1")
    with example_workspace["reference"].open("w") as file:
        file.write("Carol: 603 776 2323")
    assert not example_graph.get_review_status("DOC-1")


def test_get_review_status_edit_fallacy_id(example_workspace: dict) -> None:
    """
    Verify that changing the id of a fallacy for a correctly hashed item sets its review status to false.
    """
    example_graph = example_workspace["graph"]
    assert example_graph.get_review_status("ASN-1")
    assertion_1 = example_graph.get_item("ASN-1")
    assertion_1.obj_dict["fallacies"]["MISTOOK"] = assertion_1.obj_dict["fallacies"][
        "MISTAKEN"
    ]
    assertion_1.obj_dict["fallacies"].pop("MISTAKEN")
    assert not example_graph.get_review_status("ASN-1")


def test_get_review_status_edit_fallacy_reference(example_workspace: dict) -> None:
    """
    Verify that changing the reference content of a fallacy for a correctly hashed item sets its review status to false.
    """
    example_graph = example_workspace["graph"]
    assert example_graph.get_review_status("ASN-1")
    with example_workspace["reference"].open("w") as file:
        file.write("Carol: 603 776 2323")
    assert not example_graph.get_review_status("ASN-1")


def test_set_review_status_false(example_graph: TrustableGraph) -> None:
    """
    Verify that setting the review status of an item to false works

    """
    example_graph.set_review_status("ASN-1", False)
    assert not example_graph.get_review_status("ASN-1")


def test_set_review_status_true(example_graph: TrustableGraph) -> None:
    """
    Verify that setting the review status of an item to true works
    """
    example_graph.set_review_status("TST-2", status=True)
    assert example_graph.get_review_status("TST-2")


def test_get_link_status_linked(example_graph: TrustableGraph) -> None:
    """
    Verify that a correctly hashed link has status `LINKED`.
    """
    assert example_graph.get_link_status("ASN-1", "DOC-1") == dotstop.LinkStatus.LINKED


def test_get_link_status_incorrect(example_graph: TrustableGraph) -> None:
    """
    Verify that an incorrectly hashed link has status `SUSPECT`.
    """
    assert example_graph.get_link_status("ASN-2", "DOC-1") == dotstop.LinkStatus.SUSPECT


def test_get_link_status_missing(example_graph: TrustableGraph) -> None:
    """
    Verify that an unhashed link has status `SUSPECT`.
    """
    assert example_graph.get_link_status("ASN-1", "TST-1") == dotstop.LinkStatus.SUSPECT


def test_get_link_status_edit_parent(example_graph: TrustableGraph) -> None:
    """
    Verify that changing the parent of a non-suspect link marks it as `SUSPECT`.
    """
    assert example_graph.get_link_status("ASN-1", "DOC-1") == dotstop.LinkStatus.LINKED
    assertion_1 = example_graph.get_item("ASN-1")
    assertion_1.obj_dict["text"] = "Alice knows Dave"
    assert example_graph.get_link_status("ASN-1", "DOC-1") == dotstop.LinkStatus.SUSPECT


def test_get_link_status_edit_child(example_graph: TrustableGraph) -> None:
    """
    Verify that changing the child of a non-suspect link marks it as `SUSPECT`.
    """
    assert example_graph.get_link_status("ASN-1", "DOC-1") == dotstop.LinkStatus.LINKED
    document_1 = example_graph.get_item("DOC-1")
    document_1.obj_dict["text"] = "Alice is in Carol's Address Book"
    assert example_graph.get_link_status("ASN-1", "DOC-1") == dotstop.LinkStatus.SUSPECT


def test_get_link_status_edit_reference(example_workspace: dict) -> None:
    """
    Verify that changing a child reference of a non-suspect link marks it as `SUSPECT`.
    """
    example_graph = example_workspace["graph"]
    assert example_graph.get_link_status("ASN-1", "DOC-1") == dotstop.LinkStatus.LINKED
    with example_workspace["reference"].open("w") as file:
        file.write("Carol: 603 776 2323")
    assert example_graph.get_link_status("ASN-1", "DOC-1") == dotstop.LinkStatus.SUSPECT


def test_get_link_status_edit_fallacy_reference(
    example_workspace: dict,
) -> None:
    """
    Verify that changing the a fallacy id in the parent  of a non-suspect link marks it as `SUSPECT`.
    """
    example_graph = example_workspace["graph"]
    assert example_graph.get_link_status("EXP-1", "ASN-1") == dotstop.LinkStatus.LINKED
    with example_workspace["reference"].open("w") as file:
        file.write("Carol: 603 776 2323")
    assert example_graph.get_link_status("EXP-1", "ASN-1") == dotstop.LinkStatus.SUSPECT


def test_get_link_status_edit_fallacy_id(
    example_workspace: dict,
) -> None:
    """
    Verify that changing the fallacy reference content of a non-suspect link marks it as `SUSPECT`.
    """
    example_graph = example_workspace["graph"]
    assert example_graph.get_link_status("EXP-1", "ASN-1") == dotstop.LinkStatus.LINKED
    assertion_1 = example_graph.get_item("ASN-1")
    assertion_1.obj_dict["fallacies"]["MISTOOK"] = assertion_1.obj_dict["fallacies"][
        "MISTAKEN"
    ]
    assertion_1.obj_dict["fallacies"].pop("MISTAKEN")
    assert example_graph.get_link_status("EXP-1", "ASN-1") == dotstop.LinkStatus.SUSPECT


def test_set_link_status_suspect_to_linked(example_graph: TrustableGraph) -> None:
    example_graph.set_link_status("ASN-2", "TST-3", status=dotstop.LinkStatus.LINKED)
    assert example_graph.get_link_status("ASN-2", "TST-3") == dotstop.LinkStatus.LINKED


def test_set_link_status_linked_to_suspect(example_graph: TrustableGraph) -> None:
    example_graph.set_link_status("ASN-1", "DOC-1", status=dotstop.LinkStatus.SUSPECT)
    assert example_graph.get_link_status("ASN-1", "DOC-1") == dotstop.LinkStatus.SUSPECT


def test_set_link_status_linked_to_unlinked(example_graph: TrustableGraph) -> None:
    example_graph.set_link_status("ASN-1", "DOC-1", status=dotstop.LinkStatus.UNLINKED)
    assert (
        example_graph.get_link_status("ASN-1", "DOC-1") == dotstop.LinkStatus.UNLINKED
    )


def test_set_link_status_suspect_to_unlinked(example_graph: TrustableGraph) -> None:
    example_graph.set_link_status("ASN-2", "TST-3", status=dotstop.LinkStatus.UNLINKED)
    assert (
        example_graph.get_link_status("ASN-2", "TST-3") == dotstop.LinkStatus.UNLINKED
    )


def test_remove_item(example_graph: TrustableGraph) -> None:
    item = example_graph.get_item("TST-1")
    example_graph.remove_item("TST-1")
    assert item not in example_graph.items
