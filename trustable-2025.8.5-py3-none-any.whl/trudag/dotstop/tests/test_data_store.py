from trudag.dotstop.core.data_store.data_store_client import DataStoreClient
from trudag.dotstop.core.data_store.data_model import validate_data

import pytest

from trudag.dotstop.core.exception import DataModelError

DATA_STORE_CODE = """
def data_store_push(data):
    return data + 1

def data_store_pull():
    return "Data"
"""


@pytest.mark.define_local_plugin("data_store.py", DATA_STORE_CODE)
def test_data_store(local_plugin):
    dsc = DataStoreClient()
    assert dsc.pull() == "Data"
    assert dsc.push(4) == 5


def test_validate():
    passing_data = {
        "scores": [{"id": "TRUST-ME", "score": 0}],
        "info": {
            "Commit date/time": "Thu May 29 01:01:01 2025",
            "Repository root": "root",
            "Commit SHA": "12345",
            "Commit tag": "v1.0.0",
            "CI job id": "4321",
            "Branch name": "test_branch",
            "Schema version": "1",
        },
    }
    failing_data_schema = {
        "scores": [{"id": "TRUST-ME", "score": 0}],
        "info": {
            "Commit banana": "sometime",
            "Schema version": "1",
        },
    }
    failing_data_collision = {
        "scores": [{"id": "1", "score": 0}, {"id": "1", "score": 0.1}],
        "info": {
            "Commit date/time": "Thu May 29 01:01:01 2025",
            "Repository root": "root",
            "Commit SHA": "12345",
            "Commit tag": "v1.0.0",
            "CI job id": "4321",
            "Branch name": "test_branch",
            "Schema version": "1",
        },
    }
    validate_data([passing_data, passing_data])
    with pytest.raises(DataModelError):
        validate_data([failing_data_schema])
    with pytest.raises(DataModelError) as e:
        validate_data([failing_data_collision])
    assert (
        str(e.value)
        == "invalid data recieved from data store the following ids are not unique ['1']"
    )
