import pytest
import shutil
from typing import Generator
from pathlib import Path


def pytest_configure(config):
    config.addinivalue_line(
        "markers",
        "define_local_plugin: provide a filename and code when using the local_plugin fixture",
    )


@pytest.fixture
def local_plugin(request) -> Generator[None, None, None]:
    """
    Create a temporary folder `.dotstop_extensions` in the current working
    directory which contains a mock plugin.

    Tests consuming this fixture should define the filename and code for the
    plugin using the custom marker:

    ```
    @pytest.mark.define_local_plugin(filename, code)
    ```
    """
    plugin_filename = request.node.get_closest_marker("define_local_plugin").args[0]
    plugin_code = request.node.get_closest_marker("define_local_plugin").args[1]

    plugin_dir = Path.cwd() / Path(".dotstop_extensions")
    keep_plugin_dir = plugin_dir.exists()
    plugin_dir.mkdir(exist_ok=True)
    plugin_path = plugin_dir / Path(plugin_filename)
    if plugin_path.exists():
        raise FileExistsError(
            f"Could not create temporary named file {str(plugin_path)}"
        )
    plugin_path.write_text(plugin_code)
    yield None
    plugin_path.unlink()
    if not keep_plugin_dir:
        shutil.rmtree(plugin_dir)
