from typing import Callable
import pytest
import trudag.dotstop.core.exception as exception
from trudag.dotstop.core.item import map_and_raise_itemerror, MarkdownItem


# Examples of malformed or invalid items.


@pytest.fixture
def example_invalid_level() -> str:
    return "---\nnormative: true\nlevel: 'top'\n---\nStatement\n"


@pytest.fixture
def example_invalid_order() -> str:
    return "---\nnormative: true\npublish:\n  order: 'top'\n---\nStatement\n"


@pytest.fixture
def example_invalid_normative() -> str:
    return "---\nnormative: 'yes'\nlevel: 1.3.4\n---\nStatement\n"


@pytest.fixture
def example_malformed_frontmatter() -> str:
    return "---\nnormative:yeslevel:3.4\n---\nStatement\n"


@pytest.fixture
def example_missing_frontmatter() -> str:
    return "Statement"


@pytest.fixture
def example_empty_frontmatter() -> str:
    return "---\n---\nStatement\n"


ExampleItemOrdered = Callable[[str, str | None, int | None, str | None], MarkdownItem]
"""
Function signature for example_item_ordered inner function

(name: str, group: str | None, order: int | None, legacy_level: str | None)
"""


@pytest.fixture
def example_item_ordered():
    def inner(
        name: str, group: str | None, order: int | None, legacy_level: str | None
    ) -> MarkdownItem:
        group_fmt = "" if group is None else f"  group: {group}\n"
        order_fmt = "" if order is None else f"  order: {order}\n"
        publish_fmt = (
            ""
            if group is None and order is None
            else f"publish:\n{group_fmt}{order_fmt}"
        )
        legacy_level_fmt = "" if legacy_level is None else f"level: {legacy_level}\n"
        return MarkdownItem.from_markdown(
            name,
            f"---\nnormative: true\n{publish_fmt}{legacy_level_fmt}---",
        )

    return inner


@pytest.mark.parametrize(
    "markdown",
    [
        "example_invalid_level",
        "example_invalid_order",
        "example_invalid_normative",
        "example_missing_frontmatter",
        "example_malformed_frontmatter",
        "example_empty_frontmatter",
    ],
)
def test_invalid_markdown(markdown, request):
    markdown = request.getfixturevalue(markdown)
    with pytest.raises(exception.ItemError):
        MarkdownItem.from_markdown("BAD-ITEM", markdown)


def test_text_with_newlines():
    markdown = (
        "---\nnormative: true\n---\n\nComplex body text\n\n\nContaining newlines\n"
    )
    item = MarkdownItem.from_markdown("GOOD-ITEM", markdown)
    assert item.text == "Complex body text\n\n\nContaining newlines"


def test_name():
    item = MarkdownItem.from_markdown("GOOD-ITEM", "---\nnormative: true\n---")
    assert item.name == "GOOD-ITEM"


def test_str():
    item = MarkdownItem.from_markdown("GOOD-ITEM", "---\nnormative: true\n---")
    assert str(item) == "GOOD-ITEM"


def test_normative_true():
    item = MarkdownItem.from_markdown("GOOD-ITEM", "---\nnormative: true\n---")
    assert item.normative


def test_normative_false():
    item = MarkdownItem.from_markdown("GOOD-ITEM", "---\nnormative: false\n---")
    assert not item.normative


def test_single_score():
    item = MarkdownItem.from_markdown(
        "GOOD-ITEM", "---\nnormative: true\nscore: 0.781\n---"
    )
    assert item.score == 0.781


def test_text_table():
    item = MarkdownItem.from_markdown(
        "GOOD-ITEM",
        """---
normative: false
---
|  a  |  b  |  c  |
| --- | --- | --- |
|  a  |  b  |  c  |
|  a  |  b  |  c  |
""",
    )
    assert (
        item.text
        == """|  a  |  b  |  c  |
| --- | --- | --- |
|  a  |  b  |  c  |
|  a  |  b  |  c  |"""
    )


def test_text_dividers():
    item = MarkdownItem.from_markdown(
        "GOOD-ITEM",
        """---
normative: false
---
---
---
""",
    )
    assert item.text == "---\n---"


def test_multiple_scores():
    markdown = (
        "---\n"
        "normative: true\n"
        "score:\n"
        "    Neil: 0.81\n"
        "    Rachel: 0.901\n"
        "    Nick: 0.17\n"
        "    Christian: 0.62\n"
        "---\n"
        "Statement\n"
    )
    item = MarkdownItem.from_markdown("GOOD-ITEM", markdown)
    assert item.score == pytest.approx(0.62525, rel=1.0e-15)


def test_map_to_itemerror():
    item = MarkdownItem.from_markdown(
        "EXAMPLE-ITEM", "---\nnormative: true\n---\nsentence"
    )

    def undecorated_func(item: MarkdownItem) -> None:  # noqa ARG001
        raise Exception("bad function")

    decorator = map_and_raise_itemerror("bad item", Exception)
    decorated_func = decorator(undecorated_func)

    with pytest.raises(
        exception.ItemError, match="bad item: EXAMPLE-ITEM: bad function"
    ):
        decorated_func(item)


def test_item_order_no_order(example_item_ordered: ExampleItemOrdered):
    """
    Test item order with no ordering defined.

    This falls back to the new item ordering system where it compares item names.
    """

    a = example_item_ordered("a", None, None, None)
    b = example_item_ordered("b", None, None, None)
    c = example_item_ordered("c", None, None, None)

    assert a < b
    assert b < c
    assert a < c


def test_item_order_legacy_mixed(example_item_ordered: ExampleItemOrdered):
    """
    Test new item ordering against old item ordering.

    Old item ordering takes the least priority, getting pushed down as a result.
    """

    a = example_item_ordered("a", None, None, "1.1")
    b = example_item_ordered("b", None, None, None)
    c = example_item_ordered("c", None, None, None)

    assert b < a
    assert c < a


def test_item_order_legacy_only(example_item_ordered: ExampleItemOrdered):
    a = example_item_ordered("a", None, None, "1.1")
    b = example_item_ordered("b", None, None, "1.3")
    c = example_item_ordered("c", None, None, "1.2")

    assert a < b
    assert c < b
    assert a < c


def test_item_order_groups(example_item_ordered: ExampleItemOrdered):
    """
    Tests ordering by group names.

    Names are compared in this case.
    """

    a = example_item_ordered("a", "group_b", None, None)
    b = example_item_ordered("b", "group_a", None, None)
    c = example_item_ordered("c", "group_a", None, None)
    d = example_item_ordered("d", None, None, None)

    # check order by named
    assert b < a
    assert b < c
    assert c < a

    # check order with unnamed group
    assert d < a
    assert d < b
    assert d < c


def test_item_order_number(example_item_ordered: ExampleItemOrdered):
    """
    Tests ordering by numerical order within the unnamed group.

    Lower number means higher priority.

    If no number is used, those take higher priority than ones with numbers, and falls back to name ordering.
    """
    a = example_item_ordered("a", None, 10, None)
    b = example_item_ordered("b", None, 0, None)
    c = example_item_ordered("c", None, -10, None)
    d = example_item_ordered("d", None, None, None)

    # check order by numerical order
    assert b < a
    assert c < b
    assert c < a

    # check order with no value
    assert d < a
    assert d < b
    assert d < c


def test_item_order_number_in_group(example_item_ordered: ExampleItemOrdered):
    """
    Tests ordering by using both numerical order within groups.

    Numerical order cannot affect ordering outside of the defined group (or unnamed group).
    """

    a = example_item_ordered("a", "group_a", 10, None)
    b = example_item_ordered("b", "group_a", 0, None)
    c = example_item_ordered("c", "group_b", 30, None)
    d = example_item_ordered("d", "group_b", 20, None)
    e = example_item_ordered("e", None, 50, None)
    f = example_item_ordered("f", None, 40, None)

    # check order within group_a, group_b, and unnamed
    assert b < a
    assert d < c
    assert f < e

    # check order of groups from group_a
    assert b < a < c
    assert b < a < d

    assert e < b < a
    assert f < b < a

    # check order of groups from group_b
    assert e < d < c
    assert f < d < c
