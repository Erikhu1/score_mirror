# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

import pathlib
import pytest
import hashlib
import trudag.dotstop.core.reference as reference
from typing import Any
from trudag.dotstop.core.exception import ReferenceError


@pytest.fixture
def example_csv_file(tmp_path: pathlib.Path) -> dict[str, Any]:
    """
    Get the path to a csv file with known sha and markdown interpretation.
    """
    reference_path = tmp_path / "data.csv"
    reference_contents = "header 1,header 2\ndata 1,data 2\ndata 3,data 4\n"
    with reference_path.open("w") as reference_file:
        reference_file.write(reference_contents)
    hash = hashlib.sha256()
    hash.update(str.encode(reference_contents))
    return {
        "type": "file",
        "path": reference_path,
        "sha": hash.hexdigest(),
        "markdown": (
            "| header 1   | header 2   |\n"
            "|------------|------------|\n"
            "| data 1     | data 2     |\n"
            "| data 3     | data 4     |\n"
        ),
    }


@pytest.fixture
def example_bst_file(tmp_path: pathlib.Path) -> dict[str, Any]:
    """
    Get the path to a bst file with known sha and markdown interpretation.
    """
    reference_path = tmp_path / "element.bst"
    reference_contents = "kind: pyproject\n\nsources:\n- kind: git_repo\n  url: https://gitlab.com/CodethinkLabs/trustable/trustable\n"
    with reference_path.open("w") as reference_file:
        reference_file.write(reference_contents)
    hash = hashlib.sha256()
    hash.update(str.encode(reference_contents))
    return {
        "type": "file",
        "path": reference_path,
        "sha": hash.hexdigest(),
        "markdown": (
            "````yaml\n"
            "kind: pyproject\n\n"
            "sources:\n"
            "- kind: git_repo\n"
            "  url: https://gitlab.com/CodethinkLabs/trustable/trustable\n"
            "\n"
            "````\n"
        ),
    }


@pytest.fixture
def tmp_reference() -> dict[str, Any]:
    """
    Get the dict and sha for a mock reference, defined in `TMP_REFERENCE`.
    """
    hash = hashlib.sha256()
    hash.update(b"TEMP")
    return {
        "type": "tmp",
        "sha": hash.hexdigest(),
    }


TMP_REFERENCE = """from trudag.dotstop.core.reference.references import BaseReference
class TemporaryReference(BaseReference):
    def __init__(self, sha):
        pass

    @classmethod
    def type(cls) -> str:
        return "tmp"

    @property
    def content(self) -> bytes:
        return b"TEMP"

    def as_markdown(self) -> str:
        return str(self)

    def __str__(self) -> str:
        return "tmp"
"""


@pytest.mark.define_local_plugin("references.py", TMP_REFERENCE)
def test_local_reference(local_plugin, tmp_reference):
    builder = reference.ReferenceBuilder()
    mockref = builder.build(tmp_reference)
    assert mockref.sha == tmp_reference["sha"]


@pytest.mark.parametrize("file", ["example_csv_file", "example_bst_file"])
def test_sha(file, request) -> None:
    file = request.getfixturevalue(file)
    ref = reference.LocalFileReference(file["path"])
    assert ref.sha == file["sha"]


@pytest.mark.parametrize("file", ["example_csv_file", "example_bst_file"])
def test_as_markdown(file, request) -> None:
    file = request.getfixturevalue(file)
    ref = reference.LocalFileReference(file["path"])
    assert ref.as_markdown() == file["markdown"]


@pytest.mark.parametrize("file", ["example_csv_file", "example_bst_file"])
def test_build_sha(file, request) -> None:
    file = request.getfixturevalue(file)
    builder = reference.ReferenceBuilder()
    built_reference = builder.build(file)
    assert built_reference.sha == file["sha"]


@pytest.mark.parametrize("file", ["example_csv_file", "example_bst_file"])
def test_build_as_markdown(file, request) -> None:
    file = request.getfixturevalue(file)
    builder = reference.ReferenceBuilder()
    built_reference = builder.build(file)
    assert built_reference.as_markdown() == file["markdown"]


def test_gitlab_reference_invalid(monkeypatch) -> None:
    token = "foobarbaz"
    monkeypatch.setenv("GITLAB_CI_TOKEN", token)

    ref = reference.GitlabFileReference("gitlab.com", 66600816, "README.md", "main")
    with pytest.raises(
        ReferenceError,
        match=r"Could not GET: .*$",
    ) as err:
        ref.content()

    assert token not in str(err.value)

    ref = reference.GitlabFileReference("https://gitlab.com", -1, "README.md", "main")
    with pytest.raises(
        ReferenceError,
        match=r"Could not GET[^:].*$",
    ) as err:
        ref.content()

    assert token not in str(err.value)

    ref = reference.GitlabFileReference(
        "http://gitlab.com", 66600816, "README.md", "main"
    )
    with pytest.raises(
        ReferenceError,
        match=r"Could not GET[^:].*$",
    ) as err:
        ref.content()

    assert token not in str(err.value)
