import doorstop
import trudag.dotstop
from trudag.dotstop.core.item import ItemOrder


class FakeItem(trudag.dotstop.BaseItem):
    """
    Test double that fakes a `BaseItem`.

    Note this double is intended as a _Fake_, rather than a _Mock_ or _Stub_.

    Built around a simple dictionary allowing easy modification of class
    properties.

    Defaults for all class properties and methods, except `name`, are provided
    as follows:

    - `score`: `None`
    - `text`: `"statement"`
    - `normative`: `True`
    - `_level`: `doorstop.core.types.Level("1.0")`
    - `_separator`: `"-"`
    - `header`: `self.name + self.text`
    - `references()`: []
    - `fallacies()`: {}
    """

    def __init__(self, obj_dict: dict) -> None:
        if "name" not in obj_dict:
            raise ValueError("obj_dict must have field 'name'")
        self.obj_dict = obj_dict

    @property
    def name(self) -> str:
        return self.obj_dict["name"]

    @name.setter
    def name(self, value: str) -> None:
        self.obj_dict["name"] = value

    @property
    def score(self) -> float | None:
        score_data = self.obj_dict.get("score")
        if score_data is None:
            return None

        if isinstance(score_data, float):
            return score_data

        return sum(score_data.values()) / len(score_data.values())

    @property
    def sme_scores(self) -> dict[str, float] | None:
        score_data = self.obj_dict.get("score")
        if score_data is None:
            return None

        if isinstance(score_data, float):
            return None

        return score_data

    @property
    def text(self) -> str:
        return self.obj_dict.get("text", "statement")

    @property
    def normative(self) -> bool:
        return self.obj_dict.get("normative", True)

    @property
    def _level(self) -> doorstop.core.types.Level:
        return self.obj_dict.get("_level", doorstop.core.types.Level("1.0"))

    @property
    def order(self) -> ItemOrder:
        group = self.obj_dict.get("group")
        order = self.obj_dict.get("order")
        return ItemOrder(group, order)

    @property
    def _separator(self) -> str:
        return self.obj_dict.get("_separator", "-")

    def header(self, include_name: bool = True) -> str:
        return self.obj_dict.get("header", self.name + self.text)

    def references(self) -> list[trudag.dotstop.BaseReference]:
        return self.obj_dict.get("references", [])

    def fallacies(self) -> dict[str, trudag.dotstop.Fallacy]:
        return self.obj_dict.get("fallacies", {})

    def validate(self) -> float | None:
        return None
