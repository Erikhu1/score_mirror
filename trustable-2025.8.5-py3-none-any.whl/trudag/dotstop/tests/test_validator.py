# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

import pytest
import trudag.dotstop.core.validator as validator


TMP_VALIDATOR = """from typing import TypeAlias, Generator
yaml: TypeAlias = str | int | float | list["yaml"] | dict[str, "yaml"]

def tmp_validator(
    configuration: dict[str, yaml],
) -> tuple[float, list[Exception | Warning]]:
    return (0.01636, [Exception("fake exception yielded from tmp_validator")])
    """


@pytest.mark.define_local_plugin("validators.py", TMP_VALIDATOR)
def test_local_validator(local_plugin):
    v = validator.Validator()
    assert v.validate("tmp_validator", 0.0) == 0.01636
