# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

"""
A library for creating graphical summaries of trustable software projects.

Functions for creating `.dot` files, and interfacing between graphviz and
dotstop.
"""

import copy
import pydot
import graphviz as gz
import logging
from pathlib import Path
from trudag.dotstop.core.graph import TrustableGraph
from trudag.dotstop.core.item import BaseItem
from trudag.dotstop.core.exception import InvalidArgumentError, GraphActionError


NODE_STYLE = {"shape": "box", "fontname": "Open Sans"}
MARKDOWN_FORMATS = {"markdown", "md"}
SUPPORTED_FORMATS = gz.parameters.formats.FORMATS.union(MARKDOWN_FORMATS)
GRAPH_NAME = "G"

logger = logging.getLogger(__name__)


def plot(
    graph: TrustableGraph,
    line_length: int,
    same_rank: list[list[str]],
    invis_deps: list[tuple[str, str]],
    pick: list[tuple[str, int | None, int | None]],
    orphan_nodes: bool,
    output_file_path: Path = Path("./graph.svg"),
    base_url: str = "",
) -> None:
    """
    Given a dotstop graph in `cwd`, plot the tree using Graphviz.

    Args:
        graph: dotstop.Graph to work on
        line_length (int): Soft limit for characters-per-line in node labels.
        same_rank (list[list[str]]): List of lists of item uids that should appear on the same rank in the plotted graph.
        invis_deps: (list[tuple[str, str]]): List of tuples of item uids that should be invisibly linked.
        pick: (list[tuple[str, int | None, int | None]]): Picks nodes to be retained in the graph, specified by item name and levels of parent / child to be picked.
        orphan_nodes (bool): Retain nodes that isn't linked with anything else.
        file_format (str, optional): Format of plotted graph.
        output_stem (str, optional): File stem for the output file.
        base_url (str, optional): Base url for tooltips. If "", no tooltips are added.
    """
    build_subgraph(graph, pick, orphan_nodes)

    dot_source = gz.Source(
        format_source_from_graph(graph, line_length, same_rank, invis_deps, base_url)
    )

    # Graphviz does not natively support the backticked md/plantuml format needed for mkdocs hyperlinks
    file_format = output_file_path.suffix[1:]
    if file_format not in SUPPORTED_FORMATS:
        raise Exception(
            f"Format {file_format} is not supported. Permitted formats are:\n{sorted(SUPPORTED_FORMATS)}"
        )
    if file_format in MARKDOWN_FORMATS:
        _render_markdown(dot_source, output_file_path)
    else:
        dot_source.format = file_format
        try:
            dot_source.render(output_file_path.with_suffix(""))
        except gz.ExecutableNotFound as err:
            raise GraphActionError(
                "The Graphviz executable was not found, make sure it exists on your system PATH"
            ) from err


def _render_markdown(graph, output_file_path: Path):
    with output_file_path.with_suffix(".md").open("w") as md_graph:
        md_graph.write("```plantuml\n")
        md_graph.write(graph.source)
        md_graph.write("```\n")


def format_source_from_graph(
    graph: TrustableGraph,
    line_length: int,
    same_rank: list[list[str]],
    invis_deps: list[tuple[str, str]],
    base_url: str = "",
) -> str:
    """
    Return a string of dot source code including formatting metadata.

    Args:
        graph (dotstop.core.TrustableGraph): Dotstop Graph to generate source from
        line_length (int): Soft limit for characters-per-line in node labels.
        same_rank (list[list[str]]): List of lists of item uids that should appear on the same rank in the plotted graph.
        invis_deps: (list[tuple[str, str]]): List of tuples of item uids that should be invisibly linked.
        base_url (str, optional): Base url for tooltips. If "", no tooltips are added.
    """
    formatted_graph = pydot.graph_from_dot_data(str(graph))[0]
    formatted_graph.set("rankdir", "TB")
    formatted_graph.set("newrank", "true")

    # Remove edge and node sha's, required to support some plantuml servers.
    for element in formatted_graph.get_nodes() + formatted_graph.get_edges():
        if "sha" in element.get_attributes():
            element.get_attributes().pop("sha")

    for item in graph.items:
        if not item.normative:
            formatted_graph.del_node(pydot.quote_id_if_necessary(str(item)))
        else:
            formatted_node = formatted_graph.get_node(
                pydot.quote_id_if_necessary(str(item))
            )[0]
            formatted_node.set("label", break_line_at(item.header(), line_length))
            formatted_node.set("URL", _mkdocs_url(item, base_url))
            # Set target to avoid URLs opening within the image
            formatted_node.set("target", "_top")
            for key, value in NODE_STYLE.items():
                formatted_node.set(key, value)

    # apply ranks
    for items in same_rank:
        subgraph = pydot.Subgraph(name="")
        for item in items:
            if not formatted_graph.get_node(pydot.quote_id_if_necessary(item)):
                raise Exception(f"Dotstop BaseItem {item} does not exist")
            subgraph.add_node(pydot.Node(name=item))
        subgraph.set("rank", "same")
        formatted_graph.add_subgraph(subgraph)

    # apply invisible edges
    for source, destination in invis_deps:
        invisible_edge = pydot.Edge(
            src=pydot.quote_id_if_necessary(source),
            dst=pydot.quote_id_if_necessary(destination),
            style="invis",
        )
        formatted_graph.add_edge(invisible_edge)

    return formatted_graph.to_string()


def break_line_at(line: str, char_limit: int) -> str:
    """
    Take a one-line string and add line breaks at the first whitespace after
    every `char_limit` characters.

    This will allow words to overrun where necessary.

    Raises a `ValueError` if the input string is multiline.

    Args:
        line (str): Line to break.
        char_limit (int): Soft limit on line length.

    Returns:
        (str): `line` with newlines at the first whitespace after every `char_limit` characters
    """
    if "\n" in line:
        raise ValueError("String must be a single line.")

    words = [word for word in line.split(" ")]

    passage = ""

    for word in words:
        passage += word
        if len(passage.split("\n")[-1]) >= char_limit:
            passage += "\n"
        else:
            passage += " "
    return passage


def _mkdocs_url(node: BaseItem, base_url) -> str:
    if base_url:
        return base_url + "/" + node.document + ".html#" + str(node).lower()
    return ""


def build_subgraph(
    graph: TrustableGraph,
    pick: list[tuple[str, int | None, int | None]],
    include_orphan_nodes: bool,
) -> int:
    """
    Creates a slice of the original graph through arguments.

    !!! THIS FUNCTION IS DESTRUCTIVE !!!
    The slice of the graph is directly operated on the graph passed through the argument.
    If the original graph is needed, make sure to make a copy.

    The intention behind this function is to create a reduced graph for projects that generates
    dense graphs that is hard to view and navigate, and to allow for focusing on a slice of interest.

    This function will do nothing if none of the filtering arguments are effective.

    To allow combining the filter operations together, instead of removing items from the graph on each
    operation being processed, it will initially track which items must be retained per filter.
    This item retaining tracking gets used at the end of this operation to remove all items from the graph
    except for those that are marked to be retained.

    `pick` and `orphan_nodes` filters are added as a basic set of operations to allow focusing on
    points of interest in the graph.

    Args:
        graph (dotstop.core.TrustableGraph): Dotstop Graph to filter.
        pick: (list[tuple[str, int, int]]): Picks nodes to be retained in the graph, specified by item name and levels of parent / child.
        include_orphan_nodes (bool): Retain nodes that isn't linked with anything else.

    Returns:
        (int): Number of items removed.
    """
    if not pick and not include_orphan_nodes:
        logger.debug(
            f"build_subgraph filtered out no items, pick: {pick}, orphan_nodes: {include_orphan_nodes}"
        )
        return 0

    retained_items: set[BaseItem] = set()

    if include_orphan_nodes:
        _subgraph_orphan_nodes(graph, retained_items)

        logger.debug(
            f"build_subgraph orphan_nodes filter will retain {len(retained_items)} items"
        )

    if pick:
        retain_before_count = len(retained_items)

        _subgraph_pick(graph, pick, retained_items)

        logger.debug(
            f"build_subgraph root filter will retain {len(retained_items) - retain_before_count} items"
        )

    # Final operation to apply to graph.
    total_item_count = len(graph.items)
    items = copy.copy(graph.items)
    for item in items:
        if item not in retained_items:
            graph.remove_item(item.name)

    removed_item_count = total_item_count - len(graph.items)
    logger.debug(f"build_subgraph removed {removed_item_count} items")
    return removed_item_count


def _subgraph_orphan_nodes(graph: TrustableGraph, retained_items: set[BaseItem]):
    for item in graph.items:
        if not graph.get_item_parents(item.name) and not graph.get_item_children(
            item.name
        ):
            retained_items.add(item)


def _subgraph_pick(
    graph: TrustableGraph,
    root: list[tuple[str, int | None, int | None]],
    retained_items: set[BaseItem],
):
    for item, parent_lvls, child_lvls in root:
        if parent_lvls is not None and parent_lvls < 0:
            raise InvalidArgumentError(
                f"item `{item}` has parent levels set below 0, which is invalid"
            )

        if child_lvls is not None and child_lvls < 0:
            raise InvalidArgumentError(
                f"item `{item}` has children levels set below 0, which is invalid"
            )

        retained_items.add(graph.get_item(item))

        parents = _get_parents_recursive(graph, item, parent_lvls)
        retained_items.update(parents)
        children = _get_child_recursive(graph, item, child_lvls)
        retained_items.update(children)


def _get_parents_recursive(
    graph: TrustableGraph,
    item_name: str,
    levels: int | None,
) -> list[BaseItem]:
    """
    Gets all linked parents recursively.

    Args:
        graph (dotstop.core.TrustableGraph): Dotstop Graph to use for obtaining items.
        item_name (str): Item name to use as root for obtaining parents of. This item itself won't be included in the result.
        levels (int): Levels to travel. 1 means this function will only obtain the parents of `item_name`.
    """

    if levels is not None and levels <= 0:
        return []

    working_roots = [item_name]
    result: list[BaseItem] = []
    while working_roots and (levels is None or levels > 0):
        item_parents: list[str] = []
        if levels is not None:
            levels -= 1

        for root in working_roots:
            for parent in graph.get_item_parents(root):
                item_parents.append(parent.name)
                result.append(parent)

        working_roots = item_parents

    return result


def _get_child_recursive(
    graph: TrustableGraph,
    item_name: str,
    levels: int | None,
) -> list[BaseItem]:
    """
    Gets all linked children recursively.

    Args:
        graph (dotstop.core.TrustableGraph): Dotstop Graph to use for obtaining items.
        item_name (str): Item name to use as root for obtaining children of. This item itself won't be included in the result.
        levels (int): Levels to travel. 1 means this function will only obtain the children of `item_name`.
    """

    if levels is not None and levels <= 0:
        return []

    working_roots = [item_name]
    result: list[BaseItem] = []
    while working_roots and (levels is None or levels > 0):
        item_children: list[str] = []
        if levels is not None:
            levels -= 1

        for root in working_roots:
            for child in graph.get_item_children(root):
                item_children.append(child.name)
                result.append(child)

        working_roots = item_children

    return result
