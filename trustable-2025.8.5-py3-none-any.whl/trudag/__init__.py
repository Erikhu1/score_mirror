"""
Tools for summarising the compliance of trustable software projects, in written,
graphical and numerical forms.
"""

DOORSTOP_ITEM_SCORE_KEY = "score"
"""
Doorstop attribute key used to store confidence score.
"""
