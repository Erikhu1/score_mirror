# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

"""
Library for creating written summaries of trustable software projects.
"""

from pathlib import Path
from collections import defaultdict
from datetime import datetime
from logging import getLogger
from textwrap import wrap
from trudag.dotstop.core.exception import GraphActionError
from trudag.dotstop.core.data_store.data_model import validate_data
from trudag.dotstop.core.data_store.data_store_client import (
    DATA_STORE_CLIENT_SINGLETON,
    DataStoreClient,
)

import io
from itertools import pairwise
import colorsys

import matplotlib.pyplot as plt
import numpy as np

import doorstop
import trudag.score
import trudag.dotstop as dotstop
import trudag.utils as utils
from trudag.dotstop.core.graph import TrustableGraph
import matplotlib.dates as mdates

logger = getLogger(__name__)

doorstop.settings.PUBLISH_MKDOCS = True
doorstop.settings.PUBLISH_BODY_LEVELS = False
doorstop.settings.PUBLISH_HEADING_LEVELS = False


def publish(
    graph: TrustableGraph,
    project_name: str,
    all_bodies: bool,
    output_path: Path,
    validate: bool,
    dump: Path | None = None,
    figures: bool = False,
    data_store_client: DataStoreClient | None = None,
) -> None:
    """
    Given a doorstop tree in `cwd`, summarise the tree (and its trustable score)
    in the markdown file `"trustable_report_for_" + project_name + ".md"`.

    Also produce a doorstop item summary and nav file.

    Args:
        graph (dotstop.Graph): Graph to summarise
        project_name (str): Name of the trustable software project.
        all_bodies (bool): Include the body text of all (i.e. including non-normative) items in the generated markdown.
        output_path (Path): Directory to write all generated files within.
        validate (bool): Run automated validators.
        dump (Path): Output file path for the Trustable Scores file
        figures (bool): Include time series plots (requires data store)
        data_store_client (DataStoreClient): Injectable DataStoreClient for testing
    """

    # Set up directory for published doorstop items and report
    output_path.mkdir(exist_ok=True, parents=True)

    # Create report
    writer = Report(
        graph,
        project_name,
        output_path=output_path,
        dump=dump,
        non_normative_body=all_bodies,
        run_validators=validate,
        figures=figures,
        data_store_client=data_store_client,
    )

    writer.write_navigation_index(writer.write_report())
    writer.write_dashboard()


class Report:
    def __init__(
        self,
        graph: TrustableGraph,
        project_name: str,
        output_path: Path,
        dump: Path | None = None,
        non_normative_body: bool = False,
        name_references_only=False,
        run_validators: bool = False,
        figures: bool = False,
        data_store_client: DataStoreClient | None = None,
    ) -> "Report":
        """
        The set of information defining a Trustable Report, writeable as markdown.

        Args:
            graph (dotstop.Graph): Graph for the project
            project_name (str): Name of the project
            output_path (Path): Directory to write all generated files within.
            dump (Path): Output filepath to dump trustable score summary to.
            non_normative_body (bool, optional): Include the body text of non-normative items. Defaults to False.
            name_references_only (bool, optional): Do not include the contents of external references. Defaults to False.
            run_validators (bool, optional): Run automated validators. Defaults to False.
            figures (bool): Include time series plots (requires data store).
            data_store_client (DataStoreClient): Injectable DataStoreClient for testing.
        """
        self._graph = graph
        self._project_name = project_name
        self._output_path = output_path
        self._scores = trudag.score.score(graph, run_validators, dump)
        self._non_normative_body = non_normative_body
        self._name_references_only = name_references_only
        self._review_status = self._get_review_status_dict(graph)
        self._figs_path = self._output_path.joinpath("figs")
        self._figs_path.mkdir(parents=True, exist_ok=True)

        self._figures = figures
        self._current_time = datetime.now()
        self._figs_path = self._output_path.joinpath("figs")
        self.__historic_data = None
        self.__data_store_client = data_store_client

        if self._figures:
            Path(self._figs_path).mkdir(parents=True, exist_ok=True)

    def _get_review_status_dict(self, graph: TrustableGraph) -> dict[str, bool]:
        """
        Get review status of all items and return them in a dict
        """
        return {item.name: graph.get_review_status(item.name) for item in graph.items}

    @property
    def _data_store_client(self) -> DataStoreClient:
        if self.__data_store_client is None:
            self.__data_store_client = DATA_STORE_CLIENT_SINGLETON.get()
        return self.__data_store_client

    @property
    def _historic_data(self) -> dict[str, dict[datetime, float]]:
        if not self._figures:
            raise Exception(
                "Report._historic_data shouldn't be called unless the figures flag is set"
            )
        if self.__historic_data is None:
            data = self._data_store_client.pull()
            validate_data(data)
            self.__historic_data = self._transform_data(data)

        return self.__historic_data

    def write_report(self) -> str:
        """
        The Trustable Report as markdown.
        """
        report_name = "trustable_report_for_" + self._project_name.replace(" ", "_")

        report_filepath = self._output_path.joinpath(f"{report_name}.md")

        with report_filepath.open("w") as report:
            self._write_report_preamble(report)

            for prefix, document in self._graph.documents_to_items_map().items():
                doc_filepath = self._output_path.joinpath(f"{prefix}.md")
                with doc_filepath.open("w") as file:
                    self._write_document_preamble(report, prefix, document)
                    for item in document:
                        self._write_item_summary(file, doc_filepath, item)
                        if not self._figures:
                            continue
                        self._plot_and_save_figure(item)

            self._write_report_afterword(report)

        return report_name

    def write_navigation_index(self, report_name: str) -> None:
        """
        The Trustable Report's navigation as formatted markdown.

        Args:
            report_name (str): Trustable Report's file stem.
        """

        # Build index of Doorstop documents
        index_path = self._output_path.joinpath("nav.md")
        with index_path.open("w") as index_file:
            index_file.write(f"- [Compliance report]({report_name}.md)\n")
            index_file.write("- [Dashboard](dashboard.md)\n")

            # Create sorted index of documents
            items = sorted(self._output_path.glob("*.md"))
            for item in items:
                filename = Path(item).name
                filename_no_ext = filename.rstrip("*.md")
                if (
                    filename_no_ext != "nav"
                    and filename_no_ext[:16] != "trustable_report"
                    and filename != "dashboard.md"
                ):
                    index_file.write(f"* [{filename_no_ext}]({filename})\n")

    def write_dashboard(self) -> None:
        dash_path = self._output_path.joinpath("dashboard.md")
        with dash_path.open("w") as file:
            file.write("# Dashboard\n")
            self._write_histograms(file)
            self._write_statistics(file)

    def _score_item(self, item: dotstop.BaseItem) -> float:
        """
        Given an item, get its calculated trustable score.

        All reviewed items are expected to have a corresponding entry in
        `self._scores`. Requesting the score for a reviewed item that is not in
        `self._scores` will result in an error.

        Args:
            item (dotstop.BaseItem): Item to score.

        Returns:
            float: score for `item`.
        """

        if str(item) in self._scores:
            return self._scores[str(item)]
        if not self._review_status[item.name]:
            return 0.0
        raise AssertionError(
            "Unexpected reviewed item without score encountered during score lookup."
        )

    def _style_item(
        self, item: dotstop.BaseItem, parent: dotstop.BaseItem | None = None
    ) -> str:
        """
        Choose a style for `item` based on Trustable Score and review status.

        If `parent` is specified, apply a special style if their link is
        suspect.

        Args:
            item (dotstop.BaseItem): Item to select style for.
            parent (dotstop.BaseItem) | None, optional): Parent for link investigation. Defaults to None.

        Returns:
            str: css style for `item`
        """
        style = 'class="tsf-score"'
        style += (
            f' style="background-color:{self._colormap_str(self._score_item(item))}"'
        )

        if not self._review_status[item.name]:
            style += " .status-unreviewed"
        elif parent and (
            self._graph.get_link_status(str(parent), str(item))
            == dotstop.LinkStatus.SUSPECT
        ):
            style += " .status-suspect"

        return style

    def _transform_data(self, data: list[dict]) -> dict[str, dict[datetime, float]]:
        """
        transforms historic data into a format usable by _make_graph

        ```
        [
            {
                "scores": [{"id": str, "score": float}, ...],
                "info": {"Commit date/time": str, ...}
            }
        ]
                                |
                                V
        {
            str (id): {datetime: float (score)}
        }
        ```

        Args:
            data (list[dict]): historic data provided by the data store client
        Returns:
            dict: the formatted data
        """
        out = defaultdict(lambda: {})
        for entry in data:
            date = entry["info"]["Commit date/time"]
            date = datetime.strptime(date, "%a %b %d %H:%M:%S %Y")
            for score in entry["scores"]:
                name = score["id"]
                out[name][date] = float(score["score"])

        for k, v in out.items():
            try:
                current_score = self._score_item(self._graph.get_item(k))
            except GraphActionError:
                continue
            v[self._current_time] = current_score

        return {k: dict(sorted(v.items())) for k, v in out.items()}

    def _write_figure_tables(self, file: io.TextIOWrapper, item: dotstop.BaseItem):
        parent_string = str(item)
        parent_data = self._historic_data.get(parent_string)
        if not parent_data:
            raise Exception(f"Cant plot figs. No data for item {parent_string}.")
        if len(parent_data) == 1:
            file.write("no data in data store.\n\n")
            logger.debug(f"{parent_string} Has no entries in the data store.")
            return
        child_strings = [str(c) for c in self._graph.get_item_children(parent_string)]

        indent = "    "
        tbl_columns = indent + f"|date-time|{parent_string}|"
        tbl_div = indent + "|-|-|"

        rows_data = {
            k: [self._style_table_score(v)] + ["N/A"] * len(child_strings)
            for k, v in parent_data.items()
        }

        for i, name in enumerate(child_strings, 1):
            data = self._historic_data.get(name)
            if data is None:
                continue
            tbl_columns += f"{name}|"
            tbl_div += "-|"
            for k, v in data.items():
                if k not in list(rows_data.keys()):
                    continue
                rows_data[k][i] = self._style_table_score(v)

        tbl_rows = [indent + f"|{k}|" + "|".join(v) + "|" for k, v in rows_data.items()]
        file.write(
            '\n??? example "Graph Data as Table"\n'
            + "\n".join([tbl_columns] + [tbl_div] + tbl_rows)
            + "\n\n"
        )

    def _plot_and_save_figure(self, item: dotstop.BaseItem):
        """
        plots timeseries graphs from historic data and saves as .svgs for display in the reports

        Args:
            item (dotstop.BaseItem): The Item to make the graph for
        """
        parent_string = str(item)
        parent_data = self._historic_data.get(parent_string)
        if parent_data is None:
            return
        child_strings = [str(c) for c in self._graph.get_item_children(parent_string)]

        plt.style.use("bmh")
        colours = plt.cm.winter(np.linspace(0, 1, len(child_strings)))
        _, (ax, legend_ax) = plt.subplots(
            1, 2, gridspec_kw={"width_ratios": [1.618, 1]}
        )

        for i, child in enumerate(child_strings):
            child_data = self._historic_data.get(child)
            if child_data is None:
                continue
            x_dates = child_data.keys()
            y_scores = child_data.values()
            label = "\n".join(wrap(child, 20))
            ax.plot(
                x_dates, y_scores, linewidth=1, label=label, alpha=0.5, color=colours[i]
            )

        x_dates = parent_data.keys()
        y_scores = parent_data.values()
        label = "\n".join(wrap(parent_string, 20))
        ax.plot(x_dates, y_scores, linewidth=3, label=label, alpha=1, color="red")

        ax.xaxis.set_major_locator(mdates.MonthLocator())
        ax.xaxis.set_minor_locator(mdates.WeekdayLocator(byweekday=1))
        ax.xaxis.set_major_formatter(
            mdates.ConciseDateFormatter(ax.xaxis.get_major_locator())
        )
        plt.xticks(rotation=45, ha="right", fontsize="small")
        legend_ax.axis("off")
        legend_ax.legend(*ax.get_legend_handles_labels(), loc="center")
        plt.savefig(
            self._figs_path.joinpath(f"{parent_string}.svg"),
            format="svg",
            bbox_inches="tight",
        )
        plt.close()

    def _write_item_summary(
        self, file: io.TextIOWrapper, filepath: Path, item: dotstop.BaseItem
    ) -> None:
        """
        Write a summary of an item's score and a its child items.

        Args:
            file (io.TextIOWrapper): Stream to write to
            filepath (Path): Path of file to write to
            item (dotstop.BaseItem): Item to summarise
        """
        if not item.normative and self._non_normative_body:
            file.write("\n\n---\n")
            file.write(f"\n{item.text}\n")
        elif item.normative:
            file.write("\n\n---\n")
            file.write(
                f"\n### {str(item)} ### "
                f"{{: .item-element .item-section {self._style_item(item)}}}\n"
            )
            file.write(f"\n{item.text}\n{{: .expanded-item-element }}\n")
            file.write("\n**Supported Requests:**\n\n")
            for parent_item in self._graph.get_item_parents(str(item)):
                file.write(
                    f"- [{str(parent_item)}]({parent_item.document}.md#{str(parent_item).lower()})"
                    f"{{.item-element {self._style_item(parent_item)}}}\n"
                )
            file.write("\n**Supporting Items:**\n\n")
            if self._graph.get_item_children(str(item)):
                for child_item in self._graph.get_item_children(str(item)):
                    file.write(
                        f"- [{str(child_item)}]({child_item.document}.md#{str(child_item).lower()})"
                        f"{{.item-element {self._style_item(child_item, parent=item)}}}\n"
                    )
            else:
                file.write("_None_\n")

            self._write_item_references(file, filepath, item)
            self._write_item_fallacies(file, filepath, item)

            if self._figures:
                file.write("\n**Graph:**\n\n")
                if self._historic_data.get(str(item)) is not None:
                    file.write(f"![No Image](figs/{str(item)}.svg)\n")
                    self._write_figure_tables(file, item)
                else:
                    file.write("_No Historic Data Found_\n")

    def _write_item_references(
        self, file: io.TextIOWrapper, filepath: Path, item: dotstop.BaseItem
    ):
        """
        Write name or embed an item's references.

        Args:
            file (io.TextIOWrapper): Stream to write to
            filepath (Path): Path of file to write to
            item (dotstop.BaseItem): Item references to write
        """
        file.write("\n{% raw %}\n")
        file.write("\n**References:**\n\n")
        if not item.references():
            file.write("_None_\n")
        for ref in item.references():
            file.write(f"- `{escape_problem_characters(str(ref))}`\n\n")
            file.write('\t??? "Click to view reference"\n')
            file.write(
                "\t\t".join(
                    f"\n{escape_problem_characters(ref.as_markdown(filepath))}".splitlines(
                        True
                    )
                )
            )
            file.write("\n\n")
        file.write("\n{% endraw %}\n")

    def _write_item_fallacies(
        self, file: io.TextIOWrapper, filepath: Path, item: dotstop.BaseItem
    ):
        """
        Write name or embed an item's fallacies.

        Args:
            file (io.TextIOWrapper): Stream to write to
            filepath (Path): Path of file to write to
            item (dotstop.BaseItem): Item's fallacies to write
        """
        file.write("\n**Fallacies:**\n\n")
        if not item.fallacies():
            file.write("_None_\n")
        for name, fallacy in item.fallacies().items():
            file.write(f"- **{name}**: _{fallacy.description}_\n\n")
            file.write('\t??? "Click to view reference"\n')
            file.write(
                "\t\t".join(
                    f"\n{fallacy.reference.as_markdown(filepath=filepath)}".splitlines(
                        True
                    )
                )
            )
            file.write("\n\n")

    def _write_document_preamble(
        self, file: io.TextIOWrapper, prefix: str, document: list[dotstop.BaseItem]
    ) -> None:
        """
        Summarise the Document name and scores.

        Args:
            file (io.TextIOWrapper): Stream to write to.
            prefix (str): Name of the document to summarise.
            document (list[dotstop.BaseItem]): Constituent `BaseItem`s of the document.
        """
        file.write(f"\n## Compliance for {prefix}\n\n")
        file.write("| Item   | Summary | Score |\n")
        file.write("|--------|---------|-------|\n")
        for item in document:
            if item.normative:
                file.write(
                    f"| [{str(item)}]({prefix}.md#{str(item).lower()}) {{{self._style_item(item)}}}"
                    f"| {item.header(include_name=False)} "
                    f"| {self._score_item(item):.2f} |\n"
                )

    def _write_report_preamble(self, file: io.TextIOWrapper) -> None:
        """
        Summarise the project and provide a color key.

        Args:
            file (io.TextIOWrapper): Stream to write to
        """
        file.write("# Trustable Compliance Report\n\n")
        file.write("\n\n## Item status guide ## { .subsection }\n\n")
        file.write(
            "Each item in a Trustable Graph is scored with a number between 0 and 1.\n"
        )
        file.write(
            "The score represents aggregated organizational confidence in a given Statement,"
            " with larger numbers corresponding to higher confidence.\n"
        )
        file.write(
            "Scores in the report are indicated by both a numerical score and the colormap below:\n"
        )
        file.write(self._colorbar())
        file.write("\n\nThe status of an item and its links also affect the score.\n")
        file.write(
            "\nUnreviewed items are indicated by a strikethrough.\n"
            "The score of unreviewed items is always set to zero.\n\n"
        )
        file.write(
            "\nSuspect links are indicated by italics.\n"
            "The contribution to the score of a parent item by a suspiciously "
            "linked child is always zero, regardless of the child's own score."
        )

    def _write_report_afterword(self, file: io.TextIOWrapper) -> None:
        """
        Complete a report with the commit details.

        Args:
            file (io.TextIOWrapper): Stream to write to
        """

        file.write(f"\n\n---\n\n_Generated for: {self._project_name}_\n\n")
        file.write(f"* _Repository root: {utils.get_root_dir()}_\n")
        file.write(f"* _Commit SHA: {utils.get_commit_sha()}_\n")
        file.write(f"* _Commit date/time: {utils.get_commit_date()}_\n")
        file.write(f"* _Commit tag: {utils.get_last_tag()}_\n")

    def _write_histogram_as_table(self, file: io.TextIOWrapper, scores: list[float]):
        indent = "    "
        hist, bin_edges = np.histogram(scores, [i / 10 for i in range(11)])
        bins = [f"{a}-{b}" for a, b in pairwise(bin_edges)]
        file.write('??? example "click to view figure as table"\n\n')
        file.write(indent + "|bin|count|\n")
        file.write(indent + "|-|-|\n")
        for count, bin in zip(hist, bins):
            file.write(
                indent
                + f"|{bin} {{{self._style_histogram_table_bin(bin)}}} |{count}|\n"
            )

    def _write_histograms(self, file: io.TextIOWrapper):
        for name, items in (
            ("evidence", self._graph.get_premises()),
            ("expectations", self._graph.get_expectations()),
            ("all", self._graph.items),
        ):
            scores = [self._score_item(item) for item in items if item.normative]
            self._histogram(scores, name)
            file.write(f"## {name.title()} Score Distribution\n\n")
            file.write(
                f"The distribution of scores for {name} nodes across the graph.\n\n"
            )
            file.write(f"![No Image](figs/{name}_hist.svg)\n\n")
            self._write_histogram_as_table(file, scores)
        for name, scores in self._get_sme_scores().items():
            self._histogram(scores, name)
            file.write(f"## {name.title()} SME Score Distribution\n\n")
            file.write(f"![No Image](figs/{name}_hist.svg)\n\n")
            self._write_histogram_as_table(file, scores)

    def _histogram(self, scores: list[float], name: str):
        nbins = 10
        _, _, patches = plt.hist(scores, [i / 10 for i in range(nbins + 1)])
        for i, p in enumerate(patches):
            colour = self._colormap_hsl(i / nbins)
            plt.setp(
                p,
                "facecolor",
                colorsys.hls_to_rgb(colour[0] / 360, colour[2] / 100, colour[1] / 100),
            )
        plt.xlabel("score")
        plt.ylabel("count")
        plt.savefig(
            self._figs_path.joinpath(f"{name}_hist.svg"),
            format="svg",
            bbox_inches="tight",
        )
        plt.close()

    def _write_statistics(self, file: io.TextIOWrapper):
        file.write("## Summary\n\n")
        num_items = len(self._graph.items)
        num_items_reviewed = self._get_num_items_reviewed()
        num_items_unreviewed = num_items - num_items_reviewed
        evidence = self._graph.get_premises()
        num_evidence = len(evidence)
        num_items_evidence = len(
            [
                item
                for item in self._graph.items
                if set(self._graph.get_item_children(item.name)) & set(evidence)
            ]
        )
        num_expectations = len(self._graph.get_expectations())
        num_orphaned_statements = len(
            [item for item in self._graph.get_orphaned_items() if item.normative]
        )
        file.write(
            f"""
| Category | Count |
|----------|-------|
|statements|{num_items}|
|reviewed statements|{num_items_reviewed}|
|unreviewed statements|{num_items_unreviewed}|
|orphaned statements|{num_orphaned_statements}|
|statements with evidence|{num_items_evidence}|
|evidence|{num_evidence}|
|expectations|{num_expectations}|
"""
        )

    def _colormap_hsl(self, score: float) -> tuple[float, int, int]:
        """
        Map the interval [0,1] to hsl colorspace, using a linear colormap.
        """
        MIN_HUE = 0.0
        MAX_HUE = 120.0
        SATURATION = 100
        MIN_LIGHTNESS = 30
        MAX_LIGHTNESS = 65
        hue = MIN_HUE + score * (MAX_HUE - MIN_HUE)
        lightness = int(MAX_LIGHTNESS - score * (MAX_LIGHTNESS - MIN_LIGHTNESS))
        return (hue, SATURATION, lightness)

    def _colormap_str(self, score: float) -> str:
        """
        Map the interval [0,1] to an html hsl value, using a linear colormap.
        """
        hsl = self._colormap_hsl(score)
        return f"hsl({hsl[0]}, {hsl[1]}%, {hsl[2]}%)"

    def _colorbar(self) -> str:
        """
        A colorbar for this `Report`'s colormap as an html element.
        """
        return (
            '<div class="br" style="height: 26px; width: 80%;'
            + f'background: linear-gradient(to right in hsl, {self._colormap_str(0.0)} 0%, {self._colormap_str(1.0)} 100%);">\n'
            + '<span style="float:right;">1.00&nbsp</span>\n'
            + '<span style="float:left;">&nbsp0.00</span>\n'
            + "</div>\n"
        )

    def _style_table_score(self, score: float) -> str:
        """
        Choose a style for a table entry based on Trustable Score.
        """
        style = f'style="background-color:{self._colormap_str(score)}"'

        return f"{score:.2f} {{{style}}}"

    def _style_histogram_table_bin(self, bin: str) -> str:
        """
        Choose a style for table bin based on Trustable Score.
        """
        style = (
            f'style="background-color:{self._colormap_str(float(bin.split("-")[1]))}"'
        )

        return style

    def _get_num_items_reviewed(self) -> int:
        return len(
            list(
                filter(
                    lambda item: self._graph.get_review_status(str(item)),
                    self._graph.items,
                )
            )
        )

    def _get_sme_scores(self) -> dict[str, list[float]]:
        """
        Gets the distribution of scores for each sme
        """
        out = defaultdict(list)
        for item in self._graph.items:
            sme_scores = item.sme_scores
            if sme_scores:
                for k, v in sme_scores.items():
                    out[k].append(v)
        return out


# Replaces <> with escape equivalents, to prevent the HTML rendered from the markdown
# interpreting generics as HTML tags
def escape_problem_characters(original: str) -> str:
    return original.replace("<", "&lt;").replace(">", "&gt;")
