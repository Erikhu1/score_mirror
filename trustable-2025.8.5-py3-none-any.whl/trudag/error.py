from enum import IntEnum


class ExitCodes(IntEnum):
    SUCCESS = 0
    LINT_FAILURE = 1
