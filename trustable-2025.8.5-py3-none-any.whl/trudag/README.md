# Trustable-compliance

A documentation generation tool for the Trustable Software Framework.

## Installation

Be sure you have at least:

- python >= 3.9
- poetry >= 2.0

From the root directory of the trustable repository, run the following:

```shell
poetry build
pip install dist/trustable-<VERSION>.tar.gz
```

## Usage

See the full documentation [here](../docs/trudag/overview.md)

## Dependencies

- Building `trudag` requires [poetry](https://python-poetry.org/) version 2.0.0 or newer.
- Using `trudag`'s plotting functionality requires an instance of [Graphviz](https://graphviz.org/).

## License

The tools in this directory are licensed under Eclipse Public License 2.0.
See the Eclipse Foundation site [here](https://www.eclipse.org/legal/epl-2.0/)
for more information, or see the license text [here](LICENSE).
