# ******************************************************************************
# * Copyright (c) 2024-5 Codethink
# *
# * This program and the accompanying materials are made available under the
# * terms of the Eclipse Public License 2.0 which is available at
# * http://www.eclipse.org/legal/epl-2.0.
# *
# * This Source Code may also be made available under the following Secondary
# * Licenses when the conditions for such availability set forth in the Eclipse
# * Public License, v. 2.0 are satisfied: GNU General Public License, version 2
# * with the GNU Classpath Exception which is
# * available at https://www.gnu.org/software/classpath/license.html.
# *
# * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
# ******************************************************************************

"""
Additional functionality required by but not specific to the CLI.
"""

import logging
from multiprocessing.pool import ThreadPool

from pathlib import Path
from colorama import Fore, Style
from trudag.dotstop.core.graph import LinkStatus
from trudag.dotstop import MarkdownItem
from trudag.dotstop.core.item import ITEM_SEPARATOR
from trudag.dotstop.core.exception import GraphActionError, GitError
from trudag.dotstop.core.graph import TrustableGraph
from trudag.dotstop.core.graph.graph_factory import build_trustable_graph
from trudag.error import ExitCodes
from trudag import utils
from git import GitCommandError, Repo
import json

logger = logging.getLogger(__name__)


def create_new_item(
    prefix: str,
    path: Path,
    parent: str,
    uid: str,
    output_file: Path,
    dot_graph: TrustableGraph,
) -> None:
    """
    Create a new [`MarkdownItem`][trudag.dotstop.core.item.MarkdownItem] in the filesystem and add it to `dot_graph`.

    Updates `dot_graph` and writes it as dot to `output_file`.
    Creates a [default][trudag.dotstop.core.item.MarkdownItem.create_default_item] item file at `f"{path}/{prefix}-{name}.md"`.

    Args:
        prefix: Document prefix for the new item
        path: Directory where new item will be written.
        parent: Name of the parent item, if any.
        uid: Unique (within a document) name for the item.
        output_file: File to write the updated graph to.
        dot_graph: Graph to update and write to file.
    """
    if not uid:
        raise ValueError("The UID is not allowed to be empty")
    if ITEM_SEPARATOR in uid:
        err_msg = f"Cannot create an item with name {uid}, as it contains reserved character {ITEM_SEPARATOR}"
        raise GraphActionError(err_msg)
    if not path.exists():
        path.mkdir(parents=True)
    elif path.exists() and not path.is_dir():
        raise FileExistsError(f"Path '{path} exists but is not a directory")

    item_name = (prefix + ITEM_SEPARATOR + uid).upper()
    try:
        dot_graph.add_items([MarkdownItem.create_default_item(path, item_name)], parent)
        return dot_graph.to_file(output_file)
    except ValueError:
        if (filename := path / f"{item_name}.md").exists():
            filename.unlink()
        raise


def describe_item(graph: TrustableGraph, item_name: str, statement: bool) -> str:
    """
    Describes item and formats item details as a human-readable output.

    Args:
        graph: Graph to use for describing the item
        item_name: Item name to be described
        statement: If statement of the item should be included in the output
    """
    reviewed = "reviewed" if graph.get_review_status(item_name) else "unreviewed"
    statement_output = ""
    if statement:
        statement_output = f"\nstatement:\n{graph.get_item(item_name).text}\n"
    parents = "\n".join([parent.name for parent in graph.get_item_parents(item_name)])
    children = "\n".join([child.name for child in graph.get_item_children(item_name)])

    return (
        f"item name: {item_name}\n"
        f"review status: {reviewed}\n"
        f"{statement_output}\n"
        "parents:\n"
        f"{parents}\n\n"
        "children:\n"
        f"{children}"
    )


def _worker_linter(
    graph: TrustableGraph, item_name: str
) -> tuple[str | None, list[tuple[str, str]]]:
    """
    Worker function which allows for a parallelising the linting of the graph.
    This will check a single item, for its review status and the review status of its child links.

    Args:
        graph (TrustableGraph): The graph, which contains the item, to lint.
        item (str): The item to check for its review status.

    Returns:
        unreviewed (str): If item is unreviewed then the item name will be included, otherwise None.
        suspect_links (list[tuple[str, str]]: If any of the links from this item to its children are un-reviewed
    """
    unreviewed = None
    suspect_links = []

    if not graph.get_review_status(item_name):
        unreviewed = item_name

    for child in graph.get_item_children(item_name):
        child_name = child.name
        if graph.get_link_status(item_name, child_name) == LinkStatus.SUSPECT:
            suspect_links.append((item_name, child_name))

    return (unreviewed, suspect_links)


def _lint(
    graph: TrustableGraph, workers: int | None
) -> tuple[ExitCodes, list[str], list[tuple[str, str]]]:
    """
    Analyze the given graph for unreviewed items and suspect links.

    Args:
        graph (TrustableGraph): The graph to lint.
        workers (int | None): The upperbound on worker threads to spawn.

    Returns:
        tuple:
            - ExitCodes: LINT_FAILURE if any issues are found, SUCCESS otherwise.
            - list[str]: List of unreviewed item names.
            - list[tuple[str, str]]: List of suspect links in a (item, child) pair.
    """
    error_code = ExitCodes.SUCCESS
    unreviewed_items = []
    suspect_links = []

    with ThreadPool(processes=workers) as pool:
        # Prepare the arguments for each call to worker function
        work_items = [(graph, item.name) for item in graph.items]

        # Call the worker function start in parallel
        for unreviewed, suspect in pool.starmap(_worker_linter, work_items):
            if unreviewed:
                unreviewed_items.append(unreviewed)
            if suspect:
                suspect_links.extend(suspect)

        # Check and set the return flags
        if unreviewed_items or suspect_links:
            error_code = ExitCodes.LINT_FAILURE

    return error_code, unreviewed_items, suspect_links


def _lint_dump_json(
    dump: Path, unreviewed_items: list[str], suspect_links: list[tuple[str, str]]
) -> None:
    with dump.open("w") as file:
        json.dump(
            _lint_result_json(unreviewed_items, suspect_links),
            file,
            ensure_ascii=False,
        )


def lint(graph: TrustableGraph, dump: Path | None, workers: int | None) -> ExitCodes:
    """
    Perform linting on the graph and log warnings for any issues found.

    Args:
        graph (TrustableGraph): The graph to lint.
        dump (Path | None): Dumps the result into a specified path. Extension determines the format of the dump.
            Allowed extensions: .json
        workers (int | None): The upperbound for worker threads to be spawned.

    Returns:
        ExitCodes: LINT_FAILURE if issues are found, SUCCESS otherwise.
    """
    lint_dump_exts = {".json": _lint_dump_json}

    if dump and (dump.suffix not in lint_dump_exts):
        raise ValueError(
            "Dump was used, but the file extension is not supported. The extension `json` is supported"
        )

    exit_code, unreviewed_items, suspect_links = _lint(graph, workers)

    if dump:
        lint_dump_exts[dump.suffix](dump, unreviewed_items, suspect_links)

    for item in unreviewed_items:
        logger.warning(f"Unreviewed Item: {item}")

    for link in suspect_links:
        logger.warning(f"Suspect Link: {_format_suspect_link(link)}")

    return exit_code


def _lint_result_json(
    unreviewed_items: list[str], suspect_links: list[tuple[str, str]]
) -> dict[str, object]:
    return {
        "unreviewed_items": unreviewed_items,
        "suspect_links": [
            {"parent": link[0], "child": link[1]} for link in suspect_links
        ],
    }


def _log_lint_message(message: str, lint_added: bool, affected_items: set[str]):
    """
    Log a formatted warning message for lint differences.

    Args:
        message (str): The message to log as a header.
        lint_added (bool): Whether the lint was added (True) or removed (False).
        affected_items (set[str]): Items to include in the log message.
    """
    if not affected_items:
        return

    colour_code = Fore.GREEN if lint_added else Fore.RED

    if affected_items:
        affected_items_str = "\n".join([f"  {item}" for item in affected_items])

        logger.warning(
            f"{message}:\n\n{colour_code}{affected_items_str}{Style.RESET_ALL}\n"
        )


def _compare_sets(set_1: set[str], set_2: set[str]):
    """
    General helper function to compare two sets

    Args:
        set_1 (set): First set to compare.
        set_2 (set): Second set to compare.

    Returns:
        tuple:
            - set: Items common to both sets.
            - set: Items only in set_1.
            - set: Items only in set_2.
    """
    only_in_set_1 = set_1 - set_2
    only_in_set_2 = set_2 - set_1

    common = set_2 - only_in_set_2

    return common, only_in_set_1, only_in_set_2


def _compare_lint_outputs(
    current_unreviewed_items: list[str],
    current_suspect_links: list[tuple[str, str]],
    branch_unreviewed_items: list[str],
    branch_suspect_links: list[tuple[str, str]],
) -> ExitCodes:
    """
    Compare lint results between two graphs and log differences.

    Args:
        current_unreviewed_items (list[str]): Current unreviewed items.
        current_suspect_links (list[str]): Current suspect links.
        branch_unreviewed_items (list[str]): Unreviewed items from branch.
        branch_suspect_links (list[str]): Suspect links from branch.

    Returns:
        ExitCodes: LINT_FAILURE if any differences are found, otherwise SUCCESS.
    """
    _, added_unreviewed_items, removed_unreviewed_items = _compare_sets(
        set(current_unreviewed_items), set(branch_unreviewed_items)
    )
    _, added_suspect_links, removed_suspect_links = _compare_sets(
        set(_format_suspect_link(link) for link in current_suspect_links),
        set(_format_suspect_link(link) for link in branch_suspect_links),
    )

    _log_lint_message("Unreviewed items added", True, added_unreviewed_items)
    _log_lint_message("Unreviewed items removed", False, removed_unreviewed_items)
    _log_lint_message("Suspect links added", True, added_suspect_links)
    _log_lint_message("Suspect links removed", False, removed_suspect_links)

    if (
        added_unreviewed_items
        or removed_unreviewed_items
        or added_suspect_links
        or removed_suspect_links
    ):
        return ExitCodes.LINT_FAILURE

    return ExitCodes.SUCCESS


def _format_suspect_link(suspect_link: tuple[str, str]) -> str:
    return f"{suspect_link[0]} -> {suspect_link[1]}"


def _get_changed_items(
    graph_1: TrustableGraph, graph_2: TrustableGraph
) -> tuple[list[str], dict[str, dict[str, float]]]:
    """
    Identify changed items and those with SME scores between two graphs.

    Args:
        graph_1 (TrustableGraph)
        graph_2 (TrustableGraph)

    Returns:
        tuple:
            - list[str]: Names of items with differing SHAs.
            - dict[str, dict[str, float]]: Mapping of changed SME item names to their scores.
    """
    changed_items = []
    changed_items_with_sme_scores = {}

    # for items in graph_1.documents_to_items_map().values():
    for item in graph_1.items:
        try:
            _ = graph_2.get_item(item.name)
        except GraphActionError:
            # Ignore items that have been added/removed
            continue

        # Use get_stored_sha method instead of get_item().sha as get_item().sha
        # is expensive and might require context (e.g. LocalFile reference)
        # that could have changed during context switch
        if graph_1.get_item_sha(item.name) != graph_2.get_item_sha(item.name):
            changed_items.append(item.name)

            item_obj = graph_1.get_item(item.name)

            if item_obj.sme_scores:
                changed_items_with_sme_scores[item.name] = item_obj.sme_scores

    return changed_items, changed_items_with_sme_scores


def lint_diff(
    current_graph: TrustableGraph, compare_branch: str, workers: int | None
) -> ExitCodes:
    """
    Compare the current graph against another git branch's graph and log differences.

    Logs:
        - New or removed unreviewed items
        - New or removed suspect links
        - Items with changed SHAs
        - Changed items with associated SME scores

    Warning:
        This function checks out the target git branch temporarily,
        and restores HEAD afterward.

    Args:
        current_graph (TrustableGraph): The current working graph.
        compare_branch (str): The git branch to compare against.
        workers (int | None): The upperbound for worker threads to spawn.

    Returns:
        ExitCodes: LINT_FAILURE if any differences are found, SUCCESS otherwise.
    """
    # fail fast if target is invalid
    repo = utils.get_repo()
    try:
        repo.git.rev_parse(compare_branch)
    except GitCommandError as err:
        raise GitError("Failed to find target branch") from err

    # fail fast if dotstop file doesn't exist in the target branch
    try:
        repo.git.cat_file(
            f"{compare_branch}:{utils.DOTSTOP_DEFAULT_FILENAME.name}",
            e=True,
        )
    except GitCommandError as err:
        raise GitError(
            f"Failed to find {utils.DOTSTOP_DEFAULT_FILENAME.name} in the target branch"
        ) from err

    logger.info("Linting current graph...")
    _, current_unreviewed_items, current_suspect_links = _lint(current_graph, workers)

    dirty = repo.is_dirty()
    if dirty:
        logger.warn(
            "Stashing dirty changes before checking out branch, ensure uncommited files are restored from stash"
        )
        repo.git.stash(include_untracked=True)

    prev_head = repo.head
    logger.warning(
        f"Checking out git branch {compare_branch}, ensure head is correctly restored"
    )
    repo.git.switch(compare_branch, detach=True)

    # Safety net to make sure we never leave user's git head at compare_branch
    try:
        workdir = utils.get_workdir()
        branch_graph = build_trustable_graph(
            items_source=workdir, graph_source=workdir / utils.DOTSTOP_DEFAULT_FILENAME
        )

        logger.info(f"Linting target graph ({compare_branch})...")
        _, branch_unreviewed_items, branch_suspect_links = _lint(branch_graph, workers)
    except Exception:
        _restore_git_head(repo, dirty)
        raise

    _restore_git_head(repo, dirty)

    changed_items, changed_items_with_sme_scores = _get_changed_items(
        current_graph, branch_graph
    )

    for changed_item in changed_items:
        exit_code = ExitCodes.LINT_FAILURE
        item_file = list(Path().rglob(f"{changed_item}.*"))

        if not item_file:
            logger.warning(f"Item {changed_item} can not be found")
            continue
        if len(item_file) > 1:
            logger.warning(
                f"Item {changed_item} has multiple files, only showing first file's contents"
            )

        logger.warning(
            f"Item has been changed {changed_item}:\n"
            f"{utils.OUTPUT_SEPARATOR}\n"
            f"{item_file[0].read_text()}\n"
            f"{utils.OUTPUT_SEPARATOR}\n"
        )

    exit_code = _compare_lint_outputs(
        current_unreviewed_items,
        current_suspect_links,
        branch_unreviewed_items,
        branch_suspect_links,
    )

    for item_name, sme_scores in changed_items_with_sme_scores.items():
        sme_score_str = "\n".join(
            [f"  {sme_name}: {sme_score}" for sme_name, sme_score in sme_scores.items()]
        )

        logger.warning(
            f"Item {item_name} has changed and contains the following SME scores:\n\n{Fore.GREEN}{sme_score_str}{Style.RESET_ALL}\n"
        )

    return exit_code


def _restore_git_head(repo: Repo, dirty: bool) -> None:
    repo.git.switch("-", detach=True)
    logger.info("git HEAD restored")
    if dirty:
        logger.info("restored uncommited git changes")
        repo.git.stash("pop")


def set_all_link_status_linked(current_graph: TrustableGraph, item: str) -> None:
    """
    This sets the link status of all links from the `item` as LINKED.
    This will not change the link status of links to items that aren't reviewed.

    Args:
        current_graph (TrustableGraph): The current working graph.
        item (str): The item to set all the links from/to
    """
    if not current_graph.get_review_status(item):
        logger.warning(
            f"Cannot set links from source '{item}', as item review status is unreviewed.\n"
        )
        return
    for parent in current_graph.get_item_parents(item):
        if (
            current_graph.get_review_status(parent.name)
            and current_graph.get_link_status(parent.name, item) is LinkStatus.SUSPECT
        ):
            current_graph.set_link_status(parent.name, item, LinkStatus.LINKED)
    for child in current_graph.get_item_children(item):
        if (
            current_graph.get_review_status(child.name)
            and current_graph.get_link_status(item, child.name) is LinkStatus.SUSPECT
        ):
            current_graph.set_link_status(item, child.name, LinkStatus.LINKED)
